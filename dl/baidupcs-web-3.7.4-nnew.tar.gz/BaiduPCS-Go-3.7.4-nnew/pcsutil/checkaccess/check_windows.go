package checkaccess

// TODO: check writable

func AccessRDWR(path string) bool {
	return true
}
