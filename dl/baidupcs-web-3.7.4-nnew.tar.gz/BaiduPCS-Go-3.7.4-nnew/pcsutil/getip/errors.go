package getip

import (
	"errors"
)

var (
	// ErrParseIP 解析ip地址错误
	ErrParseIP = errors.New("parse ip error")
)
