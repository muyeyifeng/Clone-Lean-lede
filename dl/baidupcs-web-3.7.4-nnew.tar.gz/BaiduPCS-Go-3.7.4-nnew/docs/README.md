# 文档目录

## 百度PCS文档

### 文件API

[综述](https://github.com/Erope/BaiduPCS-Go/blob/master/docs/overview.md)

[文件API列表](https://github.com/Erope/BaiduPCS-Go/blob/master/docs/file_data_apis_list.md)

[文件API错误码列表](https://github.com/Erope/BaiduPCS-Go/blob/master/docs/file_data_apis_error.md)

### 结构化数据API

[综述](https://github.com/Erope/BaiduPCS-Go/blob/master/docs/structured_data_apis_overview.md)

[结构化数据API列表](https://github.com/Erope/BaiduPCS-Go/blob/master/docs/structured_data_api_list.md)

[结构化数据API错误码](https://github.com/Erope/BaiduPCS-Go/blob/master/docs/structured_data_apis_error.md)
