# Daemon 守护进程

Run the brook daemon with joker

```
joker brook server -l :9999 -p hello
```

Get the last command ID

```
joker last
```

View output and error of a command

```
joker log ID
```

View running commmands

```
joker list
```

Stop a running command

```
joker stop ID
```

