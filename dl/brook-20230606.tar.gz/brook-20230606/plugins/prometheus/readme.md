`prometheus` plugin can send log into prometheus
