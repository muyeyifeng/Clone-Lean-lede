假设你的 brook wsserver 是 `ws://1.2.3.4:9999`, 密码是 `hello`

## 在 Brook 图形客户端

1. 选择 `brook wsserver`
2. 输入 server `ws://1.2.3.4:9999`
3. 输入密码 `hello`
4. 点击 `添加` 按钮

## 提示

-   在桌面, 请偏爱使用 Chrome 浏览器, 可能需要重启浏览器
-   在桌面, 如果选择 `proxy` 模式在图形客户端, 一些软件需要手动配置代理:
    -   [**Telegram**] Settings->Data and Storage->Use Proxy->Add Proxy->Socks5, Server: `127.0.0.1` or `::1`, Port: `1080` -> Done. **重启 Telegram, 这块 Telegram 有 bug**
