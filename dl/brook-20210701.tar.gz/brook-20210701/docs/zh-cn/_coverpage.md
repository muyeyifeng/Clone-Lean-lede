![logo](https://txthinking.github.io/brook/_static/brook.png)

# Brook

> Brook 是一个跨平台的强加密无特征的代理软件.<br/>
> Brook 遵循 KISS 哲学.

[GitHub](https://github.com/txthinking/brook)
[开始](#什么是cli和gui)

![color](#ffffff)
