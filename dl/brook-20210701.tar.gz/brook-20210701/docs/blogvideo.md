* Blog: https://talks.txthinking.com
* Youtube: https://www.youtube.com/txthinking
