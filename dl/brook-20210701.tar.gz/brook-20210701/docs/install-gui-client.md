GUI(Graphical user interface), Brook GUI has only client function.

## macOS

[Brook.dmg](https://github.com/txthinking/brook/releases/latest/download/Brook.dmg)

or

```
$ brew install --cask brook
```

## Windows

[Brook.exe](https://github.com/txthinking/brook/releases/latest/download/Brook.exe)

## Android

[Brook.apk](https://github.com/txthinking/brook/releases/latest/download/Brook.apk)

## iOS & M1 Mac

[Brook for iOS](https://apps.apple.com/us/app/brook-a-cross-platform-proxy/id1216002642)

## OpenWrt

[brook_linux_xxx.ipk](/brook-tproxy-gui)

---

You can get the all above download links on the [releases](https://github.com/txthinking/brook/releases) page
