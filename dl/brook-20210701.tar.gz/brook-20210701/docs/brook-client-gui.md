Assume your brook server is `1.2.3.4:9999` and password is `hello`

## On Brook GUI Client

1. Select `brook server`
2. Type `1.2.3.4:9999` on server field
3. Type `hello` on password field
4. Tap `Add` button

## Tips

-   On desktop, please prefer to use Chrome browser. You may need to restart your browser or application
-   On desktop, if you choose `proxy` mode on the GUI client, some software requires manual config proxy:
    -   [**Telegram**] Settings->Data and Storage->Use Proxy->Add Proxy->Socks5, Server: `127.0.0.1` or `::1`, Port: `1080` -> Done. **Restart Telegram, it has a bug on this**
