# brook wssserver protocol

<!--THEME:github-->
<!--G-R3M673HK5V-->

```
TLS(brook wsserver protocol)
```

The simple explanation is `brook wsserver + tls = brook wssserver`

The similar concept is `http + tls = https`
