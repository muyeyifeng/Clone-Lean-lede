package constant

var (
	Version = "Custom Version"
	Commit  = "Unknown Git Commit ID"
)
