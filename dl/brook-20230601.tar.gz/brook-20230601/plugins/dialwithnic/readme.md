`dialwithnic` plugin can dial with specified nic
