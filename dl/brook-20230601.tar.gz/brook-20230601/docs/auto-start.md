# Auto Start at Boot 开机自启

Add one auto-start command at boot

```
jinbe joker brook server -l :9999 -p hello
```

View added commmands

```
jinbe list
```

Remove one added command

```
jinbe remove ID
```

