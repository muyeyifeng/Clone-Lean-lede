# One Click Script 一键脚本

```
bash <(curl https://bash.ooo/brook.sh)
```
