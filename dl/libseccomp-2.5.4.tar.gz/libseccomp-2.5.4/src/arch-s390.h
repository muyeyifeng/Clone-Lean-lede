/*
 * Copyright 2015 IBM
 * Author: Jan Willeke <willeke@linux.vnet.com.com>
 */

#ifndef _ARCH_S390_H
#define _ARCH_S390_H

#include "arch.h"

ARCH_DECL(s390)

#endif
