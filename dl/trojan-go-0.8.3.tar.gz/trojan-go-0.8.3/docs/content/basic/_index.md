---
title: "基本配置"
draft: false
weight: 20
---

这一部分内容将介绍如何配置基本的Trojan-Go代理服务器和客户端。
