// +build !linux !cgo

package nsenter
