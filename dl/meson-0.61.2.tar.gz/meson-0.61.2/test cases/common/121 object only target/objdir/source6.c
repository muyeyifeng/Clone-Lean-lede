int func6_in_obj(void) {
    return 0;
}
