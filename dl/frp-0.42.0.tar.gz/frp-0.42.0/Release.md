### New

* Added new parameter `config_dir` in frpc to run multiple client instances in one process.

### Fix

* Equal sign in environment variables causes parsing error.
