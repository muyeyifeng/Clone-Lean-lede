---
name: Bug report
about: Did something not work as expected?
title: ''
labels: ''
assignees: ''

---

### Please read the document first

* https://txthinking.github.io/brook/

### Please describe step by step any commands and operations you have performed, environment and version:
