#ifndef OVERRIDE_H
#define OVERRIDE_H

Netsnmp_Node_Handler override_handler;
void init_override(void);

#endif                          /* OVERRIDE_H */
