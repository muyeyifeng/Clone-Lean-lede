.. _mozilla_projects_nss:

Network Security Services (NSS)
===============================

.. toctree::
   :maxdepth: 2
   :glob:
   :hidden:

   getting_started.rst
   build_artifacts.rst
   releases/index.rst
   community.rst
   more.rst
   More documentation <more_docs>


.. warning::
   This NSS documentation was just imported from our legacy MDN repository. It currently is very deprecated and likely incorrect or broken in many places.

