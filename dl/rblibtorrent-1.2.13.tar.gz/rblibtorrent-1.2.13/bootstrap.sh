#!/bin/sh

./autotool.sh
./configure $@

