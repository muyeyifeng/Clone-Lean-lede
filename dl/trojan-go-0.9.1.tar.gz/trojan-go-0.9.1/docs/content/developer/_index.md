---
title: "实现细节和开发指南"
draft: false
weight: 40
---

这一部分介绍Trojan-Go底层实现的细节，主要面向开发者。
