**Please provide the following information**

libtorrent version (or branch):

platform/architecture:

compiler and compiler version:

please describe what symptom you see, what you would expect to see instead and
how to reproduce it.

