<!--
---
title: "Breaking Changes"
custom_edit_url: https://github.com/netdata/netdata/edit/master/BREAKING_CHANGES.md
---
-->

# Breaking Changes

-   remove deprecated bash modules (`apache`, `cpu_apps`, `cpufreq`, `exim`, `hddtemp`, `load_average`, `mem_apps`, `mysql`, `nginx`, `phpfpm`, `postfix`, `squid`, `tomcat`) [[#7962](https://github.com/netdata/netdata/pull/7962)]
