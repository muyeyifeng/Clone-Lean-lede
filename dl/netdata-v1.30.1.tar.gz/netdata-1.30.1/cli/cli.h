// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef NETDATA_CLI_H
#define NETDATA_CLI_H 1

#include "../daemon/common.h"

#endif //NETDATA_CLI_H
