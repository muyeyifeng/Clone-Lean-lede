#!/bin/sh
adduser --system --ingroup video mjpg_streamer
