#ifndef SSOCKS_CONFIG
#define SSOCKS_CONFIG

#define PACKAGE_NAME      "ssocks"
#define PACKAGE_TARNAME   "ssocks"
#define PACKAGE_VERSION   "0.0.14"
#define PACKAGE_STRING    "ssocks 0.0.14"
#define PACKAGE_BUGREPORT "https://github.com/tostercx/ssocks/issues"
#define PACKAGE_URL       ""

#endif
