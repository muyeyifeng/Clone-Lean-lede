# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability, please send an e-mail to cloud@txthinking.com.
It would be much appreciated if the POC is directly included.
All security vulnerabilities will be promptly addressed.
