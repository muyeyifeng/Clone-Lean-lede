`block` plugin can block the dst address on the server side, such as domain or ip. If it is the domain dst, and the IP will be resolved in the domain and check again.
