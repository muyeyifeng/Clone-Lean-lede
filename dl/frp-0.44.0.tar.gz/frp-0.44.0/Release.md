### New

* Use auto generated certificates if `plugin_key_path` and `plugin_crt_path` are empty for plugin `https2https` and `https2http`.
* Server dashboard supports TLS configs.

### Fix

* xtcp error with IPv6 address.
