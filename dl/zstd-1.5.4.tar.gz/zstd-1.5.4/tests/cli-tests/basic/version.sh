#!/bin/sh

set -e

zstd -V
zstd --version
