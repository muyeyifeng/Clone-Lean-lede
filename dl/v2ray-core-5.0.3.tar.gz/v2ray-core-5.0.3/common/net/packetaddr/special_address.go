package packetaddr

const seqPacketMagicAddress = "sp.packet-addr.v2fly.arpa"
