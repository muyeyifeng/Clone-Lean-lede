package system

import "github.com/opencontainers/runc/libcontainer/userns"

var RunningInUserNS = userns.RunningInUserNS
