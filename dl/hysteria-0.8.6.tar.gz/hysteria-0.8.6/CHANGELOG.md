# Changelog

## 0.8.5

- Added an option to disable MTU discovery `disable_mtu_discovery`
