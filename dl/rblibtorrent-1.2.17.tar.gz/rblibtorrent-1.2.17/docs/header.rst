:Author: Arvid Norberg, arvid@libtorrent.org
:Version: 1.2.17

