# brook wssserver protocol

<!--THEME:github-->
<!--G-R3M673HK5V-->

```
TLS(brook wsserver protocol)
```

The simple explanation is `brook wsserver + tls = brook wssserver`, and brook wsserver is a standard http server, so `http + tls = https`, brook wssserver is a standard https server
