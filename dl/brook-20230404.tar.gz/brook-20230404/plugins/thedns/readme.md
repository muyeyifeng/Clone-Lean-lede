`thedns` plugin can block/bypass/disable ipv4/disable ipv6 dns query for brook dnsoverbrook/dnsserver.
