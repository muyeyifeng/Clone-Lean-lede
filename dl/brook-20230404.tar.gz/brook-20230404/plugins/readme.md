It is very simple to write brook plugin, just overwrite the public function variable.
