`log` plugin can log to console or log to file.
