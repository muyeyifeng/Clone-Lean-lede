ssize_t myread(int fd, char *whereto, size_t len);
ssize_t mywrite(int fd, char *wherefrom, size_t len);
