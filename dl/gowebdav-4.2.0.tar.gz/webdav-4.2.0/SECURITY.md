# Security Policy

## Reporting a Vulnerability

Please report security issues to:
msaa1990 [at] gmail [dot com]

cc: hacdias [at] gmail [dot com]
