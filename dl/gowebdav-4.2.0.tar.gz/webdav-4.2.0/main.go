package main

import (
	"github.com/hacdias/webdav/v4/cmd"
)

func main() {
	cmd.Execute()
}
