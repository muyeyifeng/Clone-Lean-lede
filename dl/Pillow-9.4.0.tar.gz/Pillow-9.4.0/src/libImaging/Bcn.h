typedef struct {
    char *pixel_format;
} BCNSTATE;
