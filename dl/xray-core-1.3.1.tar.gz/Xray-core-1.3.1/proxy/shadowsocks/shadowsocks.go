// Package shadowsocks provides compatible functionality to Shadowsocks.
//
// Shadowsocks client and server are implemented as outbound and inbound respectively in Xray's term.
//
// R.I.P Shadowsocks
package shadowsocks

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen
