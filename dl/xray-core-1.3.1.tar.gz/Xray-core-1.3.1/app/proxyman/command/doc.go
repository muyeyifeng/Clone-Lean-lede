package command

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen
