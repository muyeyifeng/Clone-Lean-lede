// cmMod.hpp (H)
#pragma once

#error "cmMod.hpp in incH must not be included"
