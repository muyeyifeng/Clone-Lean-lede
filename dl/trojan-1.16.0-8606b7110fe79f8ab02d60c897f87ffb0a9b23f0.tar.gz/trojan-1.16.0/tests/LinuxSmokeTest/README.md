# Linux Smoke Test

## Dependencies

- curl
- netcat
- openssl
- python3

## Usage

```
./basic.sh /path/to/trojan
./fake-client.sh /path/to/trojan
```
