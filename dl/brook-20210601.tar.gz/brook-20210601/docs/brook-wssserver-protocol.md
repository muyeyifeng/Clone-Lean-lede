# `brook wssserver` Protocol

```
TLS(brook wsserver protocol)
```

The simple explanation is `brook wsserver + tls = brook wssserver`

The similar concept is `http + tls = https`
