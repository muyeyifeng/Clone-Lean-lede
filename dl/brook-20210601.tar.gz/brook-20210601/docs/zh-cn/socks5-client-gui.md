假设你的 socks5 server 是 `1.2.3.4:9999`

## 在 Brook 图形客户端

1. 选择 `socks5 server`
2. 输入 server `1.2.3.4:9999`
3. 点击 `添加` 按钮

## 提示

-   在桌面, 请偏爱使用 Chrome 浏览器, 可能需要重启浏览器
-   在桌面, 如果选择 `proxy` 模式在图形客户端, 一些软件需要手动配置代理:
    -   [**Telegram**] Settings->Data and Storage->Use Proxy->Add Proxy->Socks5, Server: `1.2.3.4`, Port: `9999` -> Done. **重启 Telegram, 这块 Telegram 有 bug**
