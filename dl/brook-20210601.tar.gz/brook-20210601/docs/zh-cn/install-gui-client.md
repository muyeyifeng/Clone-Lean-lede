GUI(图形用户界面), Brook 图形客户端.

## macOS

[Brook.dmg](https://github.com/txthinking/brook/releases/latest/download/Brook.dmg)

or

```
$ brew install --cask brook
```

[BrookLite.dmg](https://github.com/txthinking/brook/releases/latest/download/BrookLite.dmg)

or

```
$ brew install --cask brooklite
```

## Windows

[Brook.exe](https://github.com/txthinking/brook/releases/latest/download/Brook.exe)

[BrookLite.exe](https://github.com/txthinking/brook/releases/latest/download/BrookLite.exe)

## Android

[Brook.apk](https://github.com/txthinking/brook/releases/latest/download/Brook.apk)

## iOS

[Brook on App Store](https://apps.apple.com/us/app/brook-a-cross-platform-proxy/id1216002642)

请使用非中国大陆 Apple ID 下载.

## OpenWrt

[brook_linux_xxx.ipk](/zh-cn/brook-tproxy-gui)

---

以上下载链接你也能在[releases](https://github.com/txthinking/brook/releases)页面找到
