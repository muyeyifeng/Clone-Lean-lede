// +build windows

package engine

var (
	isRoot = func() bool {
		return true
	}
)
