<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>À propos de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>Responsable actuel</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation>Grèce</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation>Nationalité :</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation>E-mail :</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation>Nom&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation>Auteur original</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation>France</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>Remerciements</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation>Traducteurs</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="296"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="322"/>
        <source>Software Used</source>
        <translation>Logiciels utilisés</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="328"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent a été conçu à l&apos;aide des bibliothèques logicielles suivantes :</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="66"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un client BitTorrent évolué programmé en C++, basé sur les bibliothèques Qt et libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="67"/>
        <source>Copyright %1 2006-2021 The qBittorrent project</source>
        <translation>Copyright %1 2006-2021 Le projet qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="68"/>
        <source>Home Page:</source>
        <translation>Page d&apos;accueil :</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="69"/>
        <source>Forum:</source>
        <translation>Forum :</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="70"/>
        <source>Bug Tracker:</source>
        <translation>Suivi des bugs : </translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="110"/>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>La base de données libre IP to Country Lite de DB-IP est utilisée pour déterminer les pays des pairs. La base de données est sous licence Creative Commons Attribution 4.0 International License</translation>
    </message>
</context>
<context>
    <name>AbstractFileStorage</name>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="60"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="102"/>
        <source>The old path is invalid: &apos;%1&apos;.</source>
        <translation>L&apos;ancien chemin est invalide : &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="62"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="104"/>
        <source>The new path is invalid: &apos;%1&apos;.</source>
        <translation>Le nouveau chemin est invalide : &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="66"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="70"/>
        <source>Invalid file path: &apos;%1&apos;.</source>
        <translation>Chemin du fichier invalide : &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="72"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="115"/>
        <source>Absolute path isn&apos;t allowed: &apos;%1&apos;.</source>
        <translation>Chemin absolu non autorisé : &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="82"/>
        <source>The file already exists: &apos;%1&apos;.</source>
        <translation>Le fichier existe déjà : &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="86"/>
        <source>No such file: &apos;%1&apos;.</source>
        <translation>Aucun fichier de ce type : &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="127"/>
        <source>The folder already exists: &apos;%1&apos;.</source>
        <translation>Le dossier existe déjà : &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="131"/>
        <source>No such folder: &apos;%1&apos;.</source>
        <translation>Aucun dossier de ce type : &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Save at</source>
        <translation>Sauvegarder sous</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="384"/>
        <source>Never show again</source>
        <translation>Ne plus afficher</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="99"/>
        <source>Torrent settings</source>
        <translation>Paramètres du torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="132"/>
        <source>Set as default category</source>
        <translation>Définir comme catégorie par défaut</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Category:</source>
        <translation>Catégorie :</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="172"/>
        <source>Start torrent</source>
        <translation>Démarrer le torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="249"/>
        <source>Torrent information</source>
        <translation>Informations sur le torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="158"/>
        <source>Skip hash check</source>
        <translation>Ne pas vérifier les données du torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="196"/>
        <source>Content layout:</source>
        <translation>Agencement du contenu:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="207"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="212"/>
        <source>Create subfolder</source>
        <translation>Créer un sous-dossier</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="217"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Ne pas créer de sous-dossier</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="268"/>
        <source>Size:</source>
        <translation>Taille :</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="341"/>
        <source>Hash:</source>
        <translation>Hash :</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="348"/>
        <source>Comment:</source>
        <translation>Commentaire :</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="255"/>
        <source>Date:</source>
        <translation>Date :</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="41"/>
        <source>Torrent Management Mode:</source>
        <translation>Mode de gestion de torrent :</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="48"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Le mode automatique signifie que certaines propriétés du torrent (ex: le dossier d&apos;enregistrement) seront décidées via la catégorie associée</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="52"/>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="57"/>
        <source>Automatic</source>
        <translation>Automatique</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Remember last used save path</source>
        <translation>Se souvenir du dernier chemin utilisé</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="141"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Quand coché, le fichier .torrent ne sera pas supprimé malgré les paramètres de la page &quot;Téléchargements&quot; des options.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Do not delete .torrent file</source>
        <translation>Ne pas supprimer le fichier .torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="165"/>
        <source>Download in sequential order</source>
        <translation>Télécharger en ordre séquentiel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="151"/>
        <source>Download first and last pieces first</source>
        <translation>Télécharger les premières et dernières pièces en premier</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="436"/>
        <source>Save as .torrent file...</source>
        <translation>Enregistrer le fichier .torrent sous...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="531"/>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="535"/>
        <source>High</source>
        <translation>Haute</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="539"/>
        <source>Maximum</source>
        <translation>Maximale</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="527"/>
        <source>Do not download</source>
        <translation>Ne pas télécharger</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="478"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="646"/>
        <source>I/O Error</source>
        <translation>Erreur E/S</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="259"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="727"/>
        <source>Invalid torrent</source>
        <translation>Torrent invalide</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="674"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Non disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="675"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Non disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="684"/>
        <source>Not available</source>
        <translation>Non disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <source>Invalid magnet link</source>
        <translation>Lien magnet invalide</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="260"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Erreur lors du chargement du torrent &apos;%1&apos;.
Erreur : %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <source>This magnet link was not recognized</source>
        <translation>Ce lien magnet n&apos;a pas été reconnu</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="344"/>
        <source>Magnet link</source>
        <translation>Lien magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="350"/>
        <source>Retrieving metadata...</source>
        <translation>Récupération des métadonnées…</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="105"/>
        <source>Choose save path</source>
        <translation>Choisir un répertoire de destination</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="283"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="294"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="324"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="330"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="335"/>
        <source>Torrent is already present</source>
        <translation>Le torrent existe déjà</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="283"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="324"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation>Le torrent &apos;%1&apos; est déjà dans la liste de transfert. Les trackers n&apos;ont pas été regroupés car il s&apos;agit d&apos;un torrent privé.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>Le torrent &apos;%1&apos; est déjà dans la liste de transfert. Les trackers ont été regroupés.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="294"/>
        <source>Torrent is already queued for processing.</source>
        <translation>Le torrent est déjà en file d&apos;attente de traitement.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="330"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>Le lien Magnet &apos;%1&apos; est déjà dans la liste de transfert. Les trackers ont été regroupés.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="335"/>
        <source>Magnet link is already queued for processing.</source>
        <translation>Le lien Magnet est déjà en file d&apos;attente de traitement.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="417"/>
        <source>%1 (Free space on disk: %2)</source>
        <translation>%1 (espace libre sur le disque : %2)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="418"/>
        <source>Not available</source>
        <comment>This size is unavailable.</comment>
        <translation>Non disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="464"/>
        <source>Save as torrent file</source>
        <translation>Enregistrer le fichier torrent sous</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="544"/>
        <source>By shown file order</source>
        <translation>Par ordre de fichier affiché</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="747"/>
        <source>Cannot download &apos;%1&apos;: %2</source>
        <translation>Impossible de télécharger &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="520"/>
        <source>Rename...</source>
        <translation>Renommer…</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="525"/>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="647"/>
        <source>Invalid metadata</source>
        <translation>Metadata invalides.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="654"/>
        <source>Parsing metadata...</source>
        <translation>Analyse syntaxique des métadonnées...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="658"/>
        <source>Metadata retrieval complete</source>
        <translation>Récuperation des métadonnées terminée</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="727"/>
        <source>Failed to load from URL: %1.
Error: %2</source>
        <translation>Impossible d&apos;accéder à cette URL : %1.
Motif: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="746"/>
        <source>Download Error</source>
        <translation>Erreur de téléchargement</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="323"/>
        <location filename="../gui/advancedsettings.cpp" line="465"/>
        <source> MiB</source>
        <translation>Mio</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="546"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Ports sortants (min) [0: désactivé]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="553"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Ports sortants (max) [0: désactivé]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="595"/>
        <source>Recheck torrents on completion</source>
        <translation>Revérifier les torrents lorsqu&apos;ils sont terminés</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="601"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalle d&apos;actualisation de la liste de transfert</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="600"/>
        <location filename="../gui/advancedsettings.cpp" line="664"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="150"/>
        <source>Setting</source>
        <translation>Paramètre</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="150"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valeur</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="319"/>
        <location filename="../gui/advancedsettings.cpp" line="332"/>
        <source> (disabled)</source>
        <translation>(désactivé)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="321"/>
        <source> (auto)</source>
        <translation>(automatique)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="330"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation>min</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="343"/>
        <source>All addresses</source>
        <translation>Toutes les adresses</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="389"/>
        <source>qBittorrent Section</source>
        <translation>Section qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="386"/>
        <location filename="../gui/advancedsettings.cpp" line="394"/>
        <source>Open documentation</source>
        <translation>Ouvrir la documentation</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="344"/>
        <source>All IPv4 addresses</source>
        <translation>Toutes les adresses IPv4</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="345"/>
        <source>All IPv6 addresses</source>
        <translation>Toutes les adresses IPv6</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="397"/>
        <source>libtorrent Section</source>
        <translation>Section libtorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="400"/>
        <source>Fastresume files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="400"/>
        <source>SQLite database (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="402"/>
        <source>Resume data storage type (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Below normal</source>
        <translation>Sous la normale</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Medium</source>
        <translation>Moyenne</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Low</source>
        <translation>Basse</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Very low</source>
        <translation>Très basse</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="427"/>
        <source>Process memory priority (Windows &gt;= 8 only)</source>
        <translation>Priorité mémoire du processus (Windows &gt;= 8 seulement)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="436"/>
        <source>Asynchronous I/O threads</source>
        <translation>Fils d&apos;entrée/sortie asynchrones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="444"/>
        <source>Hashing threads</source>
        <translation>Fils de Hachage</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="452"/>
        <source>File pool size</source>
        <translation>Taille du pool de fichiers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="466"/>
        <source>Outstanding memory when checking torrents</source>
        <translation>Dépassement de mémoire lors de la vérification de torrents</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="482"/>
        <source>Disk cache</source>
        <translation>Cache disque</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="488"/>
        <location filename="../gui/advancedsettings.cpp" line="560"/>
        <location filename="../gui/advancedsettings.cpp" line="647"/>
        <location filename="../gui/advancedsettings.cpp" line="735"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="489"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalle de l&apos;expiration du cache disque</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="494"/>
        <source>Enable OS cache</source>
        <translation>Activer le cache du système d’exploitation</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="499"/>
        <source>Coalesce reads &amp; writes</source>
        <translation>Fusionner lectures &amp; écritures</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="504"/>
        <source>Use piece extent affinity</source>
        <translation>Utiliser l&apos;affinité par extension de morceau</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="507"/>
        <source>Send upload piece suggestions</source>
        <translation>Envoyer des suggestions de morceaux de téléversement</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="512"/>
        <location filename="../gui/advancedsettings.cpp" line="518"/>
        <source> KiB</source>
        <translation>Kio</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="514"/>
        <source>Send buffer watermark</source>
        <translation>Envoyer un filigrane de tampon</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="520"/>
        <source>Send buffer low watermark</source>
        <translation>Envoyer un filigrane bas de tampon</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="526"/>
        <source>Send buffer watermark factor</source>
        <translation>Envoyer le facteur de filigrane du tampon</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="532"/>
        <source>Socket backlog size</source>
        <translation>Taille de la liste des tâches du socket</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="561"/>
        <source>UPnP lease duration [0: Permanent lease]</source>
        <translation>Durée du bail UPnP [0: Bail permanent]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="567"/>
        <source>Type of service (ToS) for connections to peers</source>
        <translation>Type de service (ToS) pour les connexions aux pairs</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="570"/>
        <source>Prefer TCP</source>
        <translation>Préférer TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="570"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Proportionnel au pair (accélérateurs TCP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="577"/>
        <source>Support internationalized domain name (IDN)</source>
        <translation>Support des noms de domaines internationalisés (IDN)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="582"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Permettre des connexions multiples depuis la même adresse IP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="587"/>
        <source>Validate HTTPS tracker certificates</source>
        <translation>Valider les certificats HTTPS des trackers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="592"/>
        <source>Disallow connection to peers on privileged ports</source>
        <translation>Interdire la connexion à des pairs sur des ports privilégiés</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="607"/>
        <source>Resolve peer host names</source>
        <translation>Afficher le nom d&apos;hôte des pairs</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="663"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="665"/>
        <source>Notification timeout [0: infinite]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="680"/>
        <source>Enable icons in menus</source>
        <translation>Activer les icônes dans les menus</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="725"/>
        <source>Peer turnover disconnect percentage</source>
        <translation>Pourcentage de déconnexion par roulement de pair</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="731"/>
        <source>Peer turnover threshold percentage</source>
        <translation>Pourcentage de seuil de roulement de pair</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="737"/>
        <source>Peer turnover disconnect interval</source>
        <translation>Intervalle de déconnexion par roulement de pair</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="648"/>
        <source>Stop tracker timeout</source>
        <translation>Arrêter le délai d&apos;expiration du tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="654"/>
        <source>Display notifications</source>
        <translation>Afficher les notifications</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="657"/>
        <source>Display notifications for added torrents</source>
        <translation>Afficher les notifications pour les torrents ajoutés</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="669"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Télécharger les favicon des trackers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="673"/>
        <source>Save path history length</source>
        <translation>Sauvegarder la longueur de l&apos;historique des chemins</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="676"/>
        <source>Enable speed graphs</source>
        <translation>Activer les graphiques de vitesse</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="691"/>
        <source>Fixed slots</source>
        <translation>Emplacements fixes</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="691"/>
        <source>Upload rate based</source>
        <translation>Taux de téléversement basé</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="693"/>
        <source>Upload slots behavior</source>
        <translation>Comportement des emplacements de téléversement</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="696"/>
        <source>Round-robin</source>
        <translation>Répartition de charge</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="696"/>
        <source>Fastest upload</source>
        <translation>Téléversement le plus rapide</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="696"/>
        <source>Anti-leech</source>
        <translation>Anti-leech</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="698"/>
        <source>Upload choking algorithm</source>
        <translation>Téléversement d&apos;algorithme de choke - Blocage des Pairs</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="703"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirmer la revérification du torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="707"/>
        <source>Confirm removal of all tags</source>
        <translation>Confirmer la suppression de toutes les étiquettes</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="711"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>Toujours annoncer à tous les trackers d&apos;un niveau</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="717"/>
        <source>Always announce to all tiers</source>
        <translation>Toujours annoncer à tous les niveaux</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="609"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>N&apos;importe quelle interface</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="541"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Intervalle de sauvegarde des données de reprise</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="572"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>Algorithme mode mixte %1-TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="604"/>
        <source>Resolve peer countries</source>
        <translation>Retrouver les pays des pairs</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="631"/>
        <source>Network interface</source>
        <translation>Interface réseau</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="634"/>
        <source>Optional IP address to bind to</source>
        <translation>Adresse IP optionnelle à laquelle se relier</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="637"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Adresse IP annoncée aux trackers (Redémarrage requis)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="643"/>
        <source>Max concurrent HTTP announces</source>
        <translation>Maximum d&apos;annonces HTTP parallèles</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="684"/>
        <source>Enable embedded tracker</source>
        <translation>Activer le tracker intégré</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="689"/>
        <source>Embedded tracker port</source>
        <translation>Port du tracker intégré</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="184"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 démarré.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="187"/>
        <source>Running in portable mode. Auto detected profile folder at: %1</source>
        <translation>Fonctionnement en mode portable. Dossier de profil détecté automatiquement : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="189"/>
        <source>Redundant command line flag detected: &quot;%1&quot;. Portable mode implies relative fastresume.</source>
        <translation>Indicateur de ligne de commandes redondant détecté : «% 1». Le mode portable implique une reprise relativement rapide.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="193"/>
        <source>Using config directory: %1</source>
        <translation>Utilisation du dossier de configuration : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="386"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent : %1, programme externe en cours d&apos;exécution, commande : %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="448"/>
        <source>Torrent name: %1</source>
        <translation>Nom du Torrent : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="449"/>
        <source>Torrent size: %1</source>
        <translation>Taille du Torrent : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="450"/>
        <source>Save path: %1</source>
        <translation>Chemin de sauvegarde : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="451"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Le Torrent a été téléchargé dans %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="453"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Merci d&apos;utiliser qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="460"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; a terminé le téléchargement</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="475"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent : %1, envoi de l&apos;email de notification</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="645"/>
        <source>Application failed to start.</source>
        <translation>Échec du démarrage de l&apos;application.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="658"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="659"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation>Pour contrôler qBittorrent, accédez à l&apos;interface web via %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="665"/>
        <source>The Web UI administrator username is: %1</source>
        <translation>Le nom d&apos;utilisateur de l&apos;administrateur de l&apos;interface web est : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="666"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Le mot de passe de l&apos;administrateur de l&apos;interface web est toujours celui par défaut : %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="667"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Ceci peut être dangereux, veuillez penser à changer votre mot de passe dans les options.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="799"/>
        <source>Saving torrent progress...</source>
        <translation>Sauvegarde de l&apos;avancement du torrent.</translation>
    </message>
</context>
<context>
    <name>AsyncFileStorage</name>
    <message>
        <location filename="../base/asyncfilestorage.cpp" line="42"/>
        <source>Could not create directory &apos;%1&apos;.</source>
        <translation>Impossible de créer le dossier &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="53"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation>Échec d&apos;authentification WebAPI. Motif : l&apos;IP est bloquée, IP : %1, nom d&apos;utilisateur : %2</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="57"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Votre adresse IP a été bloquée car vous avez dépassé le nombre de tentatives d&apos;authentification autorisées.</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="73"/>
        <source>WebAPI login success. IP: %1</source>
        <translation>Authentification WebAPI réussie. IP: %1</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="80"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation>Échec d&apos;authentification WebAPI. Motif : identifiants invalides, nombre de tentatives : %1, IP : %2, nom d&apos;utilisateur : %3</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="243"/>
        <source>Save to:</source>
        <translation>Sauvegarder sous :</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Gestionnaire de téléchargement RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Le téléchargement automatique des torrents par flux RSS est actuellement désactivé ! Vous pouvez l&apos;activer depuis les paramètres de l&apos;application.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Règles pour le téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Définition d&apos;une règle</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Utiliser les expressions régulières</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation>Utiliser le filtre d&apos;épisodes intelligent</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Doit contenir :</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>Ne doit pas contenir :</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Filtre d&apos;épisode&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>Le filtre d&apos;épisodes intelligent vérifiera le numéro de l&apos;épisode afin d&apos;éviter le téléchargement de doublons.
Les formats supportés : S01E01, 1x1, 2017.12.31 et 31.12.2017 (les formats date supportent également - comme séparateur) </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Category:</source>
        <translation>Catégorie :</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="231"/>
        <source>Save to a Different Directory</source>
        <translation>Enregistrer dans un dossier différent</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="257"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <extracomment>... X days</extracomment>
        <translation>Ignorer les correspondances ultérieures pour (0 pour désactiver)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="267"/>
        <source>Disabled</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="270"/>
        <source> days</source>
        <translation> jours</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="303"/>
        <source>Add Paused:</source>
        <translation>Ajouter en pause&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="311"/>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="347"/>
        <source>Use global settings</source>
        <translation>Utiliser la configuration globale</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="316"/>
        <source>Always</source>
        <translation>Toujours</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="321"/>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="339"/>
        <source>Torrent content layout:</source>
        <translation>Agencement du contenu du torrent:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="352"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="357"/>
        <source>Create subfolder</source>
        <translation>Créer un sous-dossier</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="362"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Ne pas créer de sous-dossier</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="383"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Appliquer la règle aux flux :</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="405"/>
        <source>Matching RSS Articles</source>
        <translation>Articles RSS correspondants</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="433"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importer...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="443"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exporter...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Articles correspondants basés sur le filtrage épisode</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Example: </source>
        <translation>Exemple&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>correspondra aux épisodes 2, 5, 8 et 15-30 et supérieurs de la saison 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Episode filter rules: </source>
        <translation>Règles de filtrage d&apos;épisodes&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Le numéro de saison est une valeur obligatoire différente de zéro</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="95"/>
        <source>Filter must end with semicolon</source>
        <translation>Le filtre doit se terminer avec un point-virgule</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="96"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Trois types d&apos;intervalles d&apos;épisodes sont pris en charge&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="97"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Nombre simple&#x202f;: &lt;b&gt;1×25;&lt;/b&gt; correspond à l&apos;épisode 25 de la saison 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="98"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Intervalle standard&#x202f;: &lt;b&gt;1×25-40;&lt;/b&gt; correspond aux épisodes 25 à 40 de la saison 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>Le numéro d&apos;épisode est une valeur obligatoire positive</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="64"/>
        <source>Rules</source>
        <translation>Règles</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="65"/>
        <source>Rules (legacy)</source>
        <translation>Règles (héritées)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="99"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Intervalle infini&#x202f;: &lt;b&gt;1x25-;&lt;/b&gt; correspond aux épisodes 25 et suivants de la saison 1,  et tous les épisodes des saisons postérieures</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="286"/>
        <source>Last Match: %1 days ago</source>
        <translation>Dernière correspondance&#x202f;: il y a %1 jours</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="288"/>
        <source>Last Match: Unknown</source>
        <translation>Dernière correspondance&#x202f;: inconnu</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>New rule name</source>
        <translation>Nouveau nom pour la règle</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Veuillez entrer le nom de la nouvelle règle de téléchargement.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="386"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="552"/>
        <source>Rule name conflict</source>
        <translation>Conflit dans les noms de règle</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="387"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="553"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Une règle avec ce nom existe déjà, veuillez en choisir un autre.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="401"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Êtes vous certain de vouloir supprimer la règle de téléchargement &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="403"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Voulez-vous vraiment supprimer les règles sélectionnées ?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="404"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmation de la suppression</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Destination directory</source>
        <translation>Répertoire de destination</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="426"/>
        <source>Invalid action</source>
        <translation>Action invalide</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La liste est vide, il n&apos;y a rien à exporter.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="433"/>
        <source>Export RSS rules</source>
        <translation>Exporter les règles RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="460"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="478"/>
        <source>I/O Error</source>
        <translation>Erreur E/S</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="461"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>Erreur lors de la création du fichier de destination. Motif : %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="469"/>
        <source>Import RSS rules</source>
        <translation>Importer des règles RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>Impossible d&apos;ouvrir le fichier. Motif : %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="497"/>
        <source>Import Error</source>
        <translation>Import impossible</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="498"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>Impossible d&apos;importer le fichier sélectionné des règles. Motif : %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="507"/>
        <source>Add new rule...</source>
        <translation>Ajouter une nouvelle règle…</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="516"/>
        <source>Delete rule</source>
        <translation>Supprimer la règle</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="519"/>
        <source>Rename rule...</source>
        <translation>Renommer la règle…</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="524"/>
        <source>Delete selected rules</source>
        <translation>Supprimer les règles sélectionnées</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="529"/>
        <source>Clear downloaded episodes...</source>
        <translation>Effacer les épisodes téléchargés...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Rule renaming</source>
        <translation>Renommage de la règle</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Please type the new rule name</source>
        <translation>Veuillez enter le nouveau nom pour la règle</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="573"/>
        <source>Clear downloaded episodes</source>
        <translation>Effacer les épisodes téléchargés</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="574"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Êtes-vous sûr de vouloir effacer la liste des épisodes téléchargés pour la règle sélectionnée ?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="688"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Mode regex : utiliser des expressions régulières compatibles à celles de Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="738"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="785"/>
        <source>Position %1: %2</source>
        <translation>Position %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="692"/>
        <source>Wildcard mode: you can use</source>
        <translation>Mode caractère de remplacement : vous pouvez utiliser</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="693"/>
        <source>? to match any single character</source>
        <translation>? pour correspondre à n&apos;importe quel caractère</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="694"/>
        <source>* to match zero or more of any characters</source>
        <translation>* pour correspondre à zéro caractère ou davantage</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="695"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Les caractères espace comptent comme des opérateurs ET (tous les mots, dans n&apos;importe quel ordre)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="696"/>
        <source>| is used as OR operator</source>
        <translation>| est utilisé comme opérateur OU</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="697"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Si l&apos;ordre des mots est important, utilisez * au lieu de d&apos;un caractère espace.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="704"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Une expression avec une clause vide %1 (par exemple %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="708"/>
        <source> will match all articles.</source>
        <translation>va correspondre à tous les articles.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="709"/>
        <source> will exclude all articles.</source>
        <translation>va exclure tous les articles.</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>Liste des adresses IP bloquées</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="80"/>
        <source>Ban IP</source>
        <translation>Bannir l&apos;IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="87"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="94"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="106"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="94"/>
        <source>The entered IP address is invalid.</source>
        <translation>L’adresse IP saisie n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="106"/>
        <source>The entered IP is already banned.</source>
        <translation>L&apos;adresse IP saisie est déjà bloquée.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::BencodeResumeDataStorage</name>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="113"/>
        <source>Cannot create torrent resume folder: &quot;%1&quot;</source>
        <translation type="unfinished">Impossible de créer le répertoire de reprise: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="151"/>
        <source>Couldn&apos;t load torrents queue from &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished">Impossible de charger la file d&apos;attente des torrents depuis &apos;%1&apos;. Motif : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="182"/>
        <source>Cannot read file %1: %2</source>
        <translation type="unfinished">Impossible de lire le fichier %1 : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="341"/>
        <source>Couldn&apos;t save torrent metadata to &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="366"/>
        <source>Couldn&apos;t save torrent resume data to &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="391"/>
        <source>Couldn&apos;t save data to &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished">Impossible de sauvegarder les données dans &apos;%1&apos;. Motif : %2</translation>
    </message>
</context>
<context>
    <name>BitTorrent::DBResumeDataStorage</name>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="261"/>
        <source>Not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="265"/>
        <source>Couldn&apos;t load resume data of torrent &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="505"/>
        <source>Couldn&apos;t store resume data for torrent &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="529"/>
        <source>Couldn&apos;t delete resume data of torrent &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="574"/>
        <source>Couldn&apos;t store torrents queue positions. Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="560"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Un redémarrage est nécessaire pour changer le support PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2420"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Statut réseau du système changé en %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2420"/>
        <source>ONLINE</source>
        <translation>EN LIGNE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2420"/>
        <source>OFFLINE</source>
        <translation>HORS LIGNE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2434"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>La configuration réseau de %1 a changé, rafraîchissement de la session</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1097"/>
        <location filename="../base/bittorrent/session.cpp" line="2804"/>
        <source>Encryption support [%1]</source>
        <translation>Support du chiffrement [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1098"/>
        <location filename="../base/bittorrent/session.cpp" line="2805"/>
        <source>FORCED</source>
        <translation>FORCE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2922"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 n&apos;est pas une adresse IP valide et a été refusée lors de l&apos;application de la liste d&apos;adresses IP bloquées. </translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1096"/>
        <location filename="../base/bittorrent/session.cpp" line="3351"/>
        <source>Anonymous mode [%1]</source>
        <translation>Mode anonyme  [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1631"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed torrent and its files.</source>
        <translation>&apos;%1&apos; a atteint le ratio maximal configuré. Le torrent et ses fichiers ont été supprimés.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1642"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Enabled super seeding for it.</source>
        <translation>&apos;%1&apos; a atteint le ratio maximal configuré. Le mode super-partage a été activé pour ce torrent.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1670"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed torrent and its files.</source>
        <translation>&apos;%1&apos; a atteint le temps d&apos;émission maximal configuré. Le torrent et ses fichiers ont été supprimés.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1681"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Enabled super seeding for it.</source>
        <translation>&apos;%1&apos; a atteint le temps d&apos;émission maximal configuré. Le mode super-partage a été activé pour ce torrent.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2350"/>
        <source>Error: Aborted saving resume data for %1 outstanding torrents.</source>
        <translation>Erreur : annulation de l&apos;enregistrement des données de reprise pour %1 torrents en attente.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2452"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.158.1 isn&apos;t valid.</comment>
        <translation>L&apos;adresse %1 de l&apos;interface réseau configurée est invalide.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2493"/>
        <location filename="../base/bittorrent/session.cpp" line="2528"/>
        <source>Can&apos;t find the configured address &apos;%1&apos; to listen on</source>
        <comment>Can&apos;t find the configured address &apos;192.168.1.3&apos; to listen on</comment>
        <translation>Impossible de trouver l&apos;adresse configurée %1 sur laquelle écouter</translation>
    </message>
    <message>
        <source>Couldn&apos;t save torrent metadata file &apos;%1&apos;. Reason: %2</source>
        <translation type="vanished">Impossible d&apos;enregistrer le fichier de métadonnées torrent &apos;%1&apos;. Motif : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3898"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Impossible de décoder le fichier torrent &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3947"/>
        <source>Cancelled moving &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;.</source>
        <translation>Déplacement de &quot;%1&quot; depuis &quot;%2&quot; vers &quot;%3&quot; annulé.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3957"/>
        <source>Couldn&apos;t enqueue move of &quot;%1&quot; to &quot;%2&quot;. Torrent is currently moving to the same destination location.</source>
        <translation>Impossible d&apos;ajouter à la file d&apos;attente le déplacement de &quot;%1&quot; vers &quot;%2&quot;. Le torrent est actuellement en train d&apos;être déplacé vers le même emplacement.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3966"/>
        <source>Couldn&apos;t enqueue move of &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;. Both paths point to the same location.</source>
        <translation>Impossible d&apos;ajouter le déplacement de &quot;%1&quot; depuis &quot;%2&quot; vers &quot;%3&quot;. Les deux chemins pointent vers le même emplacement.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3974"/>
        <source>Enqueued to move &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;.</source>
        <translation>Ajout du déplacement de &quot;%1&quot; depuis &quot;%2&quot; vers &quot;%3&quot; à la file d&apos;attente.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3991"/>
        <source>Moving &quot;%1&quot; to &quot;%2&quot;...</source>
        <translation>Déplacement de &quot;%1&quot; vers &quot;%2&quot;...</translation>
    </message>
    <message>
        <source>Cannot write to torrent resume folder: &quot;%1&quot;</source>
        <translation type="vanished">Ecriture impossible dans le répertoire de reprise: &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Cannot create torrent resume folder: &quot;%1&quot;</source>
        <translation type="vanished">Impossible de créer le répertoire de reprise: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4103"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Téléchargement récursif du fichier &apos;%1&apos; au sein du torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4576"/>
        <source>IP filter</source>
        <comment>this peer was blocked. Reason: IP filter.</comment>
        <translation>Filtre d&apos;adresses IP</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4579"/>
        <source>port filter</source>
        <comment>this peer was blocked. Reason: port filter.</comment>
        <translation>Filtre de port</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4582"/>
        <source>%1 mixed mode restrictions</source>
        <comment>this peer was blocked. Reason: I2P mixed mode restrictions.</comment>
        <translation>%1 restrictions du mode mixte</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4585"/>
        <source>use of privileged port</source>
        <comment>this peer was blocked. Reason: use of privileged port.</comment>
        <translation>Utilisation d&apos;un port avec privilèges</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4588"/>
        <source>%1 is disabled</source>
        <comment>this peer was blocked. Reason: uTP is disabled.</comment>
        <translation>%1 est désactivé</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4591"/>
        <source>%1 is disabled</source>
        <comment>this peer was blocked. Reason: TCP is disabled.</comment>
        <translation>%1 est désactivé</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4429"/>
        <source>Torrent errored. Torrent: &quot;%1&quot;. Error: %2.</source>
        <translation>Erreur du torrent. Torrent : &quot;%1&quot;. Erreur : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4438"/>
        <source>Couldn&apos;t load torrent. Reason: %1</source>
        <translation>Le torrent n&apos;a pas pu être chargé. Motif : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4460"/>
        <location filename="../base/bittorrent/session.cpp" line="4509"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; a été retiré de la liste de transferts.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4480"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; a été retiré de la liste de transferts et du disque dur.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4503"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; a été retiré de la liste des transferts mais les fichiers n&apos;ont pas été supprimés. Erreur : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4550"/>
        <source>File error alert. Torrent: &quot;%1&quot;. File: &quot;%2&quot;. Reason: %3</source>
        <translation>Alerte d&apos;erreur fichier. Torrent : &quot;%1&quot;. Fichier : &quot;%2&quot;. Motif : %3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4615"/>
        <source>URL seed name lookup failed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Error: &quot;%3&quot;</source>
        <translation>Échec de la recherche du nom d&apos;origine de l&apos;URL. Torrent : « %1 ». URL : « %2 ». Erreur : « %3 »</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4621"/>
        <source>Received error message from a URL seed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Message: &quot;%3&quot;</source>
        <translation>Message d&apos;erreur reçu d&apos;une source d&apos;URL. Torrent : « %1 ». URL : « %2 ». Message : « %3 »</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4630"/>
        <source>Successfully listening on IP: %1, port: %2/%3</source>
        <comment>e.g: Successfully listening on IP: 192.168.0.1, port: TCP/6881</comment>
        <translation>Ecoute correcte sur l&apos;IP: %1, port: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4642"/>
        <source>Failed to listen on IP: %1, port: %2/%3. Reason: %4</source>
        <comment>e.g: Failed to listen on IP: 192.168.0.1, port: TCP/6881. Reason: already in use</comment>
        <translation>Impossible d&apos;écouter sur l&apos;IP : %1, port : %2/%3. Motif : %4</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4650"/>
        <source>Detected external IP: %1</source>
        <comment>e.g. Detected external IP: 1.1.1.1</comment>
        <translation>IP externe détectée : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4732"/>
        <source>Error: Internal alert queue full and alerts were dropped, you might see degraded performance. Dropped alert types: %1. Message: %2</source>
        <translation>Erreur : la file d&apos;attente des alertes internes est pleine et des alertes ont été supprimées, vous pourriez constater une dégradation des performances. Types d&apos;alerte supprimés : %1. Message : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4754"/>
        <source>&quot;%1&quot; is successfully moved to &quot;%2&quot;.</source>
        <translation>&quot;%1&quot; a été déplacé vers &quot;%2&quot; avec succès.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4776"/>
        <source>Failed to move &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;. Reason: %4.</source>
        <translation>Impossible de déplacer &quot;%1&quot; de &quot;%2&quot; à &quot;%3&quot;. Motif : %4.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4815"/>
        <source>SOCKS5 proxy error. Message: %1</source>
        <translation>Erreur du serveur mandataire SOCKS5. Message : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2012"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Téléchargement de &apos;%1&apos;, veuillez patienter...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2507"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>L&apos;interface réseau définie est invalide : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1091"/>
        <source>Peer ID: </source>
        <translation>ID du pair :</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1092"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>L&apos;agent-utilisateur HTTP est &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="531"/>
        <location filename="../base/bittorrent/session.cpp" line="1093"/>
        <source>DHT support [%1]</source>
        <translation>Prise en charge du DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="531"/>
        <location filename="../base/bittorrent/session.cpp" line="546"/>
        <location filename="../base/bittorrent/session.cpp" line="1093"/>
        <location filename="../base/bittorrent/session.cpp" line="1094"/>
        <location filename="../base/bittorrent/session.cpp" line="1095"/>
        <location filename="../base/bittorrent/session.cpp" line="1096"/>
        <location filename="../base/bittorrent/session.cpp" line="1097"/>
        <location filename="../base/bittorrent/session.cpp" line="2805"/>
        <location filename="../base/bittorrent/session.cpp" line="3351"/>
        <source>ON</source>
        <translation>ACTIVÉE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="531"/>
        <location filename="../base/bittorrent/session.cpp" line="546"/>
        <location filename="../base/bittorrent/session.cpp" line="1093"/>
        <location filename="../base/bittorrent/session.cpp" line="1094"/>
        <location filename="../base/bittorrent/session.cpp" line="1095"/>
        <location filename="../base/bittorrent/session.cpp" line="1096"/>
        <location filename="../base/bittorrent/session.cpp" line="1098"/>
        <location filename="../base/bittorrent/session.cpp" line="2805"/>
        <location filename="../base/bittorrent/session.cpp" line="3351"/>
        <source>OFF</source>
        <translation>DÉSACTIVÉE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="546"/>
        <location filename="../base/bittorrent/session.cpp" line="1094"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Découverte de pairs sur le réseau local [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1095"/>
        <source>PeX support [%1]</source>
        <translation>Support PeX [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1460"/>
        <source>Could not get GUID of network interface: %1</source>
        <translation>Impossible d&apos;obtenir le GUID de l&apos;interface réseau : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1475"/>
        <source>Trying to listen on: %1</source>
        <comment>e.g: Trying to listen on: 192.168.0.1:6881</comment>
        <translation>Tentative d&apos;écoute sur : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1626"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; a atteint le ratio maximum que vous avez défini. Retiré.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1637"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; a atteint le ratio maximum que vous avez défini. Mis en pause.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1665"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; a atteint le temps de partage maximum que vous avez défini. Supprimé.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1676"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; a atteint le temps de partage maximum que vous avez défini. Mis en pause.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2315"/>
        <source>Couldn&apos;t export torrent metadata file &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3816"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Tracker &apos;%1&apos; ajouté au torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3826"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Tracker &apos;%1&apos; retiré du torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3841"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>URL de partage &apos;%1&apos; ajoutée au torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3847"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>URL de partage &apos;%1&apos; retirée du torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4178"/>
        <location filename="../base/bittorrent/session.cpp" line="4188"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Impossible de résumer le torrent &quot;%1&quot;.</translation>
    </message>
    <message>
        <source>Couldn&apos;t load torrents queue from &apos;%1&apos;. Error: %2</source>
        <translation type="vanished">Impossible de charger la file d&apos;attente des torrents depuis &apos;%1&apos;. Motif : %2</translation>
    </message>
    <message>
        <source>Cannot read file %1: %2</source>
        <translation type="vanished">Impossible de lire le fichier %1 : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4235"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Le filtre IP a été correctement chargé : %1 règles ont été appliquées.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4245"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Erreur : impossible d&apos;analyser le filtre IP fourni.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4396"/>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation>&apos;%1&apos; restauré.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4413"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; ajouté à la liste de téléchargement.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4561"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP : impossible de rediriger le port, message : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4567"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP : la redirection du port a réussi, message : %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="185"/>
        <source>Create new torrent aborted.</source>
        <translation>Création d’un nouveau torrent annulée.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="211"/>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="220"/>
        <source>Create new torrent file failed. Reason: %1</source>
        <translation>La création du nouveau fichier torrent a échoué. Motif : %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentImpl</name>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="637"/>
        <source>Failed to add peer &quot;%1&quot; to torrent &quot;%2&quot;. Reason: %3</source>
        <translation>Échec de l&apos;ajout du pair &quot;%1&quot; au torrent &quot;%2&quot;. Motif : %3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="642"/>
        <source>Peer &quot;%1&quot; is added to torrent &quot;%2&quot;</source>
        <translation>Le pair &quot;%1&quot; est ajouté au torrent &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1008"/>
        <source>There&apos;s not enough space on disk. Torrent is currently in &quot;upload only&quot; mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1450"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation>Télécharger d&apos;abord le premier et le dernier morceau : %1, torrent : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1451"/>
        <source>On</source>
        <translation>Activé</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1451"/>
        <source>Off</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1840"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;. Cannot proceed further.</source>
        <translation>Différence de tailles de fichiers pour le torrent &quot;%1&quot;. Impossible de continuer.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1844"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Rejet des données de reprise rapide pour le torrent %1. Motif : %2. Revérification...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1894"/>
        <source>File rename failed. Torrent: &quot;%1&quot;, file: &quot;%2&quot;, reason: &quot;%3&quot;</source>
        <translation>Renommage du fichier échoué. Torrent : &quot;%1&quot;, fichier : &quot;%2&quot;, raison : &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1944"/>
        <source>Performance alert: </source>
        <translation>Alerte performance :</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Tracker</name>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="222"/>
        <source>Embedded Tracker: Now listening on IP: %1, port: %2</source>
        <translation>Tracker intégré : En écoute sur l&apos;adresse IP : %1, port : %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="227"/>
        <source>Embedded Tracker: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Tracker intégré : Impossible de se lier à l&apos;adresse IP : %1, port : %2. Raison : %3</translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="245"/>
        <source>Categories</source>
        <translation>Catégories</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="403"/>
        <source>All</source>
        <translation>Toutes</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="410"/>
        <source>Uncategorized</source>
        <translation>Non catégorisé</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="112"/>
        <source>Add category...</source>
        <translation>Ajouter catégorie ...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="120"/>
        <source>Add subcategory...</source>
        <translation>Ajouter sous catégorie ...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="124"/>
        <source>Edit category...</source>
        <translation>Éditer catégorie ...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="126"/>
        <source>Remove category</source>
        <translation>Retirer catégorie</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="130"/>
        <source>Remove unused categories</source>
        <translation>Retirer catégories inutilisées</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>Relancer torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="135"/>
        <source>Pause torrents</source>
        <translation>Mettre en pause les torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="137"/>
        <source>Delete torrents</source>
        <translation>Supprimer torrents</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Gérer les Cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Domain</source>
        <translation>Domaine</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Path</source>
        <translation>Chemin</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Value</source>
        <translation>Valeur</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="59"/>
        <source>Expiration Date</source>
        <translation>Date d&apos;expiration </translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Confirmation de suppression</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Se souvenir du choix</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="91"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Supprimer également les fichiers du disque dur</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="44"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Confirmez-vous la suppression de &apos;%1&apos; de la liste des transferts ?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="46"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Confirmez-vous le suppression des %1 torrents de la liste des transferts ?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Télécharger depuis des URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Ajouter des liens torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Un lien par ligne ( les liens HTTP, les liens Magnet et les info-hashes sont supportés)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="66"/>
        <source>Download</source>
        <translation>Télécharger</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="119"/>
        <source>No URL entered</source>
        <translation>Aucune URL saisie</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="119"/>
        <source>Please type at least one URL.</source>
        <translation>Veuillez saisir au moins une URL.</translation>
    </message>
</context>
<context>
    <name>DownloadHandlerImpl</name>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="136"/>
        <source>I/O Error</source>
        <translation>Erreur d&apos;E/S</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="154"/>
        <source>The file size (%1) exceeds the download limit (%2)</source>
        <translation>La taille du fichier (%1) excède la limite de téléchargement (%2)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="165"/>
        <source>Exceeded max redirections (%1)</source>
        <translation>Nombre maximal de redirections dépassé (%1)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="181"/>
        <source>Redirected to magnet URI</source>
        <translation>Redirigé vers l&apos;URL Magnet</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="214"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Hôte distant introuvable (nom d&apos;hôte invalide)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="216"/>
        <source>The operation was canceled</source>
        <translation>L&apos;opération a été annulée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="218"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Connexion interrompue prématurément par le serveur distant, avant la réception complète de sa réponse</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="220"/>
        <source>The connection to the remote server timed out</source>
        <translation>Délai de connexion au serveur distant expiré</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="222"/>
        <source>SSL/TLS handshake failed</source>
        <translation>La négociation SSL/TLS a échoué</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="224"/>
        <source>The remote server refused the connection</source>
        <translation>Connexion refusée par le serveur distant</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="226"/>
        <source>The connection to the proxy server was refused</source>
        <translation>La connexion au serveur mandataire a été refusée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="228"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Le serveur mandataire a fermé la connexion prématurément</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="230"/>
        <source>The proxy host name was not found</source>
        <translation>Nom d&apos;hôte du serveur mandataire introuvable</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="232"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Le délai de connexion au serveur mandataire a expiré ou le serveur n&apos;a pas répondu à temps pour la requête envoyée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="234"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>Le serveur mandataire requiert une authentification pour compléter la requête mais aucun des identifiants proposés n&apos;a été accepté</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="236"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>L&apos;accès au contenu distant a été refusé (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="238"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>L&apos;opération sur le contenu distant n&apos;est pas autorisée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="240"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Le contenu distant n&apos;a pas été trouvé sur le serveur (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="242"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Le serveur distant exige une authentification afin de distribuer le contenu mais les identifiants fournis n&apos;ont pas été acceptés</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="244"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>L&apos;API d&apos;Accès Réseau ne peut pas traiter la requête car le protocole est inconnu</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="246"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>L&apos;opération demandée est invalide pour ce protocole</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="248"/>
        <source>An unknown network-related error was detected</source>
        <translation>Une erreur inconnue relative au réseau a été détectée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="250"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Une erreur inconnue relative au serveur mandataire a été détectée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="252"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Une erreur inconnue relative au contenu distant a été détectée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="254"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Une panne dans le protocole a été détectée</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="256"/>
        <source>Unknown error</source>
        <translation>Erreur inconnue</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="192"/>
        <source>Missing pieces</source>
        <translation>Morceaux manquants</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="193"/>
        <source>Partial pieces</source>
        <translation>Morceaux partiels</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="194"/>
        <source>Completed pieces</source>
        <translation>Morceaux complets</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="36"/>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="42"/>
        <source>Blocked IPs</source>
        <translation>IPs bloquées</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="94"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="98"/>
        <source>Clear</source>
        <translation>Effacer</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="50"/>
        <source>RSS feeds</source>
        <translation>Flux RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="62"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="113"/>
        <source>Unread  (%1)</source>
        <translation>Non lu (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="184"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation>Une erreur s&apos;est produite lors de la tentative d&apos;ouvrir le fichier journal. La journalisation est désactivée.</translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="59"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="61"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Parcourir...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="63"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Choisir un fichier</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="65"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Choisir un dossier</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="104"/>
        <source>Any file</source>
        <translation>N&apos;importe quel fichier</translation>
    </message>
</context>
<context>
    <name>FileSystemWatcher</name>
    <message>
        <location filename="../base/filesystemwatcher.cpp" line="86"/>
        <source>Watching remote folder: &quot;%1&quot;</source>
        <translation>Surveillance du dossier distant : &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../base/filesystemwatcher.cpp" line="95"/>
        <source>Watching local folder: &quot;%1&quot;</source>
        <translation>Surveillance du dossier local : &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="132"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="296"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="477"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>Erreur d&apos;entrée/sortie : impossible d&apos;ouvrir le fichier de filtrage IP en lecture.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="227"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="372"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="382"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>La ligne de filtre IP %1 est mal formée.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="237"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="392"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>La ligne %1 du filtre IP est mal formée. L&apos;adresse IP de début de la plage est mal formée.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="247"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="402"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>La ligne %1 du filtre IP est mal formée. L&apos;adresse IP de la fin de la plage est malformée.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="256"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="411"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>La ligne de filtre IP %1 est malformée. Une IP est en IPv4 et l&apos;autre est en IPv6 !</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="272"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="426"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>Exception du filtrage d&apos;IP en ligne %1. Exception: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="282"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="436"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>%1 erreurs d&apos;analyse du filtre IP supplémentaires se sont produites.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="489"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="504"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="528"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="539"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="550"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="562"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="584"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Erreur d&apos;analyse : le fichier de filtrage n&apos;est pas un fichier P2B PeerGuardian valide.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="93"/>
        <location filename="../base/net/geoipdatabase.cpp" line="127"/>
        <source>Unsupported database file size.</source>
        <translation>Taille du ficher de base de données non supporté.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="236"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Erreur des métadonnées : &apos;%1&apos; non trouvé.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="237"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Erreur des métadonnées : le type de &apos;%1&apos; est invalide.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="247"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Version de base de données non supportée : %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="255"/>
        <source>Unsupported IP version: %1</source>
        <translation>Version IP non supportée : %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="263"/>
        <source>Unsupported record size: %1</source>
        <translation>Taille du registre non supportée : %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="294"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Base de données corrompue : section data introuvable.</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="73"/>
        <source>Http request size exceeds limitation, closing socket. Limit: %1, IP: %2</source>
        <translation>Taille de requête HTTP trop grande, fermeture du socket. Limite: %1, IP: %2</translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="87"/>
        <source>Bad Http request, closing socket. IP: %1</source>
        <translation>Mauvaise requête Http, fermeture du socket. IP : %1</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>Sous-réseaux IP en liste blanche</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Exemple : 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>Ajouter un sous-réseau</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="96"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="96"/>
        <source>The entered subnet is invalid.</source>
        <translation>Le sous-réseau saisi n&apos;est pas valide.</translation>
    </message>
</context>
<context>
    <name>LogPeerModel</name>
    <message>
        <location filename="../gui/log/logmodel.cpp" line="178"/>
        <source>%1 was blocked. Reason: %2.</source>
        <comment>0.0.0.0 was blocked. Reason: reason for blocking.</comment>
        <translation>%1 a été bloqué. Motif : %2.</translation>
    </message>
    <message>
        <location filename="../gui/log/logmodel.cpp" line="179"/>
        <source>%1 was banned</source>
        <comment>0.0.0.0 was banned</comment>
        <translation>%1 a été bloquée</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Édition</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>Ou&amp;tils</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Action lorsque les téléchargements sont &amp;terminés</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>A&amp;ffichage</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>&amp;Options...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>&amp;Démarrer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Créateur de torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="285"/>
        <location filename="../gui/mainwindow.ui" line="288"/>
        <source>Alternative Speed Limits</source>
        <translation>Limites de vitesse alternatives</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="296"/>
        <source>&amp;Top Toolbar</source>
        <translation>Barre d&apos;ou&amp;tils</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="299"/>
        <source>Display Top Toolbar</source>
        <translation>Afficher la barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="307"/>
        <source>Status &amp;Bar</source>
        <translation>&amp;Barre de status</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="315"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Vitesse dans le titre de la fenêtre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="318"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Afficher la vitesse dans le titre de la fenêtre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="326"/>
        <source>&amp;RSS Reader</source>
        <translation>Lecteur &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="334"/>
        <source>Search &amp;Engine</source>
        <translation>&amp;Moteur de recherche</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="339"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>&amp;Verrouiller qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="350"/>
        <source>Do&amp;nate!</source>
        <translation>Faire un do&amp;n&#x202f;!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="469"/>
        <source>Close Window</source>
        <translation>Fermer la fenêtre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>Tout Dé&amp;marrer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="421"/>
        <source>Manage Cookies...</source>
        <translation>Gérer les Cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="424"/>
        <source>Manage stored network cookies</source>
        <translation>Gérer les cookies réseau stockées</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="440"/>
        <source>Normal Messages</source>
        <translation>Messages normaux</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="448"/>
        <source>Information Messages</source>
        <translation>Messages d&apos;information</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="456"/>
        <source>Warning Messages</source>
        <translation>Messages d&apos;avertissement</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="464"/>
        <source>Critical Messages</source>
        <translation>Messages critiques</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>&amp;Journal</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Global Speed Limits...</source>
        <translation>Définir les limites de vitesse globale...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>Bottom of Queue</source>
        <translation>Bas de la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="241"/>
        <source>Move to the bottom of the queue</source>
        <translation>Déplacer en bas de la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="249"/>
        <source>Top of Queue</source>
        <translation>Haut de la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="252"/>
        <source>Move to the top of the queue</source>
        <translation>Déplacer en haut de la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="260"/>
        <source>Move Down Queue</source>
        <translation>Reculer dans la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="263"/>
        <source>Move down in the queue</source>
        <translation>Descendre dans la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="271"/>
        <source>Move Up Queue</source>
        <translation>Avancer dans la queue</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="274"/>
        <source>Move up in the queue</source>
        <translation>Remonter dans la file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="361"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Quitter qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="369"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Mettre en veille le système</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="377"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Mettre en veille prolongée le système</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="385"/>
        <source>S&amp;hutdown System</source>
        <translation>É&amp;teindre le système</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="393"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Désactivé</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="408"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Statistiques</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="413"/>
        <source>Check for Updates</source>
        <translation>Vérifier les mises à jour</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="416"/>
        <source>Check for Program Updates</source>
        <translation>Vérifier les mises à jour du programm</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>&amp;À propos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>Mettre en &amp;pause</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>&amp;Supprimer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>Tout &amp;mettre en pause</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Ajouter un fichier torrent…</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>Ouvrir URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentation</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>Lock</source>
        <translation>Verrouiller</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="398"/>
        <location filename="../gui/mainwindow.ui" line="432"/>
        <location filename="../gui/mainwindow.cpp" line="1752"/>
        <source>Show</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1924"/>
        <source>Check for program updates</source>
        <translation>Vérifier la disponibilité de mises à jour du logiciel</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Ajouter &amp;lien vers un torrent…</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="353"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si vous aimez qBittorrent, faites un don !</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2002"/>
        <location filename="../gui/mainwindow.cpp" line="2004"/>
        <source>Execution Log</source>
        <translation>Journal d&apos;exécution</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="663"/>
        <source>Clear the password</source>
        <translation>Effacer le mot de passe</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="196"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Définir le mot de pass</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="167"/>
        <source>Preferences</source>
        <translation>Préférences</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="197"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Supprimer le mot de pass</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="222"/>
        <source>Filter torrent names...</source>
        <translation>Filtrer les noms des torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="248"/>
        <source>Transfers</source>
        <translation>Transferts</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="419"/>
        <location filename="../gui/mainwindow.cpp" line="1298"/>
        <source>qBittorrent is minimized to tray</source>
        <translation>qBittorrent est en mode réduit dans la boîte à miniatures</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="419"/>
        <location filename="../gui/mainwindow.cpp" line="1198"/>
        <location filename="../gui/mainwindow.cpp" line="1298"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation>Ce comportement peut être modifié dans les réglages. Il n&apos;y aura plus de rappel.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <source>Torrent file association</source>
        <translation>Association aux fichiers torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="464"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent n&apos;est pas l&apos;application par défaut utilisée pour ouvrir les fichiers torrent ou les liens magnet.
Voulez-vous associer qBittorrent aux fichiers torrent et liens magnet&#xa0;?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="561"/>
        <source>Icons Only</source>
        <translation>Icônes seulement</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="562"/>
        <source>Text Only</source>
        <translation>Texte seulement</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="563"/>
        <source>Text Alongside Icons</source>
        <translation>Texte à côté des Icônes</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="564"/>
        <source>Text Under Icons</source>
        <translation>Texte sous les Icônes</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="565"/>
        <source>Follow System Style</source>
        <translation>Suivre le style du système</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="646"/>
        <location filename="../gui/mainwindow.cpp" line="1051"/>
        <source>UI lock password</source>
        <translation>Mot de passe de verrouillage</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <location filename="../gui/mainwindow.cpp" line="1052"/>
        <source>Please type the UI lock password:</source>
        <translation>Veuillez entrer le mot de passe de verrouillage :</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <source>The password should contain at least 3 characters</source>
        <translation>The mot de passe doit contenir au moins 3 caractères</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="664"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Êtes vous sûr de vouloir effacer le mot de passe&#x202f;?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="723"/>
        <source>Use regular expressions</source>
        <translation>Utiliser les expressions régulières</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="745"/>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="762"/>
        <source>Transfers (%1)</source>
        <translation>Transferts (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="861"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="861"/>
        <source>Failed to add torrent: %1</source>
        <translation>Échec de l&apos;ajout du torrent&#x202f;: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="868"/>
        <source>Torrent added</source>
        <translation>Torrent ajouté</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="868"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; a été ajouté.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="874"/>
        <source>Download completion</source>
        <translation>Fin du téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="880"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Erreur E/S</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="975"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmation pour téléchargement récursif</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="981"/>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="982"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="983"/>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1074"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent vient d&apos;être mis à jour et doit être redémarré pour que les changements soient pris en compte.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1198"/>
        <source>qBittorrent is closed to tray</source>
        <translation>qBittorrent est dans la boîte à miniatures</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1213"/>
        <source>Some files are currently transferring.</source>
        <translation>Certains fichiers sont en cours de transfert.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1213"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Êtes-vous sûr de vouloir quitter qBittorrent ?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1215"/>
        <source>&amp;No</source>
        <translation>&amp;Non</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1216"/>
        <source>&amp;Yes</source>
        <translation>&amp;Oui</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1217"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Oui, toujours</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1626"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1861"/>
        <location filename="../gui/mainwindow.cpp" line="1867"/>
        <source>Missing Python Runtime</source>
        <translation>L’exécutable Python est manquant </translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1888"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 3.3.0.</source>
        <translation>Votre version de Python (%1) est dépassée. Veuillez mettre à jour vers la dernière version pour que les moteurs de recherche fonctionnent.
Version minimum requise : 3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1939"/>
        <source>qBittorrent Update Available</source>
        <translation>Mise à jour de qBittorrent disponible</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="874"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Le téléchargement de «&#x202f;%1&#x202f;» est terminé.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="881"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Une erreur d&apos;entrée/sortie est survenue sur le torrent «&#x202f;%1&#x202f;».
Raison&#x202f;: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="976"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Le torrent «&#x202f;%1&#x202f;» contient des fichiers torrent, voulez-vous procéder en les téléchargeant&#x202f;?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="998"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Impossible de télécharger le fichier à l&apos;adresse «&#x202f;%1&#x202f;», raison&#x202f;: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1862"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python est nécessaire afin d&apos;utiliser le moteur de recherche mais il ne semble pas être installé.
Voulez-vous l&apos;installer maintenant&#x202f;?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1868"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Python est nécessaire afin d&apos;utiliser le moteur de recherche mais il ne semble pas être installé.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1880"/>
        <location filename="../gui/mainwindow.cpp" line="1887"/>
        <source>Old Python Runtime</source>
        <translation>L&apos;exécutable Python est dépassé</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1881"/>
        <source>Your Python version (%1) is outdated. Minimum requirement: 3.5.0.
Do you want to install a newer version now?</source>
        <translation>Votre version de Python (%1) est dépassée. Version minimum requise : 3.5.0. Souhaitez-vous installer une version plus récente maintenant ?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1936"/>
        <source>A new version is available.</source>
        <translation>Une nouvelle version est disponible.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1937"/>
        <source>Do you want to download %1?</source>
        <translation>Voulez-vous télécharger %1 ?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1938"/>
        <source>Open changelog...</source>
        <translation>Ouvrir le journal des modifications...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1959"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Pas de mises à jour disponibles.
Vous utilisez déjà la dernière version.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1923"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Vérifier les mises à jour</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2134"/>
        <source>Checking for Updates...</source>
        <translation>Vérification des mises à jour…</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2135"/>
        <source>Already checking for program updates in the background</source>
        <translation>Recherche de mises à jour déjà en cours en tâche de fond</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2168"/>
        <source>Download error</source>
        <translation>Erreur de téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2169"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>L’installateur Python ne peut pas être téléchargé pour la raison suivante : %1.
Veuillez l’installer manuellement.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <location filename="../gui/mainwindow.cpp" line="1060"/>
        <source>Invalid password</source>
        <translation>Mot de passe invalide</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="689"/>
        <location filename="../gui/mainwindow.cpp" line="702"/>
        <location filename="../gui/mainwindow.cpp" line="704"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="997"/>
        <source>URL download error</source>
        <translation>Erreur de téléchargement URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1060"/>
        <source>The password is invalid</source>
        <translation>Le mot de passe fourni est invalide</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1637"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vitesse de réception : %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1638"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vitesse d&apos;envoi : %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1645"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[R&#xa0;: %1, E&#xa0;: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1752"/>
        <source>Hide</source>
        <translation>Cacher</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1211"/>
        <source>Exiting qBittorrent</source>
        <translation>Fermeture de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1429"/>
        <source>Open Torrent Files</source>
        <translation>Ouvrir fichiers torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1430"/>
        <source>Torrent Files</source>
        <translation>Fichiers torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1485"/>
        <source>Options were saved successfully.</source>
        <translation>Préférences sauvegardées avec succès.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="185"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>Votre DNS dynamique a été mis à jour avec succès.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="191"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Le service est temporairement indisponible, un nouvel essai sera fait dans 30 minutes.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="202"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Le nom d&apos;hôte fourni n&apos;existe pas pour le compte spécifié.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Nom d&apos;utilisateur ou mot de passe invalide.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="216"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erreur de DNS dynamique&#x202f;: qBittorrent a été blacklisté par le service, veuillez rapporter un bogue sur http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="224"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erreur de DNS dynamique&#x202f;: %1 a été retourné par le service, veuillez rapporter un bogue sur http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="232"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Votre nom d&apos;utilisateur a été bloqué pour faute d&apos;abus.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="255"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Le nom de domaine fourni est invalide.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="268"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Le nom d&apos;utilisateur fourni est trop court.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="281"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Erreur de DNS dynamique&#x202f;: Le mot de passe fourni est trop court.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadManager</name>
    <message>
        <location filename="../base/net/downloadmanager.cpp" line="296"/>
        <source>Ignoring SSL error, URL: &quot;%1&quot;, errors: &quot;%2&quot;</source>
        <translation>Erreur SSL ignorée, URL : &quot;%1&quot;, erreurs : &quot;%2&quot;</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela, République bolivarienne du</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="399"/>
        <location filename="../base/net/geoipmanager.cpp" line="402"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Andorra</source>
        <translation>Andorre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="97"/>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>IP geolocation database loaded. Type: %1. Build time: %2.</source>
        <translation>Base de données GeoIP chargée. Type&#x202f;: %1. Durée de construction&#x202f;: %2</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="101"/>
        <location filename="../base/net/geoipmanager.cpp" line="467"/>
        <source>Couldn&apos;t load IP geolocation database. Reason: %1</source>
        <translation>Impossible de charger la base de données de géolocalisation des IPs. Motif&#x202f;: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>United Arab Emirates</source>
        <translation>Émirats Arabes Unis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Afghanistan</source>
        <translation>Afghanistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua-et-Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Albania</source>
        <translation>Albanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Armenia</source>
        <translation>Arménie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Antarctica</source>
        <translation>Antarctique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Argentina</source>
        <translation>Argentine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>American Samoa</source>
        <translation>Samoa Américaines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Austria</source>
        <translation>Autriche</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Australia</source>
        <translation>Australie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Azerbaijan</source>
        <translation>Azerbaïdjan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosnie Herzégovine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Barbados</source>
        <translation>Barbade</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Belgium</source>
        <translation>Belgique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bulgaria</source>
        <translation>Bulgarie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bahrain</source>
        <translation>Bahreïn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Benin</source>
        <translation>Bénin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bermuda</source>
        <translation>Bermudes</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Brazil</source>
        <translation>Brésil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Bhutan</source>
        <translation>Bhoutan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Bouvet Island</source>
        <translation>Île Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Belarus</source>
        <translation>Biélorussie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Belize</source>
        <translation>Bélize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Canada</source>
        <translation>Canada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Îles Cocos (anciennement Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>République Démocratique du Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Central African Republic</source>
        <translation>République d&apos;Afrique Centrale</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Switzerland</source>
        <translation>Suiss</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Cook Islands</source>
        <translation>Îles Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Chile</source>
        <translation>Chili</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cameroon</source>
        <translation>Cameroun</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>China</source>
        <translation>Chine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Colombia</source>
        <translation>Colombie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Cape Verde</source>
        <translation>Cap-Vert</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Curacao</source>
        <translation>Curaçao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Christmas Island</source>
        <translation>Île Christmas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Cyprus</source>
        <translation>Chypre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Czech Republic</source>
        <translation>République Tchèque</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Germany</source>
        <translation>Allemagne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Denmark</source>
        <translation>Danemark</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Dominica</source>
        <translation>Dominique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Dominican Republic</source>
        <translation>République dominicaine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Algeria</source>
        <translation>Algérie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Ecuador</source>
        <translation>Equateur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Estonia</source>
        <translation>Estonie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Egypt</source>
        <translation>Égypte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Western Sahara</source>
        <translation>Sahara occidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Eritrea</source>
        <translation>Érythrée</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Spain</source>
        <translation>Espagn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Ethiopia</source>
        <translation>Éthiopie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>Finland</source>
        <translation>Finlande</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Fiji</source>
        <translation>Fidji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Îles Malouines (Falkland)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Micronesia, Federated States of</source>
        <translation>Micronésie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Faroe Islands</source>
        <translation>Îles Féroé</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>France</source>
        <translation>France</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>United Kingdom</source>
        <translation>Royaume-uni</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Grenada</source>
        <translation>Grenade</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Georgia</source>
        <translation>Géorgie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>French Guiana</source>
        <translation>Guinée française</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greenland</source>
        <translation>Groënland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Gambia</source>
        <translation>Gambie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guinea</source>
        <translation>Guinée</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guadeloupe</source>
        <translation>Guadeloupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Equatorial Guinea</source>
        <translation>Guinée équatoriale</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Greece</source>
        <translation>Grèce</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Géorgie du Sud-et-les Îles Sandwich du Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Guinea-Bissau</source>
        <translation>Guinée-Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Guyana</source>
        <translation>Guyane</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Îles Heard-et-MacDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Croatia</source>
        <translation>Croatie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Haiti</source>
        <translation>Haïti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>Hungary</source>
        <translation>Hongrie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Indonesia</source>
        <translation>Indonésie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Ireland</source>
        <translation>Irlande</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Israel</source>
        <translation>Israël</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>India</source>
        <translation>Inde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>British Indian Ocean Territory</source>
        <translation>Territoire britannique de l&apos;océan Indien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Iran, Islamic Republic of</source>
        <translation>République islamique d&apos;Iran</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Iceland</source>
        <translation>Islande</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Italy</source>
        <translation>Italie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Jamaica</source>
        <translation>Jamaïque</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Jordan</source>
        <translation>Jordanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Japan</source>
        <translation>Japon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Kyrgyzstan</source>
        <translation>Kirghizstan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Cambodia</source>
        <translation>Cambodge</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Comoros</source>
        <translation>Comores</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Saint-Christophe-et-Niévès</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Corée du Nord</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Korea, Republic of</source>
        <translation>Corée du Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Kuwait</source>
        <translation>Koweït</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Cayman Islands</source>
        <translation>Îles Caïmans</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lebanon</source>
        <translation>Liban</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Saint Lucia</source>
        <translation>Sainte-Lucie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Lithuania</source>
        <translation>Lituanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Luxembourg</source>
        <translation>Luxembourg</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Latvia</source>
        <translation>Lettonie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Morocco</source>
        <translation>Maroc</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Monaco</source>
        <translation>Monaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Moldova, Republic of</source>
        <translation>Moldavie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Marshall Islands</source>
        <translation>Îles Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Myanmar</source>
        <translation>Birmanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Mongolia</source>
        <translation>Mongolie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Northern Mariana Islands</source>
        <translation>Îles Mariannes du Nord</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Martinique</source>
        <translation>Martinique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Mauritania</source>
        <translation>Mauritanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malta</source>
        <translation>Malte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mauritius</source>
        <translation>Maurice</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Maldives</source>
        <translation>Maldives</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Mexico</source>
        <translation>Mexique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Malaysia</source>
        <translation>Malaisie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Mozambique</source>
        <translation>Mozambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Namibia</source>
        <translation>Namibie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>New Caledonia</source>
        <translation>Nouvelle-Calédonie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Norfolk Island</source>
        <translation>Île Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Netherlands</source>
        <translation>Pays-Bas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Norway</source>
        <translation>Norvège</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Nepal</source>
        <translation>Népal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>New Zealand</source>
        <translation>Nouvelle-Zélande</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Peru</source>
        <translation>Pérou</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>French Polynesia</source>
        <translation>Polynésie française</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Papua New Guinea</source>
        <translation>Papouasie - Nouvelle-Guinée</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Philippines</source>
        <translation>Philippines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Poland</source>
        <translation>Pologne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint Pierre et Miquelon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Reunion</source>
        <translation>Réunion</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Romania</source>
        <translation>Roumanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Russian Federation</source>
        <translation>Russie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Saudi Arabia</source>
        <translation>Arabie Saoudite</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Solomon Islands</source>
        <translation>Îles Salomon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Sudan</source>
        <translation>Soudan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Sweden</source>
        <translation>Suède</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Singapore</source>
        <translation>Singapour</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Slovenia</source>
        <translation>Slovénie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard et Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Slovakia</source>
        <translation>Slovaquie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>San Marino</source>
        <translation>Saint-Marin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Senegal</source>
        <translation>Sénégal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Somalia</source>
        <translation>Somalie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Sao Tome and Principe</source>
        <translation>Sao Tomé-et-Principe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Syrian Arab Republic</source>
        <translation>Syrie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Swaziland</source>
        <translation>Swaziland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Turks and Caicos Islands</source>
        <translation>Îles Turques-et-Caïques</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Chad</source>
        <translation>Tchad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>French Southern Territories</source>
        <translation>Terres australes françaises</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Thailand</source>
        <translation>Thaïlande</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tajikistan</source>
        <translation>Tadjikistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Turkmenistan</source>
        <translation>Turkménistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Tunisia</source>
        <translation>Tunisie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Vietnam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="427"/>
        <source>Couldn&apos;t download IP geolocation database file. Reason: %1</source>
        <translation>Impossible de télécharger la base de données de géolocalisation des IPs. Motif&#x202f;: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="435"/>
        <source>Could not decompress IP geolocation database file.</source>
        <translation>Impossible de décompresser la base de données de géolocalisation des IPs.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="456"/>
        <source>Couldn&apos;t save downloaded IP geolocation database file.</source>
        <translation>Impossible d&apos;enregistrer la base de données de géolocalisation des IPs téléchargée.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="458"/>
        <source>Successfully updated IP geolocation database.</source>
        <translation>La base de données de géolocalisation des IPs a été mise à jour avec succès.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Timor-Leste</source>
        <translation>Timor Oriental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolivie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Pays-Bas caribéens - Bonaire, St Eustatius, Saba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Côte d&apos;Ivoire</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Libya</source>
        <translation>Libye</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Saint Martin (French part)</source>
        <translation>Saint-Martin (France)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macédoine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Pitcairn</source>
        <translation>Îles Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Palestine, State of</source>
        <translation>Palestine, État de</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Sainte-Hélène, Ascension et Tristan da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>South Sudan</source>
        <translation>Soudan du Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Saint-Martin (Pays-bas)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Turkey</source>
        <translation>Turquie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad et Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzanie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Ukraine</source>
        <translation>Ukraine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Uganda</source>
        <translation>Ouganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Îles mineures éloignées des États-Unis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>United States</source>
        <translation>États-Unis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Uzbekistan</source>
        <translation>Ouzbékistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Vatican</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>Saint-Vincent-et-les-Grenadines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Virgin Islands, British</source>
        <translation>Îles Vierges, Royaume-Uni</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Îles Vierges, États-Unis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis et Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="393"/>
        <source>Yemen</source>
        <translation>Yémen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Serbia</source>
        <translation>Serbie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="395"/>
        <source>South Africa</source>
        <translation>Afrique du Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="396"/>
        <source>Zambia</source>
        <translation>Zambie</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Montenegro</source>
        <translation>Monténégro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="397"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Aland Islands</source>
        <translation>Åland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guernsey</source>
        <translation>Bailliage de Guernesey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Isle of Man</source>
        <translation>Île de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Saint Barthelemy</source>
        <translation>Saint-Barthélemy</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="566"/>
        <source>Email Notification Error:</source>
        <translation>Erreur de notification e-mail :</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>Comportement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>Téléchargements</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>Connexion</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>Vitesse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>Interface web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avancé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="219"/>
        <source>Transfer List</source>
        <translation>Liste des transferts</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="228"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmer la suppression des torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="238"/>
        <source>Use alternating row colors</source>
        <extracomment>In table elements, every other row will have a grey background.</extracomment>
        <translation>Alterner la couleur des lignes</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="250"/>
        <source>Hide zero and infinity values</source>
        <translation>Cacher les valeurs zéro et infini</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="258"/>
        <source>Always</source>
        <translation>Toujours</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="263"/>
        <source>Paused torrents only</source>
        <translation>Seulement les torrents en pause</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="286"/>
        <source>Action on double-click</source>
        <translation>Action du double-clic</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="292"/>
        <source>Downloading torrents:</source>
        <translation>Torrents en téléchargement:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="303"/>
        <location filename="../gui/optionsdialog.ui" line="329"/>
        <source>Start / Stop Torrent</source>
        <translation>Démarrer / Arrêter le torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="308"/>
        <location filename="../gui/optionsdialog.ui" line="334"/>
        <source>Open destination folder</source>
        <translation>Ouvrir le répertoire de destination</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="313"/>
        <location filename="../gui/optionsdialog.ui" line="344"/>
        <source>No action</source>
        <translation>Aucune action</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="321"/>
        <source>Completed torrents:</source>
        <translation>Torrents téléchargés:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="371"/>
        <source>Desktop</source>
        <translation>Bureau</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="377"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Démarrer qBittorrent au démarrage de windows</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="384"/>
        <source>Show splash screen on start up</source>
        <translation>Afficher l&apos;écran de démarrage</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="397"/>
        <source>Start qBittorrent minimized</source>
        <translation>Démarrer qBittorrent en mode réduit</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="407"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmer la fermeture lorsque des torrents sont actifs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="417"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Confirmation de l&apos;auto-extinction à la fin des téléchargements</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="605"/>
        <source> KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="776"/>
        <source>Torrent content layout:</source>
        <translation>Agencement du contenu du torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="787"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="792"/>
        <source>Create subfolder</source>
        <translation>Créer un sous-dossier</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="797"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Ne pas créer de sous-dossier</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1225"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>Notification par e-mail &amp;de fin de téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1326"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Lancer un programme e&amp;xterne à la fin d&apos;un téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1395"/>
        <source>Peer connection protocol:</source>
        <translation>Protocole de connexion au pair :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1789"/>
        <source>IP Fi&amp;ltering</source>
        <translation>Fi&amp;ltrage IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1989"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Planifier &amp;l&apos;utilisation des limites de vitesse alternatives</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2004"/>
        <source>From:</source>
        <comment>From start time</comment>
        <translation>Depuis :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2031"/>
        <source>To:</source>
        <comment>To end time</comment>
        <translation>Vers :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2236"/>
        <source>Find peers on the DHT network</source>
        <translation>Trouver des pairs sur le réseau DHT</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2284"/>
        <source>Allow encryption: Connect to peers regardless of setting
Require encryption: Only connect to peers with protocol encryption
Disable encryption: Only connect to peers without protocol encryption</source>
        <translation>Autoriser le chiffrement : Se connecter aux pairs indépendamment de la configuration
Exiger le chiffrement : Se connecter uniquement aux pairs avec protocole de chiffrement 
Désactiver le chiffrement : Se connecter uniquement aux pairs sans protocole de chiffrement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2290"/>
        <source>Allow encryption</source>
        <translation>Autoriser le chiffrement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2335"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Plus d&apos;informations&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2363"/>
        <source>&amp;Torrent Queueing</source>
        <translation>Priorisation des &amp;torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2656"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>Ajo&amp;uter automatiquement ces trackers aux nouveaux téléchargements&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2729"/>
        <source>RSS Reader</source>
        <translation>Lecteur RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2735"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Active la réception de flux RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2744"/>
        <source>Feeds refresh interval:</source>
        <translation>Intervalle de rafraîchissement des flux :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2761"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Nombre maximum d&apos;articles par flux :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2560"/>
        <location filename="../gui/optionsdialog.ui" line="2768"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation>min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2551"/>
        <source>Seeding Limits</source>
        <translation>Limites d&apos;émission</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2573"/>
        <source>When seeding time reaches</source>
        <translation>Lorsque la durée d&apos;émission atteint</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2594"/>
        <source>Pause torrent</source>
        <translation>Mettre en pause le torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2599"/>
        <source>Remove torrent</source>
        <translation>Supprimer le torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2604"/>
        <source>Remove torrent and its files</source>
        <translation>Supprimer le torrent et ses fichiers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2609"/>
        <source>Enable super seeding for torrent</source>
        <translation>Activer le super-partage pour ce torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2617"/>
        <source>When ratio reaches</source>
        <translation>Lorsque le ratio atteint</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2802"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Téléchargeur automatique de torrent RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2808"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Active le téléchargement automatique des torrents par RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2815"/>
        <source>Edit auto downloading rules...</source>
        <translation>Éditer les règles de téléchargement automatique...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2825"/>
        <source>RSS Smart Episode Filter</source>
        <translation>Filtre d&apos;épisode intelligent RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2831"/>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Télécharger les épisodes REPACK / PROPER</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2838"/>
        <source>Filters:</source>
        <translation>Filtres :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2899"/>
        <source>Web User Interface (Remote control)</source>
        <translation>Interface Web de l&apos;utilisateur (contrôle distant)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2913"/>
        <source>IP address:</source>
        <translation>Adresse IP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2920"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>L&apos;adresse IP à laquelle l&apos;UI Web sera ratachée.
Renseignez une adresse IPv4 ou IPv6. Vous pouvez renseigner &quot;0.0.0.0&quot; pour n&apos;importe quelle adresse IPv4,
&quot;::&quot; pour n&apos;importe quelle adresse IPv6, ou bien &quot;*&quot; pour l&apos;IPv4 et l&apos;IPv6.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3078"/>
        <source>Ban client after consecutive failures:</source>
        <translation>Bloquer le client suite à des échecs consécutifs :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3098"/>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3108"/>
        <source>ban for:</source>
        <translation>Bloquer pour :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3135"/>
        <source>Session timeout:</source>
        <translation>Expiration de la session :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3142"/>
        <source>Disabled</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3218"/>
        <source>Enable cookie Secure flag (requires HTTPS)</source>
        <translation>Activer le cookie Secure flag (nécessite HTTPS)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3236"/>
        <source>Server domains:</source>
        <translation>Domaines de serveur :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3243"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>Liste blanche pour le filtrage des valeurs d&apos;en-tête de l&apos;hôte HTTP.
Afin de se défendre contre les attaques par DNS rebinding, vous devez consigner les noms de domaine utilisés par le serveur WebUI.

Utiliser &apos;;&apos; pour diviser plusieurs entrées. Le caractère générique &apos;*&apos; peut être utilisé.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2961"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>&amp;Utiliser HTTPS au lieu de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3049"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Ignorer l&apos;authentification pour les clients locaux</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3056"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Ignorer l&apos;authentification pour les clients de sous-réseaux en liste blanche</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3069"/>
        <source>IP subnet whitelist...</source>
        <translation>Liste blanche de sous-réseaux IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3284"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>Met&amp;tre à jour mon nom de domaine dynamique</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="439"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Réduire qBittorrent dans la zone de notification</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="174"/>
        <source>Language:</source>
        <translation>Langue:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="461"/>
        <source>Tray icon style:</source>
        <translation>Style de l&apos;icône :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="469"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="505"/>
        <source>File association</source>
        <translation>Association des fichiers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="511"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Utiliser qBittorrent pour les fichiers .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="518"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Utiliser qBittorrent pour les liens magnet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="528"/>
        <source>Check for program updates</source>
        <translation>Vérifier la disponibilité de mises à jour du logiciel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="538"/>
        <source>Power Management</source>
        <translation>Gestion d&apos;alimentation</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="581"/>
        <source>Save path:</source>
        <translation>Chemin de sauvegarde :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="598"/>
        <source>Backup the log file after:</source>
        <translation>Sauvegarder le Log après :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="638"/>
        <source>Delete backup logs older than:</source>
        <translation>Supprimer les Logs âgés plus de : </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="746"/>
        <source>When adding a torrent</source>
        <translation>À l&apos;ajout d&apos;un torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="761"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Mettre la boite de dialogue du torrent en avant-plan</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="830"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>Faut-il supprimer le .torrent après l&apos;avoir ajouté</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="845"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>Supprimer également les fichiers .torrent dont l&apos;ajout a été annulé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="848"/>
        <source>Also when addition is cancelled</source>
        <translation>Aussi quand l&apos;ajout est annulé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="870"/>
        <source>Warning! Data loss possible!</source>
        <translation>Attention ! Perte de donnée possible !</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="912"/>
        <source>Saving Management</source>
        <translation>Gestion de Sauvegarde</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="920"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Mode de gestion de torrent par défaut :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="937"/>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="942"/>
        <source>Automatic</source>
        <translation>Automatique</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="965"/>
        <source>When Torrent Category changed:</source>
        <translation>Lorsque la catégorie du Torrent a changé :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="975"/>
        <source>Relocate torrent</source>
        <translation>Relocaliser le torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="980"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Basculer le torrent en mode manuel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1003"/>
        <source>When Default Save Path changed:</source>
        <translation>Lorsque le chemin de sauvegarde par défaut a changé :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1016"/>
        <location filename="../gui/optionsdialog.ui" line="1057"/>
        <source>Relocate affected torrents</source>
        <translation>Relocaliser les torrents affectés</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1021"/>
        <location filename="../gui/optionsdialog.ui" line="1062"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Basculer les torrents affectés en mode manuel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1087"/>
        <source>Use Subcategories</source>
        <translation>Utiliser les sous-catégories</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1106"/>
        <source>Default Save Path:</source>
        <translation>Chemin de sauvegarde par défaut :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1120"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Conserver les torrents incomplets dans&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1113"/>
        <source>Copy .torrent files to:</source>
        <translation>Copier les fichiers .torrent dans :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="427"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Afficher l&apos;icône de &amp;qBittorrent dans la zone de notification</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="561"/>
        <source>&amp;Log file</source>
        <translation>Fichier de &amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="752"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Afficher le contenu du &amp;torrent et quelques options</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="833"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>Supprimer &amp;les fichiers .torrent par la suite</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1099"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copier les fichiers .torrent des téléchargements terminés dans :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="888"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pré-allouer l&apos;espace disque pour tous les fichiers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="139"/>
        <source>Use custom UI Theme</source>
        <translation>Utiliser un thème d&apos;interface personnalisé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="148"/>
        <source>UI Theme file:</source>
        <translation>Fichier du thème de l&apos;Interface Utilisateur</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="181"/>
        <source>Use system icon theme</source>
        <translation>Utiliser le thème d&apos;icônes du système</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="209"/>
        <source>Changing Interface settings requires application restart</source>
        <translation>Changer des paramètres de l&apos;interface requiert un redémarrage de l&apos;application</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="225"/>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Afficher une fenêtre de confirmation lors de la suppression d&apos;un torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="339"/>
        <source>Preview file, otherwise open destination folder</source>
        <translation>Afficher un aperçu du fichier, sinon ouvrir le dossier de destination</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="394"/>
        <source>When qBittorrent is started, the main window will be minimized</source>
        <translation>Lorsque qBittorrent démarre, la fenêtre principale est réduite</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="404"/>
        <source>Shows a confirmation dialog when exiting with active torrents</source>
        <translation>Affiche une fenêtre de confirmation lors de la fermeture avec des torrents actifs.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="436"/>
        <source>When minimizing, the main window is closed and must be reopened from the systray icon</source>
        <translation>En réduisant, la fenêtre principale sera fermée et devra être réouverte par l&apos;icône de la barre système.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="449"/>
        <source>The systray icon will still be visible when closing the main window</source>
        <translation>L&apos;icône de la barre système restera visible lorsque la fenêtre principale sera fermée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="452"/>
        <source>Close qBittorrent to notification area</source>
        <extracomment>The systray icon will still be visible when closing the main window</extracomment>
        <translation>Conserver dans la zone de notification à la fermeture</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="474"/>
        <source>Monochrome (for dark theme)</source>
        <translation>Monochrome (pour le thème sombre)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="479"/>
        <source>Monochrome (for light theme)</source>
        <translation>Monochrome (pour le thème clair)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="544"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation>Empêcher la mise en veille du système lorsque des torrents sont en téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="551"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation>Empêcher la mise en veille du système lorsque des torrents sont en émission</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="595"/>
        <source>Creates an additional log file after the log file reaches the specified file size</source>
        <translation>Génère un fichier journal supplémentaire lorsque le fichier journal atteint la taille spécifiée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="662"/>
        <source>days</source>
        <extracomment>Delete backup logs older than 10 days</extracomment>
        <translation>jours</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="667"/>
        <source>months</source>
        <extracomment>Delete backup logs older than 10 months</extracomment>
        <translation>mois</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="672"/>
        <source>years</source>
        <extracomment>Delete backup logs older than 10 years</extracomment>
        <translation>années</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="820"/>
        <source>The torrent will be added to download list in a paused state</source>
        <translation>Le torrent sera ajouté à la file de téléchargement en état de pause</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="823"/>
        <source>Do not start the download automatically</source>
        <extracomment>The torrent will be added to download list in a paused state</extracomment>
        <translation>Ne pas démarrer le téléchargement automatiquement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="885"/>
        <source>Allocate full file sizes on disk before starting downloads, to minimize fragmentation. Only useful for HDDs.</source>
        <translation>Allouer les tailles entières des fichiers sur le disque avant de commencer les téléchargements, afin de minimiser la fragmentation. Utile uniquement pour les disques durs HDDs.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="895"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Ajouter l&apos;extension .!qB aux noms des fichiers incomplets</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="902"/>
        <source>When a torrent is downloaded, offer to add torrents from any .torrent files found inside it</source>
        <translation>Lorsqu&apos;un torrent est téléchargé, proposer d&apos;ajouter les torrents depuis les fichiers .torrent trouvés à l&apos;intérieur de celui-ci</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="905"/>
        <source>Enable recursive download dialog</source>
        <translation>Activer les fenêtres de téléchargement récursif</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="932"/>
        <source>Automatic: Various torrent properties (e.g. save path) will be decided by the associated category
Manual: Various torrent properties (e.g. save path) must be assigned manually</source>
        <translation>Automatique : Certaines propriétés du torrent (ex: le dossier d&apos;enregistrement) seront décidées via la catégorie associée
Manuel : Certaines propriétés du torrent (ex: le dossier d&apos;enregistrement) devront être saisies manuellement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1044"/>
        <source>When Category Save Path changed:</source>
        <translation>Lorsque le chemin d&apos;enregistrement de catégorie change :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1141"/>
        <source>Automatically add torrents from:</source>
        <translation>Ajouter automatiquement les torrents présents dans :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1188"/>
        <source>Add entry</source>
        <translation>Ajouter une entrée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1198"/>
        <source>Remove entry</source>
        <translation>Supprimer une entrée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1242"/>
        <source>Receiver</source>
        <translation>Destinataire</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1245"/>
        <source>To:</source>
        <comment>To receiver</comment>
        <translation>A :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1252"/>
        <source>SMTP server:</source>
        <translation>Serveur SMTP :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1265"/>
        <source>Sender</source>
        <translation>Émetteur</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1268"/>
        <source>From:</source>
        <comment>From sender</comment>
        <translation>De :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1277"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Ce serveur nécessite une connexion sécurisée (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1284"/>
        <location filename="../gui/optionsdialog.ui" line="3012"/>
        <source>Authentication</source>
        <translation>Authentification</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1296"/>
        <location filename="../gui/optionsdialog.ui" line="1750"/>
        <location filename="../gui/optionsdialog.ui" line="3020"/>
        <location filename="../gui/optionsdialog.ui" line="3342"/>
        <source>Username:</source>
        <translation>Nom d&apos;utilisateur :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1306"/>
        <location filename="../gui/optionsdialog.ui" line="1760"/>
        <location filename="../gui/optionsdialog.ui" line="3030"/>
        <location filename="../gui/optionsdialog.ui" line="3356"/>
        <source>Password:</source>
        <translation>Mot de passe :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1341"/>
        <source>Show console window</source>
        <translation>Afficher la fenêtre console</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1403"/>
        <source>TCP and μTP</source>
        <translation>TCP et μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1436"/>
        <source>Listening Port</source>
        <translation>Port d&apos;écoute</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1444"/>
        <source>Port used for incoming connections:</source>
        <translation>Port pour les connexions entrantes :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1464"/>
        <source>Random</source>
        <translation>Aléatoire</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1486"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Utiliser la redirection de port sur mon routeur via UPnP / NAT-PMP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1496"/>
        <source>Use different port on each startup</source>
        <translation>Utiliser un port différent à chaque démarrage</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1506"/>
        <source>Connections Limits</source>
        <translation>Limites de connexions</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1522"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Nombre maximum de connexions par torrent :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1532"/>
        <source>Global maximum number of connections:</source>
        <translation>Nombre maximum global de connexions :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1571"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Nombre maximum d&apos;emplacements d&apos;envoi par torrent :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1581"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Nombre maximum global d&apos;emplacements d&apos;envoi :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1620"/>
        <source>Proxy Server</source>
        <translation>Serveur mandataire (proxy)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1628"/>
        <source>Type:</source>
        <translation>Type :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1636"/>
        <source>(None)</source>
        <translation>(Aucun)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1641"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1646"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1651"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1662"/>
        <source>Host:</source>
        <translation>Hôte :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1682"/>
        <location filename="../gui/optionsdialog.ui" line="2929"/>
        <source>Port:</source>
        <translation>Port :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1710"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Dans le cas contraire, le proxy sera uniquement utilisé pour contacter les trackers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1713"/>
        <source>Use proxy for peer connections</source>
        <translation>Utiliser le serveur mandataire pour se connecter aux utilisateurs (pairs)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1720"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Les flux RSS, le moteur de recherche, les mises à jour du logiciel et tout autre chose sauf les transferts de torrents et opérations liées (comme les échanges de pairs) utiliseront une connexion directe</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1723"/>
        <source>Use proxy only for torrents</source>
        <translation>Utiliser le proxy seulement pour les torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1736"/>
        <source>A&amp;uthentication</source>
        <translation>A&amp;uthentication</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1776"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Information&#x202f;: le mot de passe est sauvegardé en clair</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1797"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Chemin du filtre (.dat, .p2p, .p2b) :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1813"/>
        <source>Reload the filter</source>
        <translation>Recharger le filtre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1828"/>
        <source>Manually banned IP addresses...</source>
        <translation>Adresses IP bloquées manuellement...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1835"/>
        <source>Apply to trackers</source>
        <translation>Appliquer aux trackers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1893"/>
        <source>Global Rate Limits</source>
        <translation>Limites de vitesse globales</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1899"/>
        <location filename="../gui/optionsdialog.ui" line="1915"/>
        <location filename="../gui/optionsdialog.ui" line="1970"/>
        <location filename="../gui/optionsdialog.ui" line="2106"/>
        <location filename="../gui/optionsdialog.ui" line="2382"/>
        <location filename="../gui/optionsdialog.ui" line="2405"/>
        <location filename="../gui/optionsdialog.ui" line="2428"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1902"/>
        <location filename="../gui/optionsdialog.ui" line="1918"/>
        <location filename="../gui/optionsdialog.ui" line="1973"/>
        <location filename="../gui/optionsdialog.ui" line="2109"/>
        <location filename="../gui/optionsdialog.ui" line="2469"/>
        <location filename="../gui/optionsdialog.ui" line="2482"/>
        <source> KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1947"/>
        <location filename="../gui/optionsdialog.ui" line="2135"/>
        <source>Upload:</source>
        <translation>Envoi :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1954"/>
        <location filename="../gui/optionsdialog.ui" line="2142"/>
        <source>Download:</source>
        <translation>Réception :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1964"/>
        <source>Alternative Rate Limits</source>
        <translation>Limites de vitesse alternatives</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2001"/>
        <source>Start time</source>
        <translation>Heure de début</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2028"/>
        <source>End time</source>
        <translation>Heure de fin</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2058"/>
        <source>When:</source>
        <translation>Quand :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2072"/>
        <source>Every day</source>
        <translation>Tous les jours</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2077"/>
        <source>Weekdays</source>
        <translation>Jours ouvrés</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2082"/>
        <source>Weekends</source>
        <translation>Week-ends</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2152"/>
        <source>Rate Limits Settings</source>
        <translation>Paramètres des limites de vitesse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2172"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Appliquer les limites de vitesse sur le réseau local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2165"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Appliquer les limites de vitesse au surplus généré par le protocole</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2158"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Appliquer les limites de vitesse au protocole µTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2230"/>
        <source>Privacy</source>
        <translation>Vie privée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2239"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activer le DHT (réseau décentralisé) pour trouver plus de pairs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2249"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Échanger des pairs avec les applications compatibles (µTorrent, Vuze, …)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2252"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Activer l&apos;échange de pairs (PeX) avec les autres utilisateurs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2262"/>
        <source>Look for peers on your local network</source>
        <translation>Rechercher des pairs sur votre réseau local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2265"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Activer la découverte de sources sur le réseau local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2277"/>
        <source>Encryption mode:</source>
        <translation>Mode de chiffrement :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2295"/>
        <source>Require encryption</source>
        <translation>Chiffrement requis</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2300"/>
        <source>Disable encryption</source>
        <translation>Chiffrement désactivé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2325"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Activez quand vous utilisez une connexion par proxy ou par VPN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2328"/>
        <source>Enable anonymous mode</source>
        <translation>Activer le mode anonyme</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2375"/>
        <source>Maximum active downloads:</source>
        <translation>Nombre maximum de téléchargements actifs :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2398"/>
        <source>Maximum active uploads:</source>
        <translation>Nombre maximum d&apos;envois actifs :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2421"/>
        <source>Maximum active torrents:</source>
        <translation>Nombre maximum de torrents actifs :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2457"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Ne pas compter les torrents lents dans ces limites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2495"/>
        <source>Upload rate threshold:</source>
        <translation>Limite de vitesse de téléversement :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2502"/>
        <source>Download rate threshold:</source>
        <translation>Limite de vitesse de téléchargement :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2522"/>
        <location filename="../gui/optionsdialog.ui" line="3118"/>
        <location filename="../gui/optionsdialog.ui" line="3145"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation>sec</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2538"/>
        <source>Torrent inactivity timer:</source>
        <translation>Compteur d&apos;inactivité du torrent :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2580"/>
        <source>then</source>
        <translation>puis</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2951"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Utiliser la redirection de port sur mon routeur via UPnP / NAT-PMP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2980"/>
        <source>Certificate:</source>
        <translation>Certificat :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2973"/>
        <source>Key:</source>
        <translation>Clé :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2993"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information sur les certificats&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3040"/>
        <source>Change current password</source>
        <translation>Changer le mot de passe actuel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3173"/>
        <source>Use alternative Web UI</source>
        <translation>Utiliser l&apos;interface Web alternative</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3185"/>
        <source>Files location:</source>
        <translation>Emplacement des fichiers :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3198"/>
        <source>Security</source>
        <translation>Sécurité</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3204"/>
        <source>Enable clickjacking protection</source>
        <translation>Activer la protection contre le clickjacking</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3211"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Activer la protection CSRF (Cross-Site Request Forgery)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3225"/>
        <source>Enable Host header validation</source>
        <translation>Activer la validation de l&apos;en-tête hôte</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3262"/>
        <source>Add custom HTTP headers</source>
        <translation>Ajouter des en-têtes HTTP personnalisées</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3274"/>
        <source>Header: value pairs, one per line</source>
        <translation>En-tête : paires de valeurs, une par ligne</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3296"/>
        <source>Service:</source>
        <translation>Service :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3319"/>
        <source>Register</source>
        <translation>Créer un compte</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3328"/>
        <source>Domain name:</source>
        <translation>Nom de domaine :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="221"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>En activant ces options, vous pouvez &lt;strong&gt;perdre à tout jamais&lt;/strong&gt; vos fichiers .torrent !</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="228"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Si vous activez la seconde option (&amp;ldquo;également lorsque l&apos;ajout est annulé&amp;rdquo;) le fichier .torrent &lt;strong&gt;sera supprimé&lt;/strong&gt; même si vous pressez &amp;ldquo;&lt;strong&gt;Annuler&lt;/strong&gt;&amp;rdquo; dans la boîte de dialogue &amp;ldquo;Ajouter un torrent&amp;rdquo;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="251"/>
        <source>Select qBittorrent UI Theme file</source>
        <translation>Sélectionner le fichier de thème d&apos;interface qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="252"/>
        <source>qBittorrent UI Theme file (*.qbtheme)</source>
        <translation>Fichier de thème d&apos;interface qBittorrent (*.qbtheme)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="288"/>
        <source>Choose Alternative UI files location</source>
        <translation>Choisir l&apos;emplacement des fichiers d&apos;interface alternative</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="386"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Paramètres supportés (sensible à la casse)&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="387"/>
        <source>%N: Torrent name</source>
        <translation>%N&#x202f;: Nom du torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="388"/>
        <source>%L: Category</source>
        <translation>%L&#x202f;: Catégorie</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="390"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F&#x202f;: Chemin vers le contenu (même chemin que le chemin racine pour les torrents composés de plusieurs fichiers)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="391"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Root path (first torrent subdirectory path)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="392"/>
        <source>%D: Save path</source>
        <translation>%D: Chemin de sauvegarde</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="393"/>
        <source>%C: Number of files</source>
        <translation>%C&#x202f;: Nombre de fichiers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="394"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z&#x202f;: Taille du torrent (en octets)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="395"/>
        <source>%T: Current tracker</source>
        <translation>%T&#x202f;: Tracker actuel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="396"/>
        <source>%I: Info hash</source>
        <translation>%I&#x202f;: Hachage d&apos;information</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="397"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Encapsuler le paramètre entre guillemets pour éviter que le texte soit coupé en espace blanc (ex., &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="465"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation>Un torrent sera considéré comme lent si ses vitesses de téléchargement et d&apos;émission restent en dessous de ces valeurs pour &quot;Compteur d&apos;inactivité du torrent&quot; secondes</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="474"/>
        <source>Certificate</source>
        <translation>Certificat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="475"/>
        <source>Select certificate</source>
        <translation>Sélectionner un certificat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="477"/>
        <source>Private key</source>
        <translation>Clé privée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="478"/>
        <source>Select private key</source>
        <translation>Sélectionner une clé privée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1654"/>
        <source>Select folder to monitor</source>
        <translation>Sélectionner un dossier à surveiller</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1663"/>
        <source>Folder is already being monitored:</source>
        <translation>Ce dossier est déjà surveillé :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1666"/>
        <source>Folder does not exist:</source>
        <translation>Ce dossier n&apos;existe pas :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1669"/>
        <source>Folder is not readable:</source>
        <translation>Ce dossier n&apos;est pas accessible en lecture :</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1680"/>
        <source>Adding entry failed</source>
        <translation>Impossible d&apos;ajouter l&apos;entrée</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1750"/>
        <location filename="../gui/optionsdialog.cpp" line="1776"/>
        <source>Invalid path</source>
        <translation>Chemin invalide</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1853"/>
        <source>Location Error</source>
        <translation>Erreur d&apos;emplacement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1853"/>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation>L&apos;emplacement des fichiers pour l&apos;interface Web alternative ne peut pas être vide.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="540"/>
        <location filename="../gui/optionsdialog.cpp" line="543"/>
        <location filename="../gui/optionsdialog.cpp" line="1709"/>
        <location filename="../gui/optionsdialog.cpp" line="1711"/>
        <source>Choose export directory</source>
        <translation>Choisir un dossier pour l&apos;export</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="223"/>
        <source>When these options are enabled, qBittorrent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Lorsque ces options sont actives, qBittorrent va &lt;strong&gt;supprimer&lt;/strong&gt; les fichiers .torrent après qu&apos;ils aient été ajoutés à la file de téléchargement avec succès (première option) ou non (seconde option). Ceci sera appliqué &lt;strong&gt;non seulement&lt;/strong&gt; aux fichiers ouverts via l&apos;action du menu &amp;ldquo;Ajouter un torrent&amp;rdquo; mais également à ceux ouverts via &lt;strong&gt;l&apos;association de types de fichiers&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="389"/>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Étiquettes (séparées par des virgules)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="537"/>
        <location filename="../gui/optionsdialog.cpp" line="550"/>
        <location filename="../gui/optionsdialog.cpp" line="553"/>
        <source>Choose a save directory</source>
        <translation>Choisir un répertoire de sauvegarde</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="546"/>
        <source>Choose an IP filter file</source>
        <translation>Choisissez un filtre d&apos;adresses IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="547"/>
        <source>All supported filters</source>
        <translation>Tous les filtres supportés</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1817"/>
        <source>Parsing error</source>
        <translation>Erreur de traitement</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1817"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Impossible de charger le filtre IP fourni</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1819"/>
        <source>Successfully refreshed</source>
        <translation>Correctement rechargé</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1819"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Le filtre IP a été correctement chargé : %1 règles ont été appliquées.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1783"/>
        <source>Invalid key</source>
        <translation>Clé invalide</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1783"/>
        <source>This is not a valid SSL key.</source>
        <translation>Ceci n&apos;est pas une clé SSL valide.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1757"/>
        <source>Invalid certificate</source>
        <translation>Certificat invalide</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="185"/>
        <source>Preferences</source>
        <translation>Préférences</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1757"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Ceci n&apos;est pas un certificat SSL valide.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1828"/>
        <source>Time Error</source>
        <translation>Erreur de temps</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1828"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Les heures de début et de fin ne peuvent être les mêmes.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1838"/>
        <location filename="../gui/optionsdialog.cpp" line="1843"/>
        <source>Length Error</source>
        <translation>Erreur de longueur</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1838"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Le nom d&apos;utilisateur pour l&apos;interface Web doit être au moins de 3 caractères de long.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1843"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Le mot de passe pour l&apos;interface Web doit être au moins de 6 caractères de long.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <source>Interested(local) and Choked(peer)</source>
        <translation type="vanished"> Intéressé (local) et Engorgé (pair)</translation>
    </message>
    <message>
        <source>interested(local) and unchoked(peer)</source>
        <translation type="vanished">intéressé (local) et non engorgé (pair)</translation>
    </message>
    <message>
        <source>interested(peer) and choked(local)</source>
        <translation type="vanished">intéressé (pair) et engorgé (local)</translation>
    </message>
    <message>
        <source>interested(peer) and unchoked(local)</source>
        <translation type="vanished">intéressé (pair) et non engorgé (local)</translation>
    </message>
    <message>
        <source>optimistic unchoke</source>
        <translation type="vanished">non-étranglement optimiste</translation>
    </message>
    <message>
        <source>peer snubbed</source>
        <translation type="vanished">pair évité</translation>
    </message>
    <message>
        <source>incoming connection</source>
        <translation type="vanished">connexion entrante</translation>
    </message>
    <message>
        <source>not interested(local) and unchoked(peer)</source>
        <translation type="vanished">non intéressé (local) et non engorgé (pair)</translation>
    </message>
    <message>
        <source>not interested(peer) and unchoked(local)</source>
        <translation type="vanished">non intéressé (pair) et non engorgé (local)</translation>
    </message>
    <message>
        <source>peer from PEX</source>
        <translation type="vanished">pair issu de PEX</translation>
    </message>
    <message>
        <source>peer from DHT</source>
        <translation type="vanished">pair issu du DHT</translation>
    </message>
    <message>
        <source>encrypted traffic</source>
        <translation type="vanished">trafic chiffré</translation>
    </message>
    <message>
        <source>encrypted handshake</source>
        <translation type="vanished">poignée de main chiffrée</translation>
    </message>
    <message>
        <source>peer from LSD</source>
        <translation type="vanished">pair issu de LSD</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="271"/>
        <source>Interested (local) and choked (peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="276"/>
        <source>Interested (local) and unchoked (peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="285"/>
        <source>Interested (peer) and choked (local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="290"/>
        <source>Interested (peer) and unchoked (local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="296"/>
        <source>Not interested (local) and unchoked (peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="300"/>
        <source>Not interested (peer) and unchoked (local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="304"/>
        <source>Optimistic unchoke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="308"/>
        <source>Peer snubbed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="312"/>
        <source>Incoming connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="316"/>
        <source>Peer from DHT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="320"/>
        <source>Peer from PEX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="324"/>
        <source>Peer from LSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="328"/>
        <source>Encrypted traffic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="332"/>
        <source>Encrypted handshake</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="95"/>
        <source>Country/Region</source>
        <translation>Pays/Région</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="96"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="97"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="98"/>
        <source>Flags</source>
        <translation>Indicateurs</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="99"/>
        <source>Connection</source>
        <translation>Connexion</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="100"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Logiciel</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="101"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progression</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="102"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vitesse DL</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="103"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vitesse UP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="104"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Téléchargé</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="105"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Envoyé</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="106"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Pertinence</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="107"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Fichiers</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="182"/>
        <source>Column visibility</source>
        <translation>Visibilité de colonne</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="273"/>
        <source>Add a new peer...</source>
        <translation>Ajouter un nouveau pair…</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="284"/>
        <source>Adding peers</source>
        <translation>Ajout de pairs</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>Some peers cannot be added. Check the Log for details.</source>
        <translation>Certains pairs n&apos;ont pas pu être ajoutés. Consultez le Journal pour plus d&apos;informations.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="284"/>
        <source>Peers are added to this torrent.</source>
        <translation>Les pairs sont ajoutés à ce torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="293"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="319"/>
        <source>Ban peer permanently</source>
        <translation>Bloquer le pair indéfiniment</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="320"/>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Êtes-vous sûr de vouloir bloquer les pairs sélectionnés de façon permanente ?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="326"/>
        <source>Peer &quot;%1&quot; is manually banned</source>
        <translation>Le pair &quot;%1&quot; est manuellement bloqué</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="290"/>
        <source>Copy IP:port</source>
        <translation>Copier l&apos;IP:port</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Ajouter des pairs</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>Liste des pairs à ajouter (une IP par ligne)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port / [IPv6]:port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="62"/>
        <source>No peer entered</source>
        <translation>Aucun pair saisi</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="63"/>
        <source>Please type at least one peer.</source>
        <translation>Veuillez saisir au moins un pair.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="76"/>
        <source>Invalid peer</source>
        <translation>Pair invalide</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="77"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>Le pair &apos;%1&apos; est invalide.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="172"/>
        <source>Unavailable pieces</source>
        <translation>Morceaux non disponibles</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="173"/>
        <source>Available pieces</source>
        <translation>Morceaux disponibles</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>Files in this piece:</source>
        <translation>Fichiers dans cette pièce :</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="277"/>
        <source>File in this piece</source>
        <translation>Ficher dans cette pièce :</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="279"/>
        <source>File in these pieces</source>
        <translation>Ficher dans ces pièces</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="296"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Attendre jusqu&apos;à ce que les métadonnée deviennent disponibles afin de voir les informations détaillées</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="298"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Maintenez la touche Maj. pour les informations détaillées</translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Greffons de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Greffons de recherche installés :</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation>Activé</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Avertissement : assurez-vous d&apos;être en conformité avec les lois sur le droit d&apos;auteur de votre pays lorsque vous téléchargez des torrents à partir d&apos;un de ces moteurs de recherche.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Vous pouvez obtenir davantage de greffons de recherche ici : &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Installer un nouveau</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Rechercher des mises à jour</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Désinstaller</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="167"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="238"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="303"/>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="172"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="217"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="243"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="308"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="223"/>
        <source>Uninstall warning</source>
        <translation>Avertissement de désinstallation</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="223"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Certains greffons n&apos;ont pas pu être désinstallés car ils sont inclus dans qBittorrent. Seulement ceux que vous avez vous-même ajoutés peuvent être désinstallés. Ces derniers ont été désactivés.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <source>Uninstall success</source>
        <translation>Désinstallation réussie</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Tous les greffons sélectionnés ont été désinstallés avec succès</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="456"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="471"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="503"/>
        <source>Search plugin update</source>
        <translation>Mise à jour du greffon de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>Plugins installed or updated: %1</source>
        <translation>Greffons installés ou mis à jour : %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="368"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="376"/>
        <source>New search engine plugin URL</source>
        <translation>URL du nouveau greffon moteur de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="369"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="377"/>
        <source>URL:</source>
        <translation>URL :</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="374"/>
        <source>Invalid link</source>
        <translation>Lien invalide</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="374"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Le lien ne semble pas pointer sur un greffon de moteur de recherche.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="391"/>
        <source>Select search plugins</source>
        <translation>Sélectionnez les greffons de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="392"/>
        <source>qBittorrent search plugin</source>
        <translation>Greffon de recherche de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="456"/>
        <source>All your plugins are already up to date.</source>
        <translation>Tous vos greffons sont déjà à jour.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="471"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>Désolé, impossible de vérifier les mises à jour du greffon. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="485"/>
        <source>Search plugin install</source>
        <translation>Installation du greffon de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="486"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>Impossible d&apos;installer le greffon de recherche &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="504"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>Impossible de mettre à jour le greffon de recherche &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Source du greffon</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Source du greffon de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation>Fichier local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation>Lien Web</translation>
    </message>
</context>
<context>
    <name>PortForwarderImpl</name>
    <message>
        <location filename="../base/bittorrent/portforwarderimpl.cpp" line="108"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Prise en charge de l&apos;UPnP / NAT-PMP [ACTIVÉE]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/portforwarderimpl.cpp" line="118"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Prise en charge UPnP / NAT-PMP [DÉSACTIVÉE]</translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="76"/>
        <source>qBittorrent is active</source>
        <translation>qBittorrent est actif</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="59"/>
        <source>The following files from torrent &quot;%1&quot; support previewing, please select one of them:</source>
        <translation>Les fichiers suivants du torrent &quot;%1&quot; permettent l&apos;affichage d&apos;un aperçu, veuillez en sélectionner un :</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Preview</source>
        <translation>Prévisualiser</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="70"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="71"/>
        <source>Size</source>
        <translation>Taille</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="72"/>
        <source>Progress</source>
        <translation>Progression</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="136"/>
        <source>Preview impossible</source>
        <translation>Prévisualisation impossible</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="137"/>
        <source>Sorry, we can&apos;t preview this file: &quot;%1&quot;.</source>
        <translation>Désolé, il est impossible de prévisualiser le fichier &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Sélection du fichier à prévisualiser</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="319"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; n&apos;existe pas</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="321"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; ne pointe pas vers un répertoire</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="323"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; ne pointe pas vers un fichier</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="325"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>N&apos;a pas la permission de lire dans &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="327"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>N&apos;a pas la permission d&apos;écrire dans &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="87"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="86"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>Ne pas télécharger</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="88"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Haute</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="89"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximale</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="60"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Peers</source>
        <translation>Pairs</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="78"/>
        <source>HTTP Sources</source>
        <translation>Sources HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="87"/>
        <source>Content</source>
        <translation>Contenu</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="98"/>
        <source>Speed</source>
        <translation>Vitesse</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="333"/>
        <source>Downloaded:</source>
        <translation>Téléchargé :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="110"/>
        <source>Availability:</source>
        <translation>Disponibilité :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="81"/>
        <source>Progress:</source>
        <translation>Progression&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="157"/>
        <source>Transfer</source>
        <translation>Transfert</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="549"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Actif pendant&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="578"/>
        <source>ETA:</source>
        <translation>Temps restant&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="507"/>
        <source>Uploaded:</source>
        <translation>Envoyé :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="436"/>
        <source>Seeds:</source>
        <translation>Sources&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="452"/>
        <source>Download Speed:</source>
        <translation>Vitesse de téléchargement&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="188"/>
        <source>Upload Speed:</source>
        <translation>Vitesse d&apos;émission&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="217"/>
        <source>Peers:</source>
        <translation>Pairs&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="275"/>
        <source>Download Limit:</source>
        <translation>Limite de téléchargement&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="349"/>
        <source>Upload Limit:</source>
        <translation>Limite d&apos;envoi&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="594"/>
        <source>Wasted:</source>
        <translation>Gaspillé :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="233"/>
        <source>Connections:</source>
        <translation>Connexions :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="607"/>
        <source>Information</source>
        <translation>Informations</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="866"/>
        <source>Comment:</source>
        <translation>Commentaire :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1026"/>
        <source>Select All</source>
        <translation>Tout sélectionner</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1033"/>
        <source>Select None</source>
        <translation>Ne rien sélectionner</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="619"/>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="623"/>
        <source>High</source>
        <translation>Haute</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="291"/>
        <source>Share Ratio:</source>
        <translation>Ratio de partage&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="407"/>
        <source>Reannounce In:</source>
        <translation>Annoncer dans&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="365"/>
        <source>Last Seen Complete:</source>
        <translation>Dernière fois vu complet&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="625"/>
        <source>Total Size:</source>
        <translation>Taille totale&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="654"/>
        <source>Pieces:</source>
        <translation>Morceaux&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="683"/>
        <source>Created By:</source>
        <translation>Créé par&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="712"/>
        <source>Added On:</source>
        <translation>Ajouté le&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="741"/>
        <source>Completed On:</source>
        <translation>Complété le&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="770"/>
        <source>Created On:</source>
        <translation>Créé le&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="799"/>
        <source>Torrent Hash:</source>
        <translation>Hachage du torrent&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="831"/>
        <source>Save Path:</source>
        <translation>Chemin de sauvegarde&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="627"/>
        <source>Maximum</source>
        <translation>Maximale</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="615"/>
        <source>Do not download</source>
        <translation>Ne pas télécharger</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="460"/>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="468"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 × %2 (a %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="410"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="413"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 cette session)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="422"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (partagé pendant %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="429"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 maximum)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="442"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="446"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="452"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="457"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 en moyenne)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="589"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="591"/>
        <source>Open Containing Folder</source>
        <translation>Ouvrir le dossier parent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="593"/>
        <source>Rename...</source>
        <translation>Renommer…</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="613"/>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="632"/>
        <source>By shown file order</source>
        <translation>Par ordre de fichier affiché</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="688"/>
        <source>New Web seed</source>
        <translation>Nouvelle source web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="692"/>
        <source>Remove Web seed</source>
        <translation>Supprimer la source web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="695"/>
        <source>Copy Web seed URL</source>
        <translation>Copier l&apos;URL de la source web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="697"/>
        <source>Edit Web seed URL</source>
        <translation>Modifier l&apos;URL de la source web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="731"/>
        <source>&lt;center&gt;&lt;b&gt;Speed graphs are disabled&lt;/b&gt;&lt;p&gt;You may change this setting in Advanced Options &lt;/center&gt;</source>
        <translation>&lt;center&gt;&lt;b&gt;Les graphiques de vitesse sont désactivés&lt;/b&gt; &lt;p&gt;Vous pouvez changer ce paramètre dans les Paramètres avancés&lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="93"/>
        <source>Filter files...</source>
        <translation>Filtrer les fichiers…</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="743"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nouvelle source URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="744"/>
        <source>New URL seed:</source>
        <translation>Nouvelle source URL&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="751"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="805"/>
        <source>This URL seed is already in the list.</source>
        <translation>Cette source URL est déjà sur la liste.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="797"/>
        <source>Web seed editing</source>
        <translation>Modification de la source web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="798"/>
        <source>Web seed URL:</source>
        <translation>URL de la source web :</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="154"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation> %1 est un paramètre de ligne de commande inconnu.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="166"/>
        <location filename="../app/main.cpp" line="177"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 doit être le paramètre de ligne de commande unique.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="212"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Vous ne pouvez pas utiliser% 1: qBittorrent est déjà en cours d&apos;exécution pour cet utilisateur.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="540"/>
        <source>Usage:</source>
        <translation>Utilisation :</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Options:</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="161"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>Le paramètre &apos;%1&apos; doit suivre la syntaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="207"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>Le paramètre &apos;%1&apos; doit suivre la syntaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="222"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>Nombre entier attendu dans la variable d&apos;environnement &apos;%1&apos;, reçu &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="279"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>Le paramètre &apos;%1&apos; doit suivre la syntaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="306"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>%1 attendu dans la variable d&apos;environnement &apos;%2&apos;, mais reçu &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <source>port</source>
        <translation>port</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="425"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 doit spécifier un port valide (1 à 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="545"/>
        <source>Display program version and exit</source>
        <translation>Afficher la version du programme et quitter</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>Display this help message and exit</source>
        <translation>Afficher ce message d&apos;aide et quitter</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Change the Web UI port</source>
        <translation>Change le port de l&apos;interface Web</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Disable splash screen</source>
        <translation>Désactiver l&apos;écran de démarrage</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Exécuter en tâche de fond</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>dossier</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="558"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Sauvegarde les fichiers de configuration dans &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <location filename="../app/cmdoptions.cpp" line="572"/>
        <source>name</source>
        <translation>nom</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="560"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Sauvegarde les fichiers de configuration dans les répertoires qBittorrent_&lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="562"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Hacke les fichiers fastresume de libtorrent, et rend les chemins des fichiers relatifs au répertoire du profil</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="564"/>
        <source>files or URLs</source>
        <translation>fichiers ou URLs</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="565"/>
        <source>Download the torrents passed by the user</source>
        <translation>Télécharger les torrents transmis par l&apos;utilisateur</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="579"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Préciser si la fenêtre &quot;Ajouter un nouveau torrent&quot; s&apos;ouvre lors de l&apos;ajout d&apos;un torrent.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="568"/>
        <source>Options when adding new torrents:</source>
        <translation>Options lors de l&apos;ajout d&apos;un nouveau torrent :</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="569"/>
        <source>path</source>
        <translation>chemin</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="569"/>
        <source>Torrent save path</source>
        <translation>Chemin d&apos;enregistrement du torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="570"/>
        <source>Add torrents as started or paused</source>
        <translation>Ajouter les torrents comme démarrés ou mis en pause</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="571"/>
        <source>Skip hash check</source>
        <translation>Ne pas vérifier le hash du torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="573"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Affecter des torrents à la catégorie. Si la catégorie n&apos;existe pas, elle sera créée.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="575"/>
        <source>Download files in sequential order</source>
        <translation>Télécharger les fichiers en ordre séquentiel</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="577"/>
        <source>Download first and last pieces first</source>
        <translation>Télécharger premières et dernières pièces en premier</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="583"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Les valeurs des options peuvent être renseignées par les variables d&apos;environnement. Pour une option nommée &apos;parameter-name&apos;, le nom de la variable d&apos;environnement est &apos;QBT_PARAMETER_NAME&apos; (en majuscules, en remplaçant &apos;-&apos; par &apos;_&apos;). Pour renseigner une valeur sentinelle, réglez la variable sur &apos;1&apos; ou &apos;TRUE&apos;. Par exemple, pour désactiver l&apos;écran d’accueil :</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="588"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Les paramètres de la ligne de commande priment sur les variables d&apos;environnement </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="596"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Exécuter le programme avec l&apos;option -h pour afficher les paramètres de ligne de commande.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="401"/>
        <source>Bad command line</source>
        <translation>Mauvaise ligne de commande</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="407"/>
        <source>Bad command line: </source>
        <translation>Mauvaise ligne de commande :</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>Legal Notice</source>
        <translation>Information légale</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="421"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation>qBittorrent est un logiciel de partage de fichiers. Lors de l&apos;ajout d&apos;un torrent, ses données seront mises à disposition des autres utilisateurs par téléversement. Vous êtes tenus seul responsable du contenu que vous partagez.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="422"/>
        <source>No further notices will be issued.</source>
        <translation>Ce message d&apos;avertissement ne sera plus affiché.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="435"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent est un logiciel de partage de fichiers. Lors de l&apos;ajout d&apos;un torrent, les données que vous téléchargez sont mises à disposition des autres utilisateurs. Vous êtes responsable du contenu que vous partagez.

Ce message d&apos;avertissement ne sera plus affiché.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="423"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Appuyez sur la touche %1 pour accepter et continuer…</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="436"/>
        <source>Legal notice</source>
        <translation>Information légale</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="437"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="438"/>
        <source>I Agree</source>
        <translation>J&apos;accepte</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="249"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation>Fermeture inattendue du programme détectée. Le fichier de sauvegarde va être utilisé pour restaurer les paramètres : %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="323"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Une erreur d&apos;accès s&apos;est produite en tentant d&apos;écrire le fichier de configuration.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="326"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Une erreur de format s&apos;est produite en tentant d&apos;écrire le fichier de configuration.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="329"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation>Une erreur inconnue est survenue lors de l&apos;écriture du fichier de configuration</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="51"/>
        <source>Migrate preferences failed: WebUI https, file: &quot;%1&quot;, error: &quot;%2&quot;</source>
        <translation>Échec de la migration des préférences : WebUI https, fichier : « %1 », erreur : « %2 »</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="73"/>
        <source>Migrated preferences: WebUI https, exported data to file: &quot;%1&quot;</source>
        <translation>Échec de la migration des préférences : WebUI https, données exportées vers le fichier : « %1 »</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="80"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="88"/>
        <source>Invalid data format.</source>
        <translation>Format de données invalide.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="123"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>Impossible d&apos;enregistrer les données de téléchargement automatique RSS vers %1. Erreur : %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="284"/>
        <source>Invalid data format</source>
        <translation>Format de données invalide</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="431"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>Impossible de lire les règles de téléchargement automatique RSS à partir de %1. Erreur : %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="445"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>Impossible de charger les règles de téléchargement automatique RSS. Raison : %1</translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="215"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Échec de téléchargement du flux RSS à &apos;%1&apos;. Motif : %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="251"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation>Mise à jour du flux RSS à &apos;%1&apos;. Ajout de %2 nouveaux articles.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="248"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Échec de l&apos;analyse du flux RSS à &apos;%1&apos;. Motif : %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="205"/>
        <source>RSS feed at &apos;%1&apos; is successfully downloaded. Starting to parse it.</source>
        <translation>Le flux RSS %1 a été téléchargé avec succès. Lancement de l&apos;analyse.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="275"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>Impossible de lire les données de la session RSS depuis %1. Erreur : %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="287"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>Impossible d&apos;analyser les données de la session RSS. Erreur : %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="294"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>Impossible de charger les données de la session RSS. Format de données invalide.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="305"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>Impossible de charger l&apos;article RSS &apos;%1#%2&apos;. Le format de données n&apos;est pas valide.</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/rss_parser.cpp" line="596"/>
        <source>Invalid RSS feed.</source>
        <translation>Flux RSS non valide.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_parser.cpp" line="600"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (ligne : %2, colonne : %3, décalage : %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="162"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>Le flux RSS avec le chemin donné existe déjà : %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="182"/>
        <source>Cannot move root folder.</source>
        <translation>Ne peut pas déplacer le dossier racine.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="190"/>
        <location filename="../base/rss/rss_session.cpp" line="231"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>L&apos;élément n&apos;existe pas : %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="223"/>
        <source>Cannot delete root folder.</source>
        <translation>Ne peut pas supprimer le dossier racine.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="315"/>
        <source>Couldn&apos;t load RSS Feed &apos;%1&apos;. URL is required.</source>
        <translation>Impossible de charger le flux RSS &apos;%1&apos;. L&apos;URL est nécessaire.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="326"/>
        <source>Couldn&apos;t load RSS Feed &apos;%1&apos;. UID is invalid.</source>
        <translation>Impossible de charger le flux RSS &apos;%1&apos;. L&apos;UID n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="333"/>
        <source>Duplicate RSS Feed UID: %1. Configuration seems to be corrupted.</source>
        <translation>Flux RSS doublon UID : %1. La configuration semble corrompue.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="354"/>
        <source>Couldn&apos;t load RSS Item &apos;%1&apos;. Invalid data format.</source>
        <translation>Impossible de charger l&apos;élément RSS &apos;%1&apos;. Format de données invalide.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="404"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Chemin d&apos;article RSS Incorrect : %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="411"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>L&apos;article RSS avec le chemin donné existe déjà : %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="420"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>Le dossier parent n&apos;existe pas : %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>La récupération automatique des flux RSS est actuellement désactivée ! Vous pouvez l&apos;activer depuis les paramètres de l&apos;application.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Nouvelle souscription</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Marquer comme lu</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Rafraîchir les flux RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Tout mettre à jour</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>Gestionnaire de téléchargement RSS…</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents&#x202f;: (double-clic pour télécharger)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Renommer…</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Renommer</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Mettre à jour</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Nouvelle souscription…</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Mettre à jour tous les flux</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Télécharger le torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Ouvrir une nouvelle URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Copier l&apos;URL du flux</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Nouveau dossier…</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="228"/>
        <source>Please choose a folder name</source>
        <translation>Veuillez choisir un nouveau nom de dossier</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="228"/>
        <source>Folder name:</source>
        <translation>Nom du dossier :</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="229"/>
        <source>New folder</source>
        <translation>Nouveau dossier</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="270"/>
        <source>Please type a RSS feed URL</source>
        <translation>Veuillez entrer une URL de flux RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="270"/>
        <source>Feed URL:</source>
        <translation>URL du flux :</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="312"/>
        <source>Deletion confirmation</source>
        <translation>Confirmation de la suppression</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="312"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Voulez-vous vraiment supprimer les flux RSS sélectionnés ?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="409"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Veuillez choisir un nouveau nom pour ce flux RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="409"/>
        <source>New feed name:</source>
        <translation>Nouveau nom du flux :</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="417"/>
        <source>Rename failed</source>
        <translation>Échec du renommage</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="489"/>
        <source>Date: </source>
        <translation>Date : </translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="491"/>
        <source>Author: </source>
        <translation>Auteur : </translation>
    </message>
</context>
<context>
    <name>ResumeDataSavingManager</name>
    <message>
        <source>Couldn&apos;t save data to &apos;%1&apos;. Error: %2</source>
        <translation type="vanished">Impossible de sauvegarder les données dans &apos;%1&apos;. Motif : %2</translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="102"/>
        <source>Select save location</source>
        <translation>Sélectionner un emplacement de sauvegarde</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="149"/>
        <source>Monitored Folder</source>
        <translation>Répertoire surveillé</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="152"/>
        <source>Override Save Location</source>
        <translation>Remplacer l&apos;emplacement de sauvegarde</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="415"/>
        <source>Monitored folder</source>
        <translation>Répertoire surveillé</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="417"/>
        <source>Default save location</source>
        <translation>Emplacement de sauvegarde par défaut</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="419"/>
        <source>Browse...</source>
        <translation>Parcourir...</translation>
    </message>
</context>
<context>
    <name>SearchController</name>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="98"/>
        <source>Python must be installed to use the Search Engine.</source>
        <translation>Python doit être installé afin d&apos;utiliser le moteur de recherche.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="123"/>
        <source>Unable to create more than %1 concurrent searches.</source>
        <translation>Impossible de lancer plus de %1 recherches en parallèles.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="203"/>
        <location filename="../webui/api/searchcontroller.cpp" line="209"/>
        <source>Offset is out of range</source>
        <translation>Offset hors plage</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="286"/>
        <source>All plugins are already up to date.</source>
        <translation>Tous les greffons sont déjà à jour.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="290"/>
        <source>Updating %1 plugins</source>
        <translation>Mise à jour de %1 greffons</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="295"/>
        <source>Updating plugin %1</source>
        <translation>Mise à jour du greffon %1</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="302"/>
        <source>Failed to check for plugin updates: %1</source>
        <translation>Échec de la recherche de mise à jour pour le greffon : %1</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Résultats(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="45"/>
        <source>Search in:</source>
        <translation>Recherche :</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Certains moteurs de recherche cherchent également dans la description du torrent et dans les noms des fichiers torrent. L&apos;affichage de ces résultats dans la liste ci-dessous est contrôlé par ce mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Partout&lt;/span&gt; désactive le filtrage et affiche tout ce qui est renvoyé par les moteurs de recherche.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Noms de torrent seulement&lt;/span&gt; ne montrent que les torrents dont les noms correspondent à la requête de recherche.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>Définir le nombre minimum et maximum autorisé de sources</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="87"/>
        <source>Seeds:</source>
        <translation>Sources&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nombre minimal de sources&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="116"/>
        <location filename="../gui/search/searchjobwidget.ui" line="204"/>
        <source>to</source>
        <translation>à</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nombre maximal de sources&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="126"/>
        <location filename="../gui/search/searchjobwidget.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Définir la taille minimale et maximale autorisée pour un torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="170"/>
        <source>Size:</source>
        <translation>Taille :</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Taille minimale du torrent &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Taille maximal du torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="77"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="78"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Taille</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="79"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Sources complètes</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="80"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Sources partielles</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="81"/>
        <source>Search engine</source>
        <translation>Moteur de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="132"/>
        <source>Filter search results...</source>
        <translation>Filtrer les résultats de recherche...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="307"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Résultats (affichage de &lt;i&gt;%1&lt;/i&gt; sur &lt;i&gt;%2&lt;/i&gt;) :</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="358"/>
        <source>Torrent names only</source>
        <translation>Noms de torrent seulement</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="359"/>
        <source>Everywhere</source>
        <translation>Partout</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="382"/>
        <source>Use regular expressions</source>
        <translation>Utiliser les expressions régulières</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="396"/>
        <source>Download</source>
        <translation>Téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="399"/>
        <source>Open description page</source>
        <translation>Ouvrir la page de description</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="403"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="405"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="407"/>
        <source>Download link</source>
        <translation>Lien de téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="409"/>
        <source>Description page URL</source>
        <translation>URL de la page de description</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="420"/>
        <source>Searching...</source>
        <translation>En cours de recherche...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="422"/>
        <source>Search has finished</source>
        <translation>La recherche est terminée</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="424"/>
        <source>Search aborted</source>
        <translation>Recherche annulée</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="426"/>
        <source>An error occurred during search...</source>
        <translation>Une erreur s&apos;est produite lors de la recherche…</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="428"/>
        <source>Search returned no results</source>
        <translation>La recherche n&apos;a retourné aucun résultat</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="453"/>
        <source>Column visibility</source>
        <translation>Visibilité de la colonne</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="221"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Format de fichier du greffon de recherche inconnu.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="233"/>
        <source>Plugin already at version %1, which is greater than %2</source>
        <translation>Le greffon est déjà à la version %1, qui est plus récente que la %2</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="234"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Une version plus récente de ce greffon est déjà installée.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="257"/>
        <source>Plugin %1 is not supported.</source>
        <translation>Le greffon %1 n&apos;est pas supporté.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="265"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="269"/>
        <source>Plugin is not supported.</source>
        <translation>Greffon non supporté.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="277"/>
        <source>Plugin %1 has been successfully updated.</source>
        <translation>Le greffon %1 a été correctement mis à jour.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="342"/>
        <source>All categories</source>
        <translation>Toutes les catégories</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="343"/>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="344"/>
        <source>TV shows</source>
        <translation>Émissions de télévision</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="345"/>
        <source>Music</source>
        <translation>Musique</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="346"/>
        <source>Games</source>
        <translation>Jeux</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="347"/>
        <source>Anime</source>
        <translation>Animation</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="348"/>
        <source>Software</source>
        <translation>Logiciel</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="349"/>
        <source>Pictures</source>
        <translation>Photos</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="350"/>
        <source>Books</source>
        <translation>Livres</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="384"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>Serveur de mise à jour temporairement indisponible. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="405"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="407"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Échec du téléchargement du fichier de plugin. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="537"/>
        <source>Plugin &quot;%1&quot; is outdated, updating to version %2</source>
        <translation>Le greffon &quot;%1&quot; est dépassé, mise à jour vers la version %2</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="544"/>
        <source>Incorrect update info received for %1 out of %2 plugins.</source>
        <translation>Informations de mise à jour incorrectes reçues de %1 plug-ins sur %2.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="583"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>Le numéro de version (&apos;%2&apos;) du greffon de recherche &apos;%1&apos; est invalide</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <location filename="../gui/search/searchwidget.cpp" line="306"/>
        <location filename="../gui/search/searchwidget.cpp" line="372"/>
        <location filename="../gui/search/searchwidget.cpp" line="380"/>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>Il n&apos;y a aucun greffon de recherche installé.
Cliquez sur le bouton &quot;Recherche de greffons...&quot; en bas à droite de la fenêtre pour en installer.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Search plugins...</source>
        <translation>Greffons de recherche...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="96"/>
        <source>A phrase to search for.</source>
        <translation>Une phrase à rechercher</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="97"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Les espaces dans un terme de recherche peuvent être protégés par des guillemets.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="99"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Exemple :</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="101"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: recherche &lt;b&gt;foo&lt;/b&gt; et &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="105"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: recherche &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="195"/>
        <source>All plugins</source>
        <translation>Tous les greffons</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="194"/>
        <source>Only enabled</source>
        <translation>Uniquement activé(s)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="196"/>
        <source>Select...</source>
        <translation>Choisir...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="297"/>
        <location filename="../gui/search/searchwidget.cpp" line="366"/>
        <location filename="../gui/search/searchwidget.cpp" line="368"/>
        <source>Search Engine</source>
        <translation>Moteur de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="297"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Veuillez installer Python afin d&apos;utiliser le moteur de recherche.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="317"/>
        <source>Empty search pattern</source>
        <translation>Motif de recherche vide</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="317"/>
        <source>Please type a search pattern first</source>
        <translation>Veuillez entrer un motif de recherche</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="347"/>
        <source>Stop</source>
        <translation>Arrêter</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="368"/>
        <source>Search has finished</source>
        <translation>Recherche terminée</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="366"/>
        <source>Search has failed</source>
        <translation>La recherche a échoué</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>Ne plus afficher</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>qBittorrent will now exit.</source>
        <translation>qBittorent va se fermer.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="115"/>
        <source>E&amp;xit Now</source>
        <translation>&amp;Quitter maintenant</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="116"/>
        <source>Exit confirmation</source>
        <translation>Confirmation de fermeture</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>The computer is going to shutdown.</source>
        <translation>L&apos;ordinateur va s&apos;arrêter.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="120"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Eteindre maintenant</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="121"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmation de l&apos;extinction</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>L&apos;ordinateur va entrer en mode veille.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="125"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Mettre en veille maintenant</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="126"/>
        <source>Suspend confirmation</source>
        <translation>Confirmation de mise en veille</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>L&apos;ordinateur va entrer en veille prolongée</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="130"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Mise en veille maintenant</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="131"/>
        <source>Hibernate confirmation</source>
        <translation>Confirmation Mise en veille</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="141"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Vous pouvez annuler cette action pendant %1 secondes.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="14"/>
        <source>Global Speed Limits</source>
        <translation>Limites de vitesse globale</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="20"/>
        <source>Speed limits</source>
        <translation>Limites de vitesse</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="33"/>
        <location filename="../gui/speedlimitdialog.ui" line="103"/>
        <source>Upload:</source>
        <translation>Émission:</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="47"/>
        <location filename="../gui/speedlimitdialog.ui" line="74"/>
        <location filename="../gui/speedlimitdialog.ui" line="117"/>
        <location filename="../gui/speedlimitdialog.ui" line="144"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="50"/>
        <location filename="../gui/speedlimitdialog.ui" line="77"/>
        <location filename="../gui/speedlimitdialog.ui" line="120"/>
        <location filename="../gui/speedlimitdialog.ui" line="147"/>
        <source> KiB/s</source>
        <translation> Kio/s</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="60"/>
        <location filename="../gui/speedlimitdialog.ui" line="130"/>
        <source>Download:</source>
        <translation>Téléchargement:</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="90"/>
        <source>Alternative speed limits</source>
        <translation>Limites de vitesse alternative</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="173"/>
        <source>Total Upload</source>
        <translation>Envoi (total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="174"/>
        <source>Total Download</source>
        <translation>Téléchargement (total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="178"/>
        <source>Payload Upload</source>
        <translation>Envoi (charge utile)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="179"/>
        <source>Payload Download</source>
        <translation>Téléchargement (charge utile)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="183"/>
        <source>Overhead Upload</source>
        <translation>Envoi (surplus)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="184"/>
        <source>Overhead Download</source>
        <translation>Téléchargement (surplus)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="188"/>
        <source>DHT Upload</source>
        <translation>Envoi (DHT)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="189"/>
        <source>DHT Download</source>
        <translation>Téléchargement (DHT)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="193"/>
        <source>Tracker Upload</source>
        <translation>Envoi (tracker)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="194"/>
        <source>Tracker Download</source>
        <translation>Téléchargement (tracker)</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Période&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minute</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minutes</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minutes</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="75"/>
        <source>6 Hours</source>
        <translation>6 heures</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="105"/>
        <source>Select Graphs</source>
        <translation>Sélectionner les graphiques</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Total Upload</source>
        <translation>Envoi (total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>3 Hours</source>
        <translation>3 heures</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="76"/>
        <source>12 Hours</source>
        <translation>12 heures</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="77"/>
        <source>24 Hours</source>
        <translation>24 heures</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Total Download</source>
        <translation>Téléchargement (total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Payload Upload</source>
        <translation>Envoi (charge utile)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>Payload Download</source>
        <translation>Téléchargement (charge utile)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Overhead Upload</source>
        <translation>Envoi (surplus)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Overhead Download</source>
        <translation>Téléchargement (surplus)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>DHT Upload</source>
        <translation>Envoi (DHT)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="90"/>
        <source>DHT Download</source>
        <translation>Téléchargement (DHT)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="91"/>
        <source>Tracker Upload</source>
        <translation>Envoi (tracker)</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="92"/>
        <source>Tracker Download</source>
        <translation>Téléchargement (tracker)</translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation>Information de plantage</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Statistiques</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Statistiques utilisateur</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Statistiques du tampon</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Succès de tampon en lecture :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Temps moyen passé en file d&apos;attente :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>Clients connectés :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation>Total du ratio de partage :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation>Total téléchargé :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation>Gâchis de la session :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation>Total envoyé :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation>Taille totale du tampon :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Statistiques de performance</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Actions d&apos;E/S en file d&apos;attente :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Surcharge du tampon d&apos;écriture :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Surcharge du tampon de lecture :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Taille totale des fichiers en file d&apos;attente :</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="112"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="192"/>
        <source>Connection status:</source>
        <translation>Statut de la connexion :</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="192"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Aucune connexion directe. Ceci peut être signe d&apos;une mauvaise configuration réseau.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="202"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT : %1 nœuds</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>Redémarrage nécessaire de qBittorrent !</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="179"/>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Connection Status:</source>
        <translation>État de la connexion :</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="179"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Hors ligne. Ceci signifie généralement que qBittorrent s&apos;a pas pu se mettre en écoute sur le port défini pour les connexions entrantes.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Online</source>
        <translation>Connecté</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="248"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Cliquez ici pour utiliser les limites de vitesse alternatives</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="242"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Cliquez ici pour utiliser les limites de vitesse normales</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Tout (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="186"/>
        <source>Downloading (0)</source>
        <translation>Téléchargement (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="189"/>
        <source>Seeding (0)</source>
        <translation>En Partage (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="192"/>
        <source>Completed (0)</source>
        <translation>Complété (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="195"/>
        <source>Resumed (0)</source>
        <translation>Démarrés (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="198"/>
        <source>Paused (0)</source>
        <translation>En Pause (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="201"/>
        <source>Active (0)</source>
        <translation>Actif (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="204"/>
        <source>Inactive (0)</source>
        <translation>Inactif (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="207"/>
        <source>Stalled (0)</source>
        <translation>En attente (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="210"/>
        <source>Stalled Uploading (0)</source>
        <translation>Envoi en attente (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="213"/>
        <source>Stalled Downloading (0)</source>
        <translation>Téléchargement en attente (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="216"/>
        <source>Errored (0)</source>
        <translation>Erreur (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="270"/>
        <source>All (%1)</source>
        <translation>Tous (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="271"/>
        <source>Downloading (%1)</source>
        <translation>Téléchargement (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="272"/>
        <source>Seeding (%1)</source>
        <translation>En Partage (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="273"/>
        <source>Completed (%1)</source>
        <translation>Terminés (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="275"/>
        <source>Paused (%1)</source>
        <translation>En Pause (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="274"/>
        <source>Resumed (%1)</source>
        <translation>Démarrés (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="276"/>
        <source>Active (%1)</source>
        <translation>Actifs (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="277"/>
        <source>Inactive (%1)</source>
        <translation>Inactifs (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="278"/>
        <source>Stalled (%1)</source>
        <translation>En attente (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="279"/>
        <source>Stalled Uploading (%1)</source>
        <translation>Envoi en attente (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="280"/>
        <source>Stalled Downloading (%1)</source>
        <translation>Téléchargement en attente (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="281"/>
        <source>Errored (%1)</source>
        <translation>Erreur (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="149"/>
        <source>Tags</source>
        <translation>Étiquettes</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>All</source>
        <translation>Tous</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="262"/>
        <source>Untagged</source>
        <translation>Pas de tags</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="110"/>
        <source>Add tag...</source>
        <translation>Ajouter une étiquette...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="116"/>
        <source>Remove tag</source>
        <translation>Supprimer une étiquette</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove unused tags</source>
        <translation>Supprimer les étiquettes inutilisées</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="123"/>
        <source>Resume torrents</source>
        <translation>Relancer les torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="125"/>
        <source>Pause torrents</source>
        <translation>Mettre en pause les torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="127"/>
        <source>Delete torrents</source>
        <translation>Supprimer les torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="171"/>
        <source>New Tag</source>
        <translation>Nouvelle étiquette</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="171"/>
        <source>Tag:</source>
        <translation>Étiquette :</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="177"/>
        <source>Invalid tag name</source>
        <translation>Nom de tag invalide</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="178"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>Le nom de l&apos;étiquette &apos;%1&apos; est invalide</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag exists</source>
        <translation>L&apos;étiquette existe déjà</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name already exists.</source>
        <translation>Le nom de l&apos;étiquette existe déjà.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Propriétés de la catégorie de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Nom&#x202f;:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Répertoire de sauvegarde :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="43"/>
        <source>Choose save path</source>
        <translation>Choisir le répertoire de sauvegarde</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="65"/>
        <source>New Category</source>
        <translation>Nouvelle catégorie</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="76"/>
        <source>Invalid category name</source>
        <translation>Nom de catégorie invalide</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="77"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>Le nom de catégorie ne peut contenir de &apos;\&apos;.
Le nom de catégorie ne peut commencer/finir par &apos;/&apos;.
Le nom de catégorie ne peut contenir la séquence &apos;//&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="84"/>
        <source>Category creation error</source>
        <translation>Erreur de création de catégorie</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="85"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Ce nom de catégorie existe déjà.
Veuillez en choisir un autre.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Size</source>
        <translation>Taille</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Progress</source>
        <translation>Progression</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Download Priority</source>
        <translation>Priorité de téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Remaining</source>
        <translation>Restant</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Availability</source>
        <translation>Disponibilité :</translation>
    </message>
</context>
<context>
    <name>TorrentContentModelItem</name>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="118"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixtes</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="120"/>
        <source>Not downloaded</source>
        <translation>Pas téléchargé</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="122"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Haut</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="124"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="126"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="140"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="124"/>
        <source>Renaming</source>
        <translation>Restant</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="124"/>
        <source>New name:</source>
        <translation>Nouveau nom :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="147"/>
        <source>Rename error</source>
        <translation>Erreur de renommage</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Créateur de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="56"/>
        <source>Select file/folder to share</source>
        <translation>Sélectionner un ficher/dossier à partager</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="64"/>
        <source>Path:</source>
        <translation>Chemin :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="91"/>
        <source>[Drag and drop area]</source>
        <translation>[zone de glisser et déposer]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="101"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="120"/>
        <source>Select file</source>
        <translation>Sélectionnez un fichier</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="108"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="113"/>
        <source>Select folder</source>
        <translation>Sélectionnez un dossier :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="120"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="141"/>
        <source>Torrent format:</source>
        <translation>Format du Torrent :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>Hybrid</source>
        <translation>Hybride</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="185"/>
        <source>Piece size:</source>
        <translation>taille des morceaux :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="199"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="204"/>
        <source>16 KiB</source>
        <translation>16 Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="209"/>
        <source>32 KiB</source>
        <translation>32 Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="214"/>
        <source>64 KiB</source>
        <translation>64 Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="219"/>
        <source>128 KiB</source>
        <translation>128 Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="224"/>
        <source>256 KiB</source>
        <translation>256 Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="229"/>
        <source>512 KiB</source>
        <translation>512 Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="234"/>
        <source>1 MiB</source>
        <translation>1 Mio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="239"/>
        <source>2 MiB</source>
        <translation>2 Mio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="244"/>
        <source>4 MiB</source>
        <translation>4 Mio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="249"/>
        <source>8 MiB</source>
        <translation>8 Mio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="254"/>
        <source>16 MiB</source>
        <translation>16 Mio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="259"/>
        <source>32 MiB</source>
        <translation>32 Mio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="267"/>
        <source>Calculate number of pieces:</source>
        <translation>Calcul du nombre de morceaux:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="296"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>Torrent privé (ne sera pas distribué sur le réseau DHT)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="303"/>
        <source>Start seeding immediately</source>
        <translation>Commencer le partage immédiatement</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="313"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorer les limites du ratio de partage pour ce torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="320"/>
        <source>Optimize alignment</source>
        <translation>Alignement optimisé</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="331"/>
        <source>Align to piece boundary for files larger than:</source>
        <translation>Aligner sur la limite de la pièce pour les fichiers plus grands que :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="338"/>
        <source>Disabled</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="341"/>
        <source> KiB</source>
        <translation>Kio</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="378"/>
        <source>Fields</source>
        <translation>Champs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="384"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <translation>Vous pouvez séparer les groupes / niveaux de trackers avec une ligne vide.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="394"/>
        <source>Web seed URLs:</source>
        <translation>URL des sources Web :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="415"/>
        <source>Tracker URLs:</source>
        <translation>URL des trackers :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="422"/>
        <source>Comments:</source>
        <translation>Commentaires :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="429"/>
        <source>Source:</source>
        <translation>Source :</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="448"/>
        <source>Progress:</source>
        <translation>Progression : </translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="73"/>
        <source>Create Torrent</source>
        <translation>Créer un Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="181"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="226"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="240"/>
        <source>Torrent creation failed</source>
        <translation>Échec de la création du Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="181"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Motif : L&apos;emplacement du fichier/dossier n&apos;est pas accessible en lecture.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="188"/>
        <source>Select where to save the new torrent</source>
        <translation>Sélectionnez où sauvegarder le nouveau torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="188"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Fichiers Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="226"/>
        <source>Reason: %1</source>
        <translation>Motif : %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="240"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>Motif : Le torrent créé est invalide. Il ne sera pas ajouté à la liste de téléchargement.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="256"/>
        <source>Torrent creator</source>
        <translation>Créateur de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="257"/>
        <source>Torrent created:</source>
        <translation>Torrent créé :</translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="138"/>
        <source>File size exceeds max limit %1</source>
        <translation>La taille du fichier excède la limite max %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="150"/>
        <source>Torrent file read error: %1</source>
        <translation>Erreur de lecture du fichier torrent : %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="156"/>
        <source>Torrent file read error: size mismatch</source>
        <translation>Erreur de lecture du fichier torrent: incohérence de taille</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="168"/>
        <source>Invalid metadata.</source>
        <translation>Métadonnée invalide.</translation>
    </message>
</context>
<context>
    <name>TorrentOptionsDialog</name>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="14"/>
        <source>Torrent Options</source>
        <translation>Options torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="20"/>
        <source>Torrent speed limits</source>
        <translation>Limites de vitesse du torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="26"/>
        <source>Download:</source>
        <translation>Téléchargement:</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="33"/>
        <location filename="../gui/torrentoptionsdialog.ui" line="46"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="36"/>
        <location filename="../gui/torrentoptionsdialog.ui" line="49"/>
        <source> KiB/s</source>
        <translation>KoB/s</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="59"/>
        <source>These will not exceed the global limits</source>
        <translation>Celles-ci ne dépasseront pas les limites globales</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="66"/>
        <source>Upload:</source>
        <translation>Émission:</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="90"/>
        <source>Torrent share limits</source>
        <translation>Limites de partage du torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="96"/>
        <source>Use global share limit</source>
        <translation>Utiliser la limite de partage globale</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="106"/>
        <source>Set no share limit</source>
        <translation>Définir aucune limite de partage</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="118"/>
        <source>Set share limit to</source>
        <translation>Définir la limite de partage à</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="128"/>
        <source>minutes</source>
        <translation>minutes</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="171"/>
        <source>ratio</source>
        <translation>ratio</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="185"/>
        <source>Disable DHT for this torrent</source>
        <translation>Désactiver DHT pour ce torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="205"/>
        <source>Disable PeX for this torrent</source>
        <translation>Désactiver PeX pour ce torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="212"/>
        <source>Disable LSD for this torrent</source>
        <translation>Désactivier LSD pour ce torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="239"/>
        <source>Not applicable to private torrents</source>
        <translation>Non applicable aux torrents privés</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="286"/>
        <source>No share limit method selected</source>
        <translation>Aucune méthode de limite de partage sélectionnée </translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="286"/>
        <source>Please select a limit method first</source>
        <translation>Merci de sélectionner d&apos;abord un méthode de limite</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="704"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation>Erreur : &apos;%1&apos; n&apos;est pas un fichier torrent valide.</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="867"/>
        <source>Priority must be an integer</source>
        <translation>La priorité doit être un nombre</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="870"/>
        <source>Priority is not valid</source>
        <translation>Priorité invalide</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="876"/>
        <source>Torrent&apos;s metadata has not yet downloaded</source>
        <translation>Les métadonnées du torrent n’ont pas encore été téléchargées</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="885"/>
        <source>File IDs must be integers</source>
        <translation>Les identifiants de fichier doivent être des entiers</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="887"/>
        <source>File ID is not valid</source>
        <translation>L&apos;ID du fichier n&apos;est pas valide</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1030"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1041"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1052"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1063"/>
        <source>Torrent queueing must be enabled</source>
        <translation>La mise en file d&apos;attente du torrent doit être activée</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1077"/>
        <source>Save path cannot be empty</source>
        <translation>Le répertoire de sauvegarde ne peut être vide</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1164"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1181"/>
        <source>Category cannot be empty</source>
        <translation>La catégorie ne peut être vide</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1170"/>
        <source>Unable to create category</source>
        <translation>Impossible de créer la catégorie</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1184"/>
        <source>Unable to edit category</source>
        <translation>Impossible d&apos;éditer la catégorie</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1081"/>
        <source>Cannot make save path</source>
        <translation>Impossible de créer le répertoire de destination</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="285"/>
        <source>&apos;sort&apos; parameter is invalid</source>
        <translation>Le paramètre de tri &apos;sort&apos; est invalide</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="532"/>
        <source>&quot;%1&quot; is not a valid file index.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="534"/>
        <source>Index %1 is out of bounds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1085"/>
        <source>Cannot write to directory</source>
        <translation>Ecriture impossible dans le répertoire</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1089"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>Définir l&apos;emplacement WebUI : déplacement de « %1 », de « %2 » vers « %3 »</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1103"/>
        <source>Incorrect torrent name</source>
        <translation>Nom de torrent incorrect</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1152"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1167"/>
        <source>Incorrect category name</source>
        <translation>Nom de catégorie incorrect</translation>
    </message>
</context>
<context>
    <name>TrackerEntriesDialog</name>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="14"/>
        <source>Edit trackers</source>
        <translation>Éditer les trackers</translation>
    </message>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="20"/>
        <source>One tracker URL per line.

- You can split the trackers into groups by inserting blank lines.
- All trackers within the same group will belong to the same tier.
- The group on top will be tier 0, the next group tier 1 and so on.
- Below will show the common subset of trackers of the selected torrents.</source>
        <translation>Une URL de tracker par ligne.

- Vous pouvez diviser les trackers en groupes en insérant des lignes vierges.
- Tous les trackers du même groupe appartiendront au même niveau.
- Le groupe en haut sera le niveau 0, le prochain groupe de niveau 1 et ainsi de suite.
- Ci-dessous s&apos;affichera le sous-ensemble commun de trackers des torrents sélectionnés.</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="301"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Tous (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="304"/>
        <source>Trackerless (0)</source>
        <translation>Sans tracker (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="307"/>
        <source>Error (0)</source>
        <translation>Erreur (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="310"/>
        <source>Warning (0)</source>
        <translation>Alerte (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="354"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="419"/>
        <source>Trackerless (%1)</source>
        <translation>Sans tracker (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="466"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="494"/>
        <source>Error (%1)</source>
        <translation>Erreur (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="480"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="506"/>
        <source>Warning (%1)</source>
        <translation>Alerte (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="561"/>
        <source>Resume torrents</source>
        <translation>Démarrer les torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="563"/>
        <source>Pause torrents</source>
        <translation>Mettre en pause les torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="565"/>
        <source>Delete torrents</source>
        <translation>Supprimer les torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="590"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="604"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Tous (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="281"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="389"/>
        <source>Working</source>
        <translation>En fonction</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="282"/>
        <source>Disabled</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="283"/>
        <source>Disabled for this torrent</source>
        <translation>Désactivé pour ce torrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="312"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="173"/>
        <source>This torrent is private</source>
        <translation>Ce torrent est privé</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="392"/>
        <source>Updating...</source>
        <translation>Mise à jour...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="395"/>
        <source>Not working</source>
        <translation>Ne fonctionne pas</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="398"/>
        <source>Not contacted yet</source>
        <translation>Pas encore contacté</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="405"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="408"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="411"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="414"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="508"/>
        <source>Tracker editing</source>
        <translation>Édition du tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="508"/>
        <source>Tracker URL:</source>
        <translation>URL du tracker :</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="514"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="525"/>
        <source>Tracker editing failed</source>
        <translation>Échec d’édition du tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="514"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>L&apos;URL de tracker fournie est invalide. </translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="525"/>
        <source>The tracker URL already exists.</source>
        <translation>L&apos;URL de tracker existe déjà.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="584"/>
        <source>Add a new tracker...</source>
        <translation>Ajouter un nouveau tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="589"/>
        <source>Edit tracker URL...</source>
        <translation>Éditer l&apos;URL du tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="591"/>
        <source>Remove tracker</source>
        <translation>Supprimer le tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="593"/>
        <source>Copy tracker URL</source>
        <translation>Copier l&apos;URL du tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="599"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Forcer le réannoncement sur les trackers sélectionnés</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="602"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forcer le réannoncement sur tous les trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="628"/>
        <source>Tier</source>
        <translation>Niveau</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="629"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="630"/>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="632"/>
        <source>Seeds</source>
        <translation>Sources</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="631"/>
        <source>Peers</source>
        <translation>Pairs</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="633"/>
        <source>Leeches</source>
        <translation>Téléchargeurs</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="634"/>
        <source>Downloaded</source>
        <translation>Téléchargé</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="635"/>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="655"/>
        <source>Column visibility</source>
        <translation>Visibilité de la colonne</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Boîte de dialogue d&apos;ajout de trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Liste des trackers à ajouter (un par ligne) :</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>URL de la liste compatible µTorrent :</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="129"/>
        <source>No change</source>
        <translation>Aucun changement</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="129"/>
        <source>No additional trackers were found.</source>
        <translation>Aucun tracker supplémentaire n&apos;a été trouvé.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="88"/>
        <source>Download error</source>
        <translation>Erreur de téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="89"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>La liste de trackers n&apos;a pas pu être téléchargée, raison : %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="673"/>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="681"/>
        <source>Categories</source>
        <translation>Catégories</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="700"/>
        <source>Tags</source>
        <translation>Étiquettes </translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="718"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="111"/>
        <source>Downloading</source>
        <translation>Téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>En attente</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Downloading metadata</source>
        <comment>Used when loading a magnet link</comment>
        <translation>Téléchargement des métadonnées</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>[F] Downloading</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Téléchargement</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Émission </translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <source>[F] Seeding</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Émission </translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>Queued</source>
        <comment>Torrent is queued</comment>
        <translation>En file d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Vérification</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <source>Checking resume data</source>
        <comment>Used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Vérification des données de reprise</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Paused</source>
        <translation>En pause</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Completed</source>
        <translation>Complété</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>Déplacement</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="126"/>
        <source>Missing Files</source>
        <translation>Fichiers manquants</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="127"/>
        <source>Errored</source>
        <comment>Torrent status, the torrent has an error</comment>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="170"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="171"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Taille</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="172"/>
        <source>Progress</source>
        <comment>% Done</comment>
        <translation>Progression</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="173"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Statut</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="174"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Sources</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="175"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pairs</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="176"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vitesse DL</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="177"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vitesse UP</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="178"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="179"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Temps restant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="180"/>
        <source>Category</source>
        <translation>Catégorie</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="181"/>
        <source>Tags</source>
        <translation>Étiquettes </translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="182"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Ajouté le</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="183"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Terminé le</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="184"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="185"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Vitesse de réception limite</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="186"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Vitesse d&apos;envoi limite</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="187"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Téléchargé</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="188"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Téléversé</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="189"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Session DL</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="190"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Session UP</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="191"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="192"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Actif pendant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="193"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Répertoire de destination</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="194"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Complété</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="195"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Limite du ratio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="196"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Dernière fois vu complet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="197"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Dernière activité</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="198"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Taille totale</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="199"/>
        <source>Availability</source>
        <comment>The number of distributed copies of the torrent</comment>
        <translation>Disponibilité</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="251"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="308"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>Il y a %1</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="321"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (partagé pendant %2)</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="586"/>
        <source>Column visibility</source>
        <translation>Visibilité des colonnes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="337"/>
        <source>Choose save path</source>
        <translation>Choix du répertoire de destination</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="567"/>
        <source>Recheck confirmation</source>
        <translation>Revérifier la confirmation</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="567"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Êtes-vous sur de vouloir revérifier le ou les torrent(s) sélectionné(s) ?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="760"/>
        <source>Rename</source>
        <translation>Renommer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="760"/>
        <source>New name:</source>
        <translation>Nouveau nom :</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="800"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Démarrer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="804"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forcer la reprise</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="802"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Mettre en pause</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="547"/>
        <source>Unable to preview</source>
        <translation>Impossible de prévisualiser</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="547"/>
        <source>The selected torrent &quot;%1&quot; does not contain previewable files</source>
        <translation>Le torrent sélectionné &quot;%1&quot; ne contient pas de fichier prévisualisable</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="663"/>
        <source>Add Tags</source>
        <translation>Ajouter des étiquettes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="706"/>
        <source>Remove All Tags</source>
        <translation>Supprimer toutes les étiquettes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="706"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Supprimer toutes les étiquettes des torrents sélectionnés ?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="721"/>
        <source>Comma-separated tags:</source>
        <translation>Étiquettes séparées par des virgules :</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="730"/>
        <source>Invalid tag</source>
        <translation>Étiquette invalide</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="731"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>Nom d&apos;étiquette : &apos;%1&apos; est invalide</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="806"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="808"/>
        <source>Preview file...</source>
        <translation>Prévisualiser le fichier…</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="812"/>
        <source>Open destination folder</source>
        <translation>Ouvrir le répertoire de destination</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="814"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Déplacer vers le haut</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="816"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Déplacer vers le bas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="818"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Déplacer tout en haut</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="820"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Déplacer tout en bas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="822"/>
        <source>Set location...</source>
        <translation>Chemin de sauvegarde…</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="826"/>
        <source>Force reannounce</source>
        <translation>Forcer une nouvelle annonce</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="828"/>
        <source>Magnet link</source>
        <translation>Lien Magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="830"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="832"/>
        <source>Hash</source>
        <translation>Hachage</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1077"/>
        <source>Queue</source>
        <translation>Liste d&apos;attente</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1085"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="840"/>
        <source>Download first and last pieces first</source>
        <translation>Télécharger premières et dernières pièces en premier</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="810"/>
        <source>Torrent options...</source>
        <translation>Options torrent...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="842"/>
        <source>Automatic Torrent Management</source>
        <translation>Gestion de torrent automatique</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="843"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Le mode automatique signifie que certaines propriétés du torrent (ex: le répertoire de destination) seront décidés via la catégorie associée</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="845"/>
        <source>Edit trackers...</source>
        <translation>Éditer les trackers...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="970"/>
        <source>Category</source>
        <translation>Catégorie</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="972"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nouvelle…</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="974"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Réinitialiser</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="995"/>
        <source>Tags</source>
        <translation>Étiquettes </translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="997"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Ajouter...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="999"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Supprimer tout</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="824"/>
        <source>Force recheck</source>
        <translation>Forcer une revérification</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="834"/>
        <source>Super seeding mode</source>
        <translation>Mode de super-partage</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="836"/>
        <source>Rename...</source>
        <translation>Renommer…</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="838"/>
        <source>Download in sequential order</source>
        <translation>Téléchargement séquentiel</translation>
    </message>
</context>
<context>
    <name>UIThemeManager</name>
    <message>
        <location filename="../gui/uithememanager.cpp" line="88"/>
        <source>Failed to load UI theme from file: &quot;%1&quot;</source>
        <translation>Échec du chargement du thème de l&apos;interface depuis le fichier : &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="110"/>
        <source>Couldn&apos;t apply theme stylesheet. stylesheet.qss couldn&apos;t be opened. Reason: %1</source>
        <translation>La feuille de style du thème n&apos;a pas pu être appliquée : stylesheet.qss n&apos;a pas pu être ouvert. Raison&#xa0;: %1</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="205"/>
        <source>Failed to open &quot;%1&quot;. Reason: %2</source>
        <translation>Échec de l&apos;ouverture &quot;%1&quot;. Motif : %2</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="213"/>
        <location filename="../gui/uithememanager.cpp" line="218"/>
        <source>&quot;%1&quot; has invalid format. Reason: %2</source>
        <translation>&quot;%1&quot; a un format invalide. Motif : %2</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="218"/>
        <source>Root JSON value is not an object</source>
        <translation>La valeur dans la racine du JSON n&apos;est pas un objet</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="228"/>
        <source>Invalid color for ID &quot;%1&quot; is provided by theme</source>
        <translation>Une couleur invalide pour l&apos;identifiant &quot;%1&quot; est fournie par le thème</translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="84"/>
        <source>Python detected, executable name: &apos;%1&apos;, version: %2</source>
        <translation>Python détecté, nom de l&apos;exécutable: &apos;%1&apos;, version: %2</translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="288"/>
        <source>Python not detected</source>
        <translation>Python non détecté</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="188"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation>Type de fichier inacceptable, seul le fichier normal est autorisé.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="196"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation>Les liens symboliques sont interdits dans les dossiers d&apos;interfaces alternatives.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="330"/>
        <source>Using built-in Web UI.</source>
        <translation>Utilisation de l&apos;interface intégrée Web UI.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="332"/>
        <source>Using custom Web UI. Location: &quot;%1&quot;.</source>
        <translation>Utilisation d&apos;une interface personnalisée Web UI. Emplacement: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="344"/>
        <source>Web UI translation for selected locale (%1) has been successfully loaded.</source>
        <translation>La traduction de Web UI pour les paramètres régionaux sélectionnés (%1) a été chargée avec succès.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="349"/>
        <source>Couldn&apos;t load Web UI translation for selected locale (%1).</source>
        <translation>Impossible de charger la traduction de Web UI pour les paramètres régionaux sélectionnés (%1).</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="397"/>
        <source>Missing &apos;:&apos; separator in WebUI custom HTTP header: &quot;%1&quot;</source>
        <translation>Séparateur &apos;:&apos; manquant dans l&apos;en-tête HTTP personnalisé du WebUI : « %1 »</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="444"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation>Taille de fichier maximale autorisée dépassée (%1)!</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="652"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>WebUI : Disparité entre l&apos;en-tête d&apos;origine et l&apos;origine de la cible! IP source : &apos;%1&apos;. En-tête d&apos;origine : &apos;%2&apos;. Origine de la cible : &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="662"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>WebUI : Disparité entre l&apos;en-tête du référent et l&apos;origine de la cible! IP source : &apos;%1&apos;. En-tête du référent : &apos;%2&apos;. Origine de la cible : &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="680"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation>WebUI : En-tête d&apos;hôte invalide, non-concordance du port. IP source de la requête : &apos;%1&apos;. Port du serveur : &apos;%2&apos;. En-tête d&apos;hôte reçu : &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="701"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation>WebUI : En-tête d&apos;hôte invalide. IP source de la requête : &apos;%1&apos;. En-tête d&apos;hôte reçu : &apos;%2&apos;</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Web UI : configuration HTTPS réussie</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="105"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Web UI : Échec de la configuration HTTPS, retour à HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="119"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>Web UI : En écoute sur IP : %1, port : %2</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="123"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Web UI : Impossible de se lier à l&apos;adresse IP : %1, port : %2. Raison : %3</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="73"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>Oct</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="74"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>Kio</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="75"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>Mio</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="76"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>Gio</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="77"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>Tio</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="78"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>Pio</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="79"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>Eio</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="257"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="374"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="381"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1j %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="386"/>
        <source>%1y %2d</source>
        <comment>e.g: 2years 10days</comment>
        <translation>%1a %2j</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="265"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Inconnue</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="144"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent va maintenant éteindre l&apos;ordinateur car tous les téléchargements sont terminés.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="364"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1min</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="368"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1min</translation>
    </message>
</context>
</TS>
