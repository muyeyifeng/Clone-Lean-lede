<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi_IN">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>क्यूबिटटाॅरेंट के बारे में</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation>बारे में</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Author</source>
        <translation>रचनाकार</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>वर्तमान अनुरक्षक</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation>ग्रीस</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation>नागरिकता:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation>ईमेल:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation>नाम:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation>मूल निर्माता</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation>फ्रांस</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>सादर आभार</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation>अनुवादक</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="296"/>
        <source>License</source>
        <translation>लाइसेंस</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="322"/>
        <source>Software Used</source>
        <translation>प्रयुक्त सॉफ्टवेयर</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="328"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>क्यूबिटटाॅरेंट निम्नलिखित लाइब्रेरी द्वारा निर्मित है :</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="66"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>C++ कोड प्रयुक्त कर क्यूटी टूलकिट व libtorrent-rasterbar आधारित, एक उन्नत बिट टोरेंट साधन।</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="67"/>
        <source>Copyright %1 2006-2021 The qBittorrent project</source>
        <translation>कॉपीराइट %1 2006-2021 क्यूबिटटाॅरेंट परियोजना</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="68"/>
        <source>Home Page:</source>
        <translation>होम पृष्ठ:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="69"/>
        <source>Forum:</source>
        <translation>चर्चा मंच:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="70"/>
        <source>Bug Tracker:</source>
        <translation>समस्या ट्रैकर:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="110"/>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>पीयर देशों के समन्वय हेतु DB-IP द्वारा प्रदान निशुल्क IP to Country Lite डेटाबेस उपयोग में है। यह डेटाबेस Creative Commons Attribution 4.0 अंतर्राष्ट्रीय लाइसेंस के तहत है।</translation>
    </message>
</context>
<context>
    <name>AbstractFileStorage</name>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="60"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="102"/>
        <source>The old path is invalid: &apos;%1&apos;.</source>
        <translation>पुराना पथ अमान्य है: &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="62"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="104"/>
        <source>The new path is invalid: &apos;%1&apos;.</source>
        <translation>नया पथ अमान्य है: &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="66"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="70"/>
        <source>Invalid file path: &apos;%1&apos;.</source>
        <translation>फाइल पथ अमान्य है: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="72"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="115"/>
        <source>Absolute path isn&apos;t allowed: &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="82"/>
        <source>The file already exists: &apos;%1&apos;.</source>
        <translation>फाइल पहले से ही है: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="86"/>
        <source>No such file: &apos;%1&apos;.</source>
        <translation>ऐसी फाइल नहीं है: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="127"/>
        <source>The folder already exists: &apos;%1&apos;.</source>
        <translation>फोल्डर पहले से ही है: &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="131"/>
        <source>No such folder: &apos;%1&apos;.</source>
        <translation>कोई ऐसा फोल्डर नहीं मिला: &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Save at</source>
        <translation>यहाँ संचित करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="398"/>
        <source>Never show again</source>
        <translation>पुनः न दिखाएँ</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="99"/>
        <source>Torrent settings</source>
        <translation>टाॅरेंट सेटिंग्स</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="132"/>
        <source>Set as default category</source>
        <translation>डिफ़ॉल्ट श्रेणी के रूप में सेट करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Category:</source>
        <translation>श्रेणी:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="172"/>
        <source>Start torrent</source>
        <translation>टाॅरेंट आरंभ करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="249"/>
        <source>Torrent information</source>
        <translation>टौरेंट सूचना</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="158"/>
        <source>Skip hash check</source>
        <translation>हैश जाँच निरस्त</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="196"/>
        <source>Content layout:</source>
        <translation>सामग्री का अभिविन्यास:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="207"/>
        <source>Original</source>
        <translation>मूल</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="212"/>
        <source>Create subfolder</source>
        <translation>उपफोल्डर बनायें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="217"/>
        <source>Don&apos;t create subfolder</source>
        <translation>उपफोल्डर न बनायें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="255"/>
        <source>Info hash v1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="334"/>
        <source>Size:</source>
        <translation>आकार:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="324"/>
        <source>Comment:</source>
        <translation>टिप्पणी:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="351"/>
        <source>Date:</source>
        <translation>दिनांक:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="41"/>
        <source>Torrent Management Mode:</source>
        <translation>टौरेंट प्रबंधन मोड:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="48"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>स्वतः मोड यानि टोरेंट विशेषताएँ (संचय पथ आदि) संबंधित श्रेणी द्वारा निर्धारित होगी</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="52"/>
        <source>Manual</source>
        <translation>स्वयं</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="57"/>
        <source>Automatic</source>
        <translation>स्वतः</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Remember last used save path</source>
        <translation>अंतिम बार प्रयुक्त संचय पथ स्मरण करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="141"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>चिन्हित होने पर, विकल्प विंडो की &quot;डाउनलोड&quot; सेटिंग्स सेट होने पर भी .torrent फाइल हटाई नहीं जाएगी</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Do not delete .torrent file</source>
        <translation>.torrent फाइल न मिटाएं</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="165"/>
        <source>Download in sequential order</source>
        <translation>क्रमबद्ध डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="151"/>
        <source>Download first and last pieces first</source>
        <translation>प्रथम व अंतिम खण्ड सबसे पहले डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="358"/>
        <source>Info hash v2:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="450"/>
        <source>Save as .torrent file...</source>
        <translation>.torrent फाइल के रूप में संचित करें...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="564"/>
        <source>Normal</source>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="568"/>
        <source>High</source>
        <translation>उच्च</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="572"/>
        <source>Maximum</source>
        <translation>सर्वोच्च</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="560"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="581"/>
        <source>Do not download</source>
        <translation>डाउनलोड न करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="480"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="669"/>
        <source>I/O Error</source>
        <translation>इनपुट/आउटपुट त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="259"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="756"/>
        <source>Invalid torrent</source>
        <translation>अमान्य टाॅरेंट</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="703"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>अनुपलब्ध</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="704"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>अनुपलब्ध</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="713"/>
        <source>Not available</source>
        <translation>अनुपलब्ध</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="310"/>
        <source>Invalid magnet link</source>
        <translation>अमान्य मैगनेट लिंक</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="260"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>टोरेंट लोड करना विफल : %1।
त्रुटि : %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="310"/>
        <source>This magnet link was not recognized</source>
        <translation>अज्ञात मैग्नेट लिंक</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="345"/>
        <source>Magnet link</source>
        <translation>अज्ञात मैग्नेट लिंक</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="351"/>
        <source>Retrieving metadata...</source>
        <translation>मेटाडाटा प्राप्ति जारी...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="105"/>
        <source>Choose save path</source>
        <translation>संचय पथ चुनें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="283"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="294"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="331"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="336"/>
        <source>Torrent is already present</source>
        <translation>टोरेंट पहले से मौजूद है</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="283"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation>टोरेंट &quot;%1&quot; अंतरण सूची में पहले से मौजूद है। निजी टोरेंट होने के कारण ट्रैकर विलय नहीं हुआ।</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>टोरेंट &quot;%1&quot; अंतरण सूची में पहले से मौजूद है। ट्रैकर विलय हुआ।</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="294"/>
        <source>Torrent is already queued for processing.</source>
        <translation>टोरेंट संसाधन हेतु पंक्तिबद्ध है।</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="299"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="300"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="352"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="353"/>
        <source>N/A</source>
        <translation>लागू नहीं</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="331"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>मैग्नेट लिंक &quot;%1&quot; अंतरण सूची में पहले से मौजूद है। ट्रैकर विलय हुआ।</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="336"/>
        <source>Magnet link is already queued for processing.</source>
        <translation>मैग्नेट लिंक संसाधन हेतु पंक्तिबद्ध है।</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="419"/>
        <source>%1 (Free space on disk: %2)</source>
        <translation>%1 (डिस्क पर अप्रयुक्त स्पेस : %2)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="420"/>
        <source>Not available</source>
        <comment>This size is unavailable.</comment>
        <translation>अनुपलब्ध</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="463"/>
        <source>Torrent file (*%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="466"/>
        <source>Save as torrent file</source>
        <translation>टोरेंट फाइल के रूप में संचित करें</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="481"/>
        <source>Couldn&apos;t export torrent metadata file &apos;%1&apos;. Reason: %2.</source>
        <translation>टाॅरेंट मेटाडाटा फाइल &apos;%1&apos; का निर्यात नहीं हो सका। कारण: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="577"/>
        <source>By shown file order</source>
        <translation>फ़ाइल अनुक्रम में दिखाया गया है </translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="585"/>
        <source>Normal priority</source>
        <translation>सामान्य वरीयता</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="589"/>
        <source>High priority</source>
        <translation>उच्च वरीयता</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="593"/>
        <source>Maximum priority</source>
        <translation>सर्वोच्च वरीयता</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="598"/>
        <source>Priority by shown file order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="687"/>
        <source>Cannot create v2 torrent until its data is fully downloaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="776"/>
        <source>Cannot download &apos;%1&apos;: %2</source>
        <translation>&apos;%1&apos; डाउनलोड विफल : %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="555"/>
        <source>Rename...</source>
        <translation>नाम बदलें…</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="559"/>
        <source>Priority</source>
        <translation>प्राथमिकता</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="670"/>
        <source>Invalid metadata</source>
        <translation>अमान्य मेटाडेटा</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="677"/>
        <source>Parsing metadata...</source>
        <translation>मेटाडेटा प्राप्यता जारी...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="681"/>
        <source>Metadata retrieval complete</source>
        <translation>मेटाडेटा प्राप्ति पूर्ण</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="756"/>
        <source>Failed to load from URL: %1.
Error: %2</source>
        <translation>यूआरएल से लोड करना विफल : %1।
त्रुटि : %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="775"/>
        <source>Download Error</source>
        <translation>डाउनलोड त्रुटि</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="329"/>
        <location filename="../gui/advancedsettings.cpp" line="471"/>
        <source> MiB</source>
        <translation>एमबी</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="558"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>जावक पोर्ट (न्यूनतम) [0: निष्क्रिय]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="565"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>जावक पोर्ट (अधिकतम) [0: निष्क्रिय]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="607"/>
        <source>Recheck torrents on completion</source>
        <translation>पूर्ण होने पर टाॅरेंट पुनः जाँचें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="613"/>
        <source>Transfer list refresh interval</source>
        <translation>अंतरण सूची रिफ्रेश अंतराल</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="612"/>
        <location filename="../gui/advancedsettings.cpp" line="676"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>मिली सेकंड</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="152"/>
        <source>Setting</source>
        <translation>सेटिंग</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="152"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>मान</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="325"/>
        <location filename="../gui/advancedsettings.cpp" line="338"/>
        <source> (disabled)</source>
        <translation>(निष्क्रिय)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="327"/>
        <source> (auto)</source>
        <translation>(स्वत:)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="336"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation>मिनट</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="349"/>
        <source>All addresses</source>
        <translation>सभी पते</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="395"/>
        <source>qBittorrent Section</source>
        <translation>क्यूबिटटोरेंट खंड</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="392"/>
        <location filename="../gui/advancedsettings.cpp" line="400"/>
        <source>Open documentation</source>
        <translation>शास्त्र खोलें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source>All IPv4 addresses</source>
        <translation>सभी आईपी4 पते</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="351"/>
        <source>All IPv6 addresses</source>
        <translation>सभी आईपी6 पते</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="403"/>
        <source>libtorrent Section</source>
        <translation>libtorrent खंड</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="406"/>
        <source>Fastresume files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="406"/>
        <source>SQLite database (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="408"/>
        <source>Resume data storage type (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Normal</source>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Below normal</source>
        <translation>सामान्य से कम</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Medium</source>
        <translation>मध्यम</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Low</source>
        <translation>कम</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Very low</source>
        <translation>सबसे कम</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="433"/>
        <source>Process memory priority (Windows &gt;= 8 only)</source>
        <translation>प्रक्रिया मेमोरी प्राथमिकता (केवल विंडोज &gt;=8 हेतु)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="442"/>
        <source>Asynchronous I/O threads</source>
        <translation>अतुल्यकालिक इनपुट/आउटपुट प्रक्रिया</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="450"/>
        <source>Hashing threads</source>
        <translation>हैश प्रक्रिया</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="458"/>
        <source>File pool size</source>
        <translation>फाइल पूल आकार</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="472"/>
        <source>Outstanding memory when checking torrents</source>
        <translation>टोरेंट जाँच हेतु सक्रिय मेमोरी</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="488"/>
        <source>Disk cache</source>
        <translation>डिस्क कैश</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="494"/>
        <location filename="../gui/advancedsettings.cpp" line="572"/>
        <location filename="../gui/advancedsettings.cpp" line="659"/>
        <location filename="../gui/advancedsettings.cpp" line="750"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation>सेकंड</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="495"/>
        <source>Disk cache expiry interval</source>
        <translation>डिस्क कैश मान्यता समाप्ति अंतराल</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="500"/>
        <source>Enable OS cache</source>
        <translation>OS कैश चालू करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="505"/>
        <source>Coalesce reads &amp; writes</source>
        <translation>कॉलेसक पढ़ना और लिखना </translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="510"/>
        <source>Use piece extent affinity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="513"/>
        <source>Send upload piece suggestions</source>
        <translation>खण्डों को अपलोड करने के सुझावों को भेजें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="518"/>
        <location filename="../gui/advancedsettings.cpp" line="524"/>
        <source> KiB</source>
        <translation>केबी</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="520"/>
        <source>Send buffer watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="526"/>
        <source>Send buffer low watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="532"/>
        <source>Send buffer watermark factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="538"/>
        <source>Outgoing connections per second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="544"/>
        <source>Socket backlog size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="573"/>
        <source>UPnP lease duration [0: Permanent lease]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="579"/>
        <source>Type of service (ToS) for connections to peers</source>
        <translation>सहकर्मियों के कनेक्शानों के लिए सेवा का प्रकार (ToS)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="582"/>
        <source>Prefer TCP</source>
        <translation>TCP को वरीयता</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="582"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="589"/>
        <source>Support internationalized domain name (IDN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="594"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="599"/>
        <source>Validate HTTPS tracker certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="604"/>
        <source>Disallow connection to peers on privileged ports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="619"/>
        <source>Resolve peer host names</source>
        <translation>सहकर्मी के होस्ट के नाम दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="675"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="677"/>
        <source>Notification timeout [0: infinite]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="681"/>
        <source>Reannounce to all trackers when IP or port changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="695"/>
        <source>Enable icons in menus</source>
        <translation>मेनू में चित्र दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="740"/>
        <source>Peer turnover disconnect percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="746"/>
        <source>Peer turnover threshold percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="752"/>
        <source>Peer turnover disconnect interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="660"/>
        <source>Stop tracker timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="666"/>
        <source>Display notifications</source>
        <translation>नोटिफिकेशन दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="669"/>
        <source>Display notifications for added torrents</source>
        <translation>जोड़े गए टौरेंटों के लिए नोटिफिकेशन दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="684"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>ट्रैकर का प्रतीक चित्र डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="688"/>
        <source>Save path history length</source>
        <translation>इतने सञ्चय पथ याद रखें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="691"/>
        <source>Enable speed graphs</source>
        <translation>गति के ग्राफ दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="706"/>
        <source>Fixed slots</source>
        <translation>निश्चित स्लॉट</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="706"/>
        <source>Upload rate based</source>
        <translation>अपलोड दर पर आधारित</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="708"/>
        <source>Upload slots behavior</source>
        <translation>अपलोड स्लॉटों का व्यवहार</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="711"/>
        <source>Round-robin</source>
        <translation>राउंड-रॉबिन</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="711"/>
        <source>Fastest upload</source>
        <translation>तीव्रतम अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="711"/>
        <source>Anti-leech</source>
        <translation>जोंकरोधी</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="713"/>
        <source>Upload choking algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="718"/>
        <source>Confirm torrent recheck</source>
        <translation>टाॅरेंट पुनर्जांच की पुष्टि करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="722"/>
        <source>Confirm removal of all tags</source>
        <translation>सभी उपनामों को हटाने की पुष्टि करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="726"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>एक परत पर हमेशा सभी ट्रैकर्स को सूचित करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="732"/>
        <source>Always announce to all tiers</source>
        <translation>हमेशा सभी परतो पर घोषणा करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="621"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>कोई भी पद्धति</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="553"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>प्रारम्भ करने का अन्तराल संचित करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="584"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="616"/>
        <source>Resolve peer countries</source>
        <translation>सहकर्मी के देशों को दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="643"/>
        <source>Network interface</source>
        <translation>नेटवर्क पद्धति</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="646"/>
        <source>Optional IP address to bind to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="649"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>ट्रैकर हेतु आईपी पता (पुनः आरंभ आवश्यक)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="655"/>
        <source>Max concurrent HTTP announces</source>
        <translation>एकसाथ अधिकतम एचटीटीपी उद्घोषणाएं</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="699"/>
        <source>Enable embedded tracker</source>
        <translation>सम्मिलित ट्रैकर सक्रिय करें</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="704"/>
        <source>Embedded tracker port</source>
        <translation>सम्मिलित ट्रैकर का पोर्ट</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="184"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>क्यूबिटटोरेंट %1 आरंभ</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="187"/>
        <source>Running in portable mode. Auto detected profile folder at: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="189"/>
        <source>Redundant command line flag detected: &quot;%1&quot;. Portable mode implies relative fastresume.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="193"/>
        <source>Using config directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="392"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>टाॅरेंट: %1, बाहरी प्रोग्राम चलाया जा रहा है, कमाण्ड: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="450"/>
        <source>Torrent name: %1</source>
        <translation>टौरेंट नाम: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="451"/>
        <source>Torrent size: %1</source>
        <translation>टौरेंट आकार: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="452"/>
        <source>Save path: %1</source>
        <translation>संचय पथ: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="453"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>टाॅरेंट %1 में डाउनलोड हुआ।</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="455"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>क्यूबिटटोरेंट उपयोग करने हेतु धन्यवाद।</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="462"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[क्यूबिटटोरेंट] &apos;%1&apos; का डाउनलोड पूर्ण</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="477"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>टाॅरेंट: %1, मेल अधिसूचना भेज रहा है</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="647"/>
        <source>Application failed to start.</source>
        <translation>एप्लीकशन शुरू होने में असफल हुई।</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="660"/>
        <source>Information</source>
        <translation>सूचना</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="661"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation>क्यूबिटटोरेंट प्रबंधन हेतु, %1 से वेब उपयोक्ता अंतरफलक अभिगम करें</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="667"/>
        <source>The Web UI administrator username is: %1</source>
        <translation>वेब UI संचालक का यूजरनेम है: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="668"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>वेब UI संचालक का पासवर्ड अभी भी डिफ़ॉल्ट है: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="669"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="801"/>
        <source>Saving torrent progress...</source>
        <translation>टाॅरेंट की प्रगति सञ्चित हो रही है</translation>
    </message>
</context>
<context>
    <name>AsyncFileStorage</name>
    <message>
        <location filename="../base/asyncfilestorage.cpp" line="42"/>
        <source>Could not create directory &apos;%1&apos;.</source>
        <translation>फोल्डर &apos;%1&apos; नहीं बन सका|</translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="53"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="57"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="73"/>
        <source>WebAPI login success. IP: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="80"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="243"/>
        <source>Save to:</source>
        <translation>यहाँ संचित करें :</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>RSS डाउनलोडर</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>RSS टाॅरेंटों का स्वतः डाउनलोड अब अक्षम है! आप इसे एप्लीकेशन सेटिंग में सक्षम कर सकते हैं।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>डाउनलोड के नियम</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>नियम की परिभाषा</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>रेग्यूलर एक्सप्रेशनों का उपयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation>बुद्धिमान एपिसोड फिल्टर का प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>शामिल होना चाहिए:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>शामिल नहीं होना चाहिए:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>एपिसोड फिल्टर:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>स्मार्ट एपिसोड फिल्टर एपिसोड के दुहराव से बचाने के लिए एपिसोड संख्या को चेक करेगा।
प्रारूप S01E01, 1x1, 2017.12.31 व 31.12.2017 समर्थित हैं (दिनांक के प्रारूप में - का प्रयोग भी कर सकते हैं)।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Category:</source>
        <translation>श्रेणी:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="231"/>
        <source>Save to a Different Directory</source>
        <translation>दूसरे फोल्डर में सञ्चय करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="257"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <extracomment>... X days</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="267"/>
        <source>Disabled</source>
        <translation>अक्षम</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="270"/>
        <source> days</source>
        <translation>दिन</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="303"/>
        <source>Add Paused:</source>
        <translation>विरामित जोड़ें:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="311"/>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="347"/>
        <source>Use global settings</source>
        <translation>सार्वभौम सैटिंग का प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="316"/>
        <source>Always</source>
        <translation>हमेशा</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="321"/>
        <source>Never</source>
        <translation>कभी नहीं</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="339"/>
        <source>Torrent content layout:</source>
        <translation>टाॅरेंट सामग्री का अभिविन्यास:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="352"/>
        <source>Original</source>
        <translation>मूल</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="357"/>
        <source>Create subfolder</source>
        <translation>उपफोल्डर बनायें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="362"/>
        <source>Don&apos;t create subfolder</source>
        <translation>उपफोल्डर न बनायें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="383"/>
        <source>Apply Rule to Feeds:</source>
        <translation>स्रोतों पर नियम लागू करें:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="405"/>
        <source>Matching RSS Articles</source>
        <translation>मिलान वाले RSS लेख</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="433"/>
        <source>&amp;Import...</source>
        <translation>आयात&amp;...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="443"/>
        <source>&amp;Export...</source>
        <translation>निर्यात&amp; करें...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Matches articles based on episode filter.</source>
        <translation>लेखों का एपिसोड फिल्टर के आधार पर मिलान करता है।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Example: </source>
        <translation>उदाहरण:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>सीजन एक के 2, 5, 8 से 15, 30 व आगे तक के एपिसोडों से मिलान करेगा</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Episode filter rules: </source>
        <translation>एपिसोड फिल्टर के नियम:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>सीजन क्रमांक एक अनिवार्य व अशून्य संख्या है</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="95"/>
        <source>Filter must end with semicolon</source>
        <translation>फिल्टर सेमीकोलन पर समाप्त होना चाहिए</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="96"/>
        <source>Three range types for episodes are supported: </source>
        <translation>एपिसोडों के लिए तीन तरह की सीमाएं समर्थित हैं:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="97"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>एकल संख्या: &lt;b&gt;1x25;&lt;/b&gt; सीजन एक के 25वें एपिसोड से मिलान करता है</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="98"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>सामान्य चाप: &lt;b&gt;1x25-40;&lt;/b&gt; सीजन एक के 25 से 40 तक एपिसोडों का मिलान करता है</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>सीजन क्रमांक एक अनिवार्य व अशून्य संख्या है</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="64"/>
        <source>Rules</source>
        <translation>नियम</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="65"/>
        <source>Rules (legacy)</source>
        <translation>नियम (पुराने)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="99"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>असीमित चाप: &lt;b&gt;1x25-;&lt;/b&gt; सीजन एक के 25 से आगे के एपिसोडों का मिलान करता है</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="286"/>
        <source>Last Match: %1 days ago</source>
        <translation>अन्तिम मिलान: %1 दिन पहले</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="288"/>
        <source>Last Match: Unknown</source>
        <translation>अन्तिम मिलान: अज्ञात</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>New rule name</source>
        <translation>नए नियम का नाम</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>Please type the name of the new download rule.</source>
        <translation>नए डाउनलोड नियम का नाम टाइप करें।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="386"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="552"/>
        <source>Rule name conflict</source>
        <translation>नियम नाम विरुद्ध</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="387"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="553"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>इस नाम का नियम पहले से मौजूद है, कृपया अन्य नाम उपयोग करें।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="401"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>क्या आप निश्चिंत है कि आप डाउनलोड नियम &apos;%1&apos; को हटाना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="403"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>क्या आप निश्चित ही चयनित डाउनलोड नियम हटाना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="404"/>
        <source>Rule deletion confirmation</source>
        <translation>नियम हटाने हेतु पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Destination directory</source>
        <translation>लक्ष्य डायरेक्टरी</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="426"/>
        <source>Invalid action</source>
        <translation>अमान्य चाल</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>सूची खाली है, निर्यात करने के लिए कुछ भी नहीं है।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="433"/>
        <source>Export RSS rules</source>
        <translation>RSS नियमों को निर्यात करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="460"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="478"/>
        <source>I/O Error</source>
        <translation>I/O त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="461"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>गंतव्य फाइल बनाने में असफल। कारण: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="469"/>
        <source>Import RSS rules</source>
        <translation>RSS नियमों को आयात करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>फाइल खोलने में असफल। कारण: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="497"/>
        <source>Import Error</source>
        <translation>आयात में त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="498"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>चुनी हुई नियमों की फाइल आयात करने में असफल। कारण: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="507"/>
        <source>Add new rule...</source>
        <translation>नया नियम जोड़ें…</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="516"/>
        <source>Delete rule</source>
        <translation>नियम मिटायें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="519"/>
        <source>Rename rule...</source>
        <translation>नियम का नाम बदलें…</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="524"/>
        <source>Delete selected rules</source>
        <translation>चयनित नियम हटाएँ</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="529"/>
        <source>Clear downloaded episodes...</source>
        <translation>डाउनलोड किये हुए एपिसोडों को हटायें...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Rule renaming</source>
        <translation>नियम नाम परिवर्तन</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Please type the new rule name</source>
        <translation>नए नियम का नाम टाइप करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="573"/>
        <source>Clear downloaded episodes</source>
        <translation>डाउनलोड किये हुए एपिसोडों को हटायें</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="574"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>क्या आप निश्चित ही चयनित नियमों के डाउनलोड हो चुके एपिसोडों को सूची से हटाना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="688"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="738"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="785"/>
        <source>Position %1: %2</source>
        <translation>स्थिति %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="692"/>
        <source>Wildcard mode: you can use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="693"/>
        <source>? to match any single character</source>
        <translation>केवल एक अक्षर का मिलान करने के लिए ?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="694"/>
        <source>* to match zero or more of any characters</source>
        <translation>शून्य या अधिक अक्षरों का मिलान करनें के लिए *</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="695"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="696"/>
        <source>| is used as OR operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="697"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="704"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="708"/>
        <source> will match all articles.</source>
        <translation>सभी लेखों से मिलान करेगा।</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="709"/>
        <source> will exclude all articles.</source>
        <translation>किसी भी लेख से मिलान नहीं करेगा।</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>प्रतिबन्धित IP पतों की सूची</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="80"/>
        <source>Ban IP</source>
        <translation>आईपी प्रतिबन्धित&#xa0;करें</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="87"/>
        <source>Delete</source>
        <translation>मिटाएं</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="94"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="106"/>
        <source>Warning</source>
        <translation>चेतावनी</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="94"/>
        <source>The entered IP address is invalid.</source>
        <translation>भरा गया IP पता अमान्य है।</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="106"/>
        <source>The entered IP is already banned.</source>
        <translation>भरा गया IP पहले से ही प्रतिबन्धित है।</translation>
    </message>
</context>
<context>
    <name>BitTorrent::BencodeResumeDataStorage</name>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="112"/>
        <source>Cannot create torrent resume folder: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="309"/>
        <source>Couldn&apos;t load torrents queue from &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="364"/>
        <source>Couldn&apos;t save torrent metadata to &apos;%1&apos;. Error: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="387"/>
        <source>Couldn&apos;t save torrent resume data to &apos;%1&apos;. Error: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="156"/>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="163"/>
        <source>Cannot read file %1: %2</source>
        <translation>फाइल नहीं पढ़ी जा सकी %1: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="412"/>
        <source>Couldn&apos;t save data to &apos;%1&apos;. Error: %2</source>
        <translation>डाटा को &apos;%1&apos; में सञ्चित नहीं कर सके। त्रुटि: %2</translation>
    </message>
</context>
<context>
    <name>BitTorrent::DBResumeDataStorage</name>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="260"/>
        <source>Not found.</source>
        <translation>नहीं मिला।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="264"/>
        <source>Couldn&apos;t load resume data of torrent &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="475"/>
        <source>Couldn&apos;t save torrent metadata. Error: %1.</source>
        <translation>टाॅरेंट मेटाडाटा का सञ्चय नहीं हो सका। त्रुटि: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="519"/>
        <source>Couldn&apos;t store resume data for torrent &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="543"/>
        <source>Couldn&apos;t delete resume data of torrent &apos;%1&apos;. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="588"/>
        <source>Couldn&apos;t store torrents queue positions. Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="565"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>PeX समर्थन बदलने के लिए पुनः आरम्भ करना आवश्यक है</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2434"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2434"/>
        <source>ONLINE</source>
        <translation>ऑनलाइन</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2434"/>
        <source>OFFLINE</source>
        <translation>ऑफलाइन</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2448"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1097"/>
        <location filename="../base/bittorrent/session.cpp" line="2811"/>
        <source>Encryption support [%1]</source>
        <translation>गोपनीयकरण समर्थन [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1098"/>
        <location filename="../base/bittorrent/session.cpp" line="2812"/>
        <source>FORCED</source>
        <translation>बलपूर्वक</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2929"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1096"/>
        <location filename="../base/bittorrent/session.cpp" line="3369"/>
        <source>Anonymous mode [%1]</source>
        <translation>अनाम रीति [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1632"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed torrent and its files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1643"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Enabled super seeding for it.</source>
        <translation>&apos;%1&apos; आपके द्वारा तय अधिकतम अनुपात तक पहुँच गया है। इसे महास्रोत बनायें।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1671"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed torrent and its files.</source>
        <translation>&apos;%1&apos; के लिए आपके द्वारा तय किया गया अधिकतम स्रोत काल समाप्त हो चुका है। टाॅरेंट व इसकी फाइलें हटायें।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1682"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Enabled super seeding for it.</source>
        <translation>&apos;%1&apos; के लिए आपके द्वारा तय किया गया अधिकतम स्रोत काल समाप्त हो चुका है। इसे महास्रोत बनायें।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2329"/>
        <source>Couldn&apos;t export torrent metadata file &apos;%1&apos;. Reason: %2.</source>
        <translation type="unfinished">टाॅरेंट मेटाडाटा फाइल &apos;%1&apos; का निर्यात नहीं हो सका। कारण: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2364"/>
        <source>Error: Aborted saving resume data for %1 outstanding torrents.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2466"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.158.1 isn&apos;t valid.</comment>
        <translation>उपयोग में ली जा रही नेटवर्क पद्धति का पता %1 अमान्य है।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2507"/>
        <location filename="../base/bittorrent/session.cpp" line="2542"/>
        <source>Can&apos;t find the configured address &apos;%1&apos; to listen on</source>
        <comment>Can&apos;t find the configured address &apos;192.168.1.3&apos; to listen on</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3942"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>टाॅरेंट फाइल &apos;%1&apos; को नहीं सुलझा पाया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3998"/>
        <source>Cancelled moving &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4008"/>
        <source>Couldn&apos;t enqueue move of &quot;%1&quot; to &quot;%2&quot;. Torrent is currently moving to the same destination location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4017"/>
        <source>Couldn&apos;t enqueue move of &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;. Both paths point to the same location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4025"/>
        <source>Enqueued to move &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4042"/>
        <source>Moving &quot;%1&quot; to &quot;%2&quot;...</source>
        <translation>&quot;%1&quot; को &quot;%2&quot; पर ले जा रहे हैं...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4154"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>टाॅरेंट फाइल &apos;%2&apos; में जड़ी हुई फाइल &apos;%1&apos; का पुनरावर्ती डाउनलोड</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4497"/>
        <source>Couldn&apos;t load torrent. Reason: %1.</source>
        <translation>टाॅरेंट लोड नहीं हो सका। कारण: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4645"/>
        <source>IP filter</source>
        <comment>this peer was blocked. Reason: IP filter.</comment>
        <translation>IP फिल्टर</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4648"/>
        <source>port filter</source>
        <comment>this peer was blocked. Reason: port filter.</comment>
        <translation>पोर्ट फिल्टर</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4651"/>
        <source>%1 mixed mode restrictions</source>
        <comment>this peer was blocked. Reason: I2P mixed mode restrictions.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4654"/>
        <source>use of privileged port</source>
        <comment>this peer was blocked. Reason: use of privileged port.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4657"/>
        <source>%1 is disabled</source>
        <comment>this peer was blocked. Reason: uTP is disabled.</comment>
        <translation>%1 अक्षम है</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4660"/>
        <source>%1 is disabled</source>
        <comment>this peer was blocked. Reason: TCP is disabled.</comment>
        <translation>%1 अक्षम है</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4489"/>
        <source>Torrent errored. Torrent: &quot;%1&quot;. Error: %2.</source>
        <translation>टाॅरेंट में त्रुटि। टाॅरेंट: &quot;%1&quot;। त्रुटि: %2।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4528"/>
        <location filename="../base/bittorrent/session.cpp" line="4577"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; को स्थानांतरण सूची से हटाया गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4548"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; को हार्ड डिस्क व स्थानांतरण सूची से हटाया गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4571"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; को स्थानांतरण सूची से हटाया गया किन्तु फाइलों को मिटा नहीं पाए। त्रुटि: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4619"/>
        <source>File error alert. Torrent: &quot;%1&quot;. File: &quot;%2&quot;. Reason: %3</source>
        <translation>फाइल त्रुटि चेतावनी। टाॅरेंट: &quot;%1&quot;, फाइल: &quot;%2&quot;, कारण: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4684"/>
        <source>URL seed name lookup failed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Error: &quot;%3&quot;</source>
        <translation>यूआरएल स्रोत का नाम ढूंढ़ने में असफल। टाॅरेंट: &quot;%1&quot;, यूआरएल: &quot;%2&quot;, त्रुटि: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4690"/>
        <source>Received error message from a URL seed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Message: &quot;%3&quot;</source>
        <translation>यूआरएल स्रोत से त्रुटि सन्देश प्राप्त हुआ। टाॅरेंट: &quot;%1&quot;, यूआरएल: &quot;%2&quot;, सन्देश: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4699"/>
        <source>Successfully listening on IP: %1, port: %2/%3</source>
        <comment>e.g: Successfully listening on IP: 192.168.0.1, port: TCP/6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4710"/>
        <source>Failed to listen on IP: %1, port: %2/%3. Reason: %4</source>
        <comment>e.g: Failed to listen on IP: 192.168.0.1, port: TCP/6881. Reason: already in use</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4719"/>
        <source>Detected external IP: %1</source>
        <comment>e.g. Detected external IP: 1.1.1.1</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4808"/>
        <source>Error: Internal alert queue full and alerts were dropped, you might see degraded performance. Dropped alert types: %1. Message: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4830"/>
        <source>&quot;%1&quot; is successfully moved to &quot;%2&quot;.</source>
        <translation>&quot;%1&quot; को &quot;%2&quot; पर स्थानान्तरित कर दिया है।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4852"/>
        <source>Failed to move &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;. Reason: %4.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4891"/>
        <source>SOCKS5 proxy error. Message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2013"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>&apos;%1&apos; डाउनलोड हो रहा है, प्रतीक्षा करें...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2521"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>दी गयी नेटवर्क पद्धति अमान्य है: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1091"/>
        <source>Peer ID: </source>
        <translation>सहकर्मी की आईडी:</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1092"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="536"/>
        <location filename="../base/bittorrent/session.cpp" line="1093"/>
        <source>DHT support [%1]</source>
        <translation>DHT समर्थन [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="536"/>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="1093"/>
        <location filename="../base/bittorrent/session.cpp" line="1094"/>
        <location filename="../base/bittorrent/session.cpp" line="1095"/>
        <location filename="../base/bittorrent/session.cpp" line="1096"/>
        <location filename="../base/bittorrent/session.cpp" line="1097"/>
        <location filename="../base/bittorrent/session.cpp" line="2812"/>
        <location filename="../base/bittorrent/session.cpp" line="3369"/>
        <source>ON</source>
        <translation>खोलें</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="536"/>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="1093"/>
        <location filename="../base/bittorrent/session.cpp" line="1094"/>
        <location filename="../base/bittorrent/session.cpp" line="1095"/>
        <location filename="../base/bittorrent/session.cpp" line="1096"/>
        <location filename="../base/bittorrent/session.cpp" line="1098"/>
        <location filename="../base/bittorrent/session.cpp" line="2812"/>
        <location filename="../base/bittorrent/session.cpp" line="3369"/>
        <source>OFF</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="1094"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>स्थानीय सहकर्मी खोज का समर्थन [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1095"/>
        <source>PeX support [%1]</source>
        <translation>PeX समर्थन [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1461"/>
        <source>Could not get GUID of network interface: %1</source>
        <translation>नेटवर्क पद्धति की GUID प्राप्त नहीं हो सकी: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1476"/>
        <source>Trying to listen on: %1</source>
        <comment>e.g: Trying to listen on: 192.168.0.1:6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1627"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; आपके द्वारा तय अधिकतम अनुपात तक पहुँच गया है। हटाया गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1638"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; आपके द्वारा तय अधिकतम अनुपात तक पहुँच गया है। विरमित किया गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1666"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; के लिए आपके द्वारा तय किया गया अधिकतम स्रोत काल समाप्त हो चुका है। हटाया गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1677"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; के लिए आपके द्वारा तय किया गया अधिकतम स्रोत काल समाप्त हो चुका है। विरामित किया गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3853"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>ट्रैकर &apos;%1&apos; को टाॅरेंट &apos;%2&apos; में जोड़ा गया</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3863"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>ट्रैकर &apos;%1&apos; को टाॅरेंट &apos;%2&apos; से मिटाया गया</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3878"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>यूआरएल स्रोत &apos;%1&apos; को टाॅरेंट &apos;%2&apos; में जोड़ा गया</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3884"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>यूआरएल स्रोत &apos;%1&apos; को टाॅरेंट &apos;%2&apos; से हटाया गया</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4229"/>
        <location filename="../base/bittorrent/session.cpp" line="4239"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>टौरेंट प्रारम्भ करनें में अक्षम &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4286"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>दिए गए IP फिल्टर को समझ लिया: %1 नियमों को लागू किया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4296"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>त्रुटि: दिया गया IP फिल्टर समझ से बाहर।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4453"/>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4473"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; को डाउनलोड सूची में जोड़ा गया।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4630"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4636"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="104"/>
        <source>Operation aborted</source>
        <translation>क्रिया को रोका गया</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="228"/>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="232"/>
        <source>Create new torrent file failed. Reason: %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentImpl</name>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="637"/>
        <source>Failed to add peer &quot;%1&quot; to torrent &quot;%2&quot;. Reason: %3</source>
        <translation>सहकर्मी &quot;%1&quot; को टाॅरेंट &quot;%2&quot; में जोड़ने में असफल। कारण: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="642"/>
        <source>Peer &quot;%1&quot; is added to torrent &quot;%2&quot;</source>
        <translation>सहकर्मी &quot;%1&quot; को टाॅरेंट &quot;%2&quot; में जोड़ा गया</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1012"/>
        <source>Couldn&apos;t write to file.</source>
        <translation>फाइल पर नहीं लिखा जा सका।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1013"/>
        <source>Torrent is currently in &quot;upload only&quot; mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1461"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation>पहले प्रथम व अन्तिम खण्ड को डाउनलोड करें: %1, टाॅरेंट: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1462"/>
        <source>On</source>
        <translation>खोलें</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1462"/>
        <source>Off</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1855"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;. Cannot proceed further.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1859"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1909"/>
        <source>File rename failed. Torrent: &quot;%1&quot;, file: &quot;%2&quot;, reason: &quot;%3&quot;</source>
        <translation>फाइल का नाम बदलने में असफल। टाॅरेंट: &quot;%1&quot;, फाइल: &quot;%2&quot;, कारण: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1964"/>
        <source>Performance alert: </source>
        <translation>कार्यक्षमता चेतावनी:</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Tracker</name>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="222"/>
        <source>Embedded Tracker: Now listening on IP: %1, port: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="227"/>
        <source>Embedded Tracker: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="245"/>
        <source>Categories</source>
        <translation>श्रेणियाँ</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="403"/>
        <source>All</source>
        <translation>सभी</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="410"/>
        <source>Uncategorized</source>
        <translation>अश्रेणित</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="112"/>
        <source>Add category...</source>
        <translation>श्रेणी जोड़ें…</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="120"/>
        <source>Add subcategory...</source>
        <translation>उपश्रेणी जोड़े…</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="124"/>
        <source>Edit category...</source>
        <translation>श्रेणी संशोधित करें...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="126"/>
        <source>Remove category</source>
        <translation>श्रेणी हटायें</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="130"/>
        <source>Remove unused categories</source>
        <translation>अनुपयोगी श्रेणियाँ हटायें</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>टौरेंटो को प्रारम्भ करें</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="135"/>
        <source>Pause torrents</source>
        <translation>टौरेंटो को विराम दें</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="137"/>
        <source>Delete torrents</source>
        <translation>टौरेंटो को मिटाएं</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>कुकी प्रबन्धित करें</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Domain</source>
        <translation>डोमेन</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Path</source>
        <translation>पथ</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Value</source>
        <translation>मान</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="59"/>
        <source>Expiration Date</source>
        <translation>समाप्ति तिथि</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>मिटाने की पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation>पसन्द याद रखें</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="91"/>
        <source>Also delete the files on the hard disk</source>
        <translation>फाइलें हार्ड डिस्क से भी मिटायें</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="44"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>क्या आप निश्चित ही स्थानान्तरण सूची से &apos;%1&apos; को मिटाना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="46"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>क्या आप निश्चित ही इन %1 टाॅरेंटों को स्थानान्तरण सूची से मिटाना चाहते हैं?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>URLओं से डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>टौरेंट लिंकों को जोड़ें</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="70"/>
        <source>Download</source>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="123"/>
        <source>No URL entered</source>
        <translation>कोई URL नहीं भरा गया</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="123"/>
        <source>Please type at least one URL.</source>
        <translation>कम से कम एक URL भरें।</translation>
    </message>
</context>
<context>
    <name>DownloadHandlerImpl</name>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="136"/>
        <source>I/O Error</source>
        <translation>I/O त्रुटि</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="154"/>
        <source>The file size (%1) exceeds the download limit (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="165"/>
        <source>Exceeded max redirections (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="181"/>
        <source>Redirected to magnet URI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="214"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="216"/>
        <source>The operation was canceled</source>
        <translation>क्रिया को रद्द कर दिया गया था</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="218"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="220"/>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="222"/>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="224"/>
        <source>The remote server refused the connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="226"/>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="228"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="230"/>
        <source>The proxy host name was not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="232"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="234"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="236"/>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="238"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="240"/>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="242"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="244"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="246"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>अनुरोध की गई कार्यवाही इस प्रोटोकॉल के लिए अमान्य है</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="248"/>
        <source>An unknown network-related error was detected</source>
        <translation>एक अनजान नेटवर्क से संबंधित त्रुटि का पता चला था</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="250"/>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="252"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="254"/>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="256"/>
        <source>Unknown error</source>
        <translation>अज्ञात त्रुटि</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="192"/>
        <source>Missing pieces</source>
        <translation>अनुपस्थित खण्ड</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="193"/>
        <source>Partial pieces</source>
        <translation>अधूरे खण्ड</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="194"/>
        <source>Completed pieces</source>
        <translation>पूर्ण खण्ड</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="36"/>
        <source>General</source>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="42"/>
        <source>Blocked IPs</source>
        <translation>प्रतिबंधित आईपी</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="94"/>
        <source>Copy</source>
        <translation>प्रतिलिपि बनाए</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="98"/>
        <source>Clear</source>
        <translation>साफ करें</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="50"/>
        <source>RSS feeds</source>
        <translation>RSS स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="62"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="113"/>
        <source>Unread  (%1)</source>
        <translation>अपठित (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="184"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="59"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="61"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;ब्राउज करें...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="63"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>फाइल चुनें</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="65"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>फोल्डर चुनें</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="104"/>
        <source>Any file</source>
        <translation>कोई भी फाइल</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="132"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="296"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="477"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="227"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="372"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="382"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>IP फिल्टर की लाइन %1 विकृत है।</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="237"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="392"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="247"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="402"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="256"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="411"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="272"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="426"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="282"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="436"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="489"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="504"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="528"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="539"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="550"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="562"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="584"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>समझने में त्रुटि: फिल्टर फाइल मान्य PeerGuardian P2B फाइल नहीं है।</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="93"/>
        <location filename="../base/net/geoipdatabase.cpp" line="127"/>
        <source>Unsupported database file size.</source>
        <translation>डाटाबेस फाइल का आकर असंगत है।</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="236"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>मेटाडाटा त्रुटि: प्रविष्टि &apos;%1&apos; नहीं मिली।</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="237"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>मेटाडाटा त्रुटि: प्रविष्टि &apos;%1&apos; का प्रकार गलत है।</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="247"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>असंगत डाटाबेस संस्करण: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="255"/>
        <source>Unsupported IP version: %1</source>
        <translation>असंगत आईपी संस्करण: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="263"/>
        <source>Unsupported record size: %1</source>
        <translation>असंगत अभिलेख आकार: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="294"/>
        <source>Database corrupted: no data section found.</source>
        <translation>खराब डाटाबेस: डाटा भाग नहीं मिला।</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="73"/>
        <source>Http request size exceeds limitation, closing socket. Limit: %1, IP: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="87"/>
        <source>Bad Http request, closing socket. IP: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>सज्जनसूची में आने वाले आईपी सबनेट</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>उदहारण: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>सबनेट जोड़े</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>मिटाएं</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="96"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="96"/>
        <source>The entered subnet is invalid.</source>
        <translation>भरा गया सबनेट अमान्य है।</translation>
    </message>
</context>
<context>
    <name>LogPeerModel</name>
    <message>
        <location filename="../gui/log/logmodel.cpp" line="178"/>
        <source>%1 was blocked. Reason: %2.</source>
        <comment>0.0.0.0 was blocked. Reason: reason for blocking.</comment>
        <translation>%1 को अवरुद्धित किया। कारण: %2</translation>
    </message>
    <message>
        <location filename="../gui/log/logmodel.cpp" line="179"/>
        <source>%1 was banned</source>
        <comment>0.0.0.0 was banned</comment>
        <translation>%1 को प्रतिबन्धित किया</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>संपादन (&amp;E)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>साधन (&amp;T)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>फाइल (&amp;F)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>सहायता (&amp;H)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>डाउनलोडों के पूरा होने पर (&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>देंखे (&amp;V)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>विकल्प… (&amp;O)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>प्रारम्भ (&amp;R)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>टाॅरेंट निर्माणक (&amp;C)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="285"/>
        <location filename="../gui/mainwindow.ui" line="288"/>
        <source>Alternative Speed Limits</source>
        <translation>वैकल्पिक गति सीमायें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="296"/>
        <source>&amp;Top Toolbar</source>
        <translation>शीर्ष &amp;उपकरण पट्टी</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="299"/>
        <source>Display Top Toolbar</source>
        <translation>शीर्ष उपकरण पट्टी दिखाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="307"/>
        <source>Status &amp;Bar</source>
        <translation>स्थिति &amp;पट्टी</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="315"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>शीर्षक&amp; पट्टी में गति</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="318"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>शीर्षक पट्टी में गति दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="326"/>
        <source>&amp;RSS Reader</source>
        <translation>&amp;RSS पाठक</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="334"/>
        <source>Search &amp;Engine</source>
        <translation>खोज &amp;इन्जन</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="339"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>क्यूबिटटोरेंट &amp;लॉक करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="350"/>
        <source>Do&amp;nate!</source>
        <translation>दा&amp;न करें!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="469"/>
        <source>Close Window</source>
        <translation>विंडो बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>सभी आरंभ (&amp;e)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="421"/>
        <source>Manage Cookies...</source>
        <translation>कुकी प्रबन्धित करें...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="424"/>
        <source>Manage stored network cookies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="440"/>
        <source>Normal Messages</source>
        <translation>सामान्य सन्देश</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="448"/>
        <source>Information Messages</source>
        <translation>सूचना सन्देश</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="456"/>
        <source>Warning Messages</source>
        <translation>चेतावनी सन्देश</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="464"/>
        <source>Critical Messages</source>
        <translation>जोखिम सन्देश</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>लॉ&amp;ग</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Global Speed Limits...</source>
        <translation> सार्वभौम गति सीमाएं निर्धारित करें...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>Bottom of Queue</source>
        <translation>पंक्ति में अन्तिम</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="241"/>
        <source>Move to the bottom of the queue</source>
        <translation>पंक्ति में अन्तिम पर ले जाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="249"/>
        <source>Top of Queue</source>
        <translation>पंक्ति में प्रथम</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="252"/>
        <source>Move to the top of the queue</source>
        <translation>पंक्ति में प्रथम पर ले जाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="260"/>
        <source>Move Down Queue</source>
        <translation>पंक्ति में पीछे ले जाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="263"/>
        <source>Move down in the queue</source>
        <translation>पंक्ति में पीछे ले जाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="271"/>
        <source>Move Up Queue</source>
        <translation>पंक्ति में आगे ले जाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="274"/>
        <source>Move up in the queue</source>
        <translation>पंक्ति में आगे ले जाएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="361"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>क्यूबिटटोरेंट &amp;बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="369"/>
        <source>&amp;Suspend System</source>
        <translation>सिस्टम को निलंबित करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="377"/>
        <source>&amp;Hibernate System</source>
        <translation>सिस्टम को &amp;अतिसुप्त करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="385"/>
        <source>S&amp;hutdown System</source>
        <translation>सिस्टम बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="393"/>
        <source>&amp;Disabled</source>
        <translation>&amp;अक्षम</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="408"/>
        <source>&amp;Statistics</source>
        <translation>आं&amp;कड़े</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="413"/>
        <source>Check for Updates</source>
        <translation>अद्यतन के लिए जाँचे</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="416"/>
        <source>Check for Program Updates</source>
        <translation>प्रोग्राम अद्यतन के लिए जाँच करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>बारे में (&amp;A)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>रोकें (&amp;P)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>हटाएँ (&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>सभी रोकें (&amp;P)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>टौरेंट फाइ&amp;ल जोड़ें...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>खोलें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>बा&amp;हर निकलें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>यूआरएल खोलें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>&amp;Documentation</source>
        <translation>शास्त्र (&amp;D)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>Lock</source>
        <translation>लॉक</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="398"/>
        <location filename="../gui/mainwindow.ui" line="432"/>
        <location filename="../gui/mainwindow.cpp" line="1761"/>
        <source>Show</source>
        <translation>दिखाएँ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1933"/>
        <source>Check for program updates</source>
        <translation>कार्यक्रम अद्यतन के लिए जाँच करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>टौरेंट लिं&amp;क जोड़ें...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="353"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>यदि क्यूबिटटाॅरेंट आपके कार्यों हेतु उपयोगी हो तो कृपया दान करें!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2011"/>
        <location filename="../gui/mainwindow.cpp" line="2013"/>
        <source>Execution Log</source>
        <translation>निष्पादन वृतांत</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="663"/>
        <source>Clear the password</source>
        <translation>पासवर्ड रद्द करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="196"/>
        <source>&amp;Set Password</source>
        <translation>पासवर्ड ल&amp;गायें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="167"/>
        <source>Preferences</source>
        <translation>वरीयताएं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="197"/>
        <source>&amp;Clear Password</source>
        <translation>पासवर्ड ह&amp;टायें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="222"/>
        <source>Filter torrent names...</source>
        <translation>टाॅरेंट नाम फिल्टर करें...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="248"/>
        <source>Transfers</source>
        <translation>अंतरण</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="419"/>
        <location filename="../gui/mainwindow.cpp" line="1307"/>
        <source>qBittorrent is minimized to tray</source>
        <translation>क्यूबिटटोरेंट ट्रे आइकन रूप में संक्षिप्त</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="419"/>
        <location filename="../gui/mainwindow.cpp" line="1207"/>
        <location filename="../gui/mainwindow.cpp" line="1307"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <source>Torrent file association</source>
        <translation>टोरेंट फाइल हेतु प्रोग्राम</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="464"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>टाॅरेंट या मैग्नेट फाइलें खोलने हेतु क्यूबिटटाॅरेंट डिफ़ॉल्ट अनुप्रयोग नहीं है।
क्या आप क्यूबिटटाॅरेंट को टाॅरेंट व मैग्नेट फाइलों हेतु डिफ़ॉल्ट सेट करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="561"/>
        <source>Icons Only</source>
        <translation>केवल चित्र</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="562"/>
        <source>Text Only</source>
        <translation>केवल लेख</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="563"/>
        <source>Text Alongside Icons</source>
        <translation>चित्र के बगल लेख</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="564"/>
        <source>Text Under Icons</source>
        <translation>चित्र के नीचे लेख</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="565"/>
        <source>Follow System Style</source>
        <translation>सिस्टम की शैली का पालन करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="646"/>
        <location filename="../gui/mainwindow.cpp" line="1051"/>
        <source>UI lock password</source>
        <translation>उपयोक्ता अंतरफलक लॉक हेतु कूटशब्द</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <location filename="../gui/mainwindow.cpp" line="1052"/>
        <source>Please type the UI lock password:</source>
        <translation>उपयोक्ता अंतरफलक लॉक हेतु कूटशब्द दर्ज करें :</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <source>The password should contain at least 3 characters</source>
        <translation>कूटशब्द में न्यूनतम 3 अक्षर होना आवश्यक है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="664"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>क्या आप निश्चित है कि आप पासवर्ड रद्द करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="723"/>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="745"/>
        <source>Search</source>
        <translation>खोजें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="762"/>
        <source>Transfers (%1)</source>
        <translation>अंतरण (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="861"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="861"/>
        <source>Failed to add torrent: %1</source>
        <translation>टौरेंट: %1 को जोड़ने में विफल</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="868"/>
        <source>Torrent added</source>
        <translation>टौरेंट जोड़ा गया</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="868"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; को जोड़ा गया।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="874"/>
        <source>Download completion</source>
        <translation>डाउनलोड पूर्ण</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="880"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>इनपुट/आउटपुट त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="975"/>
        <source>Recursive download confirmation</source>
        <translation>पुनरावर्ती डाउनलोड हेतु पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="981"/>
        <source>Yes</source>
        <translation>हाँ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="982"/>
        <source>No</source>
        <translation>नहीँ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="983"/>
        <source>Never</source>
        <translation>कभी नहीँ</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1074"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>क्यूबिटटोरेंट अपडेट किया गया व परिवर्तन लागू करने हेतु इसे पुनः आरंभ आवश्यक है।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1207"/>
        <source>qBittorrent is closed to tray</source>
        <translation>क्यूबिटटोरेंट ट्रे आइकन रूप में संक्षिप्त</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1222"/>
        <source>Some files are currently transferring.</source>
        <translation>अभी कुछ फाइलों का स्थानान्तरण हो रहा है।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1222"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>क्या आप निश्चित ही क्यूबिटटोरेंट बंद करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1224"/>
        <source>&amp;No</source>
        <translation>&amp;नहीं</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1225"/>
        <source>&amp;Yes</source>
        <translation>&amp;हां</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1226"/>
        <source>&amp;Always Yes</source>
        <translation>हमे&amp;शा हां</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1635"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/से</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1870"/>
        <location filename="../gui/mainwindow.cpp" line="1876"/>
        <source>Missing Python Runtime</source>
        <translation>पायथन रनटाइम अनुपस्थित है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1897"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 3.3.0.</source>
        <translation>आपका पायथन संस्करण (%1) पुराना है। खोज इन्जन के लिए सबसे नए संस्करण पर उन्नत करें।
न्यूनतम आवश्यक: 3.3.0।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1948"/>
        <source>qBittorrent Update Available</source>
        <translation>क्यूबिटटोरेंट अपडेट उपलब्ध है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="874"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; डाउनलोड हो चुका है।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="881"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>टाँरेंट %1 के लिए एक I/O त्रुटि हुई।
कारण: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="976"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>टाॅरेंट %1 में टाॅरेंट फाइलें है क्या आप उन्हें भी डाउनलोड करना चाहेंगे?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="998"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>URL &apos;%1&apos; पर उपलब्ध फाइल डाउनलोड नहीं हो पायी, कारण: %2।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1871"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>खोज इन्जन का उपगोय करने के लिए पायथन आवश्यक है लेकिन ये स्थापित नहीं है। क्या आप इसे अभी स्थापित करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1877"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>खोज इन्जन का उपगोय करने के लिए पायथन आवश्यक है लेकिन ये स्थापित नहीं है।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1889"/>
        <location filename="../gui/mainwindow.cpp" line="1896"/>
        <source>Old Python Runtime</source>
        <translation>पायथन रनटाइम पुराना है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1890"/>
        <source>Your Python version (%1) is outdated. Minimum requirement: 3.5.0.
Do you want to install a newer version now?</source>
        <translation>आपका पायथन संस्करण (%1) पुराना है। न्यूनतम आवश्यक: 3.5.0।
क्या आप नया संस्करण अभी स्थापित करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1945"/>
        <source>A new version is available.</source>
        <translation>नया वर्जन उपलब्ध है|</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1946"/>
        <source>Do you want to download %1?</source>
        <translation>क्या आप %1 को डाउनलोड करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1947"/>
        <source>Open changelog...</source>
        <translation>परिवर्तनलॉग खोलें...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1968"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>अद्यतन उपलब्ध नहीं है।
आप पहले से ही नवीनतम संस्करण प्रयोग कर रहे हैं।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1932"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;अद्यतन के लिए जाँचे</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2143"/>
        <source>Checking for Updates...</source>
        <translation>अद्यतन के लिए जाँचा चल रही है...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2144"/>
        <source>Already checking for program updates in the background</source>
        <translation>कार्यक्रम अद्यतन की जाँच पहले से ही पृष्टभूमि में चल रही है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2177"/>
        <source>Download error</source>
        <translation>डाउनलोड त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2178"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>पायथन का सेटअप डाउनलोड नहीं हो सका, कारण: %1।
इसे आप स्वयं स्थापित करें।</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <location filename="../gui/mainwindow.cpp" line="1060"/>
        <source>Invalid password</source>
        <translation>अमान्य कूटशब्द</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="689"/>
        <location filename="../gui/mainwindow.cpp" line="702"/>
        <location filename="../gui/mainwindow.cpp" line="704"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="997"/>
        <source>URL download error</source>
        <translation>युआरएल डाउनलोड में त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1060"/>
        <source>The password is invalid</source>
        <translation>यह कूटशब्द अमान्य है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1646"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>↓ गति: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1647"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>↑ गति: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1654"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation> [↓: %1, ↑: %2]  क्यूबिटटाॅरेंट %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1761"/>
        <source>Hide</source>
        <translation>अदृश्य करें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1220"/>
        <source>Exiting qBittorrent</source>
        <translation>क्यूबिटटाॅरेंट बंद हो रहा है</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1438"/>
        <source>Open Torrent Files</source>
        <translation>टाॅरेंट फाइल खोलें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1439"/>
        <source>Torrent Files</source>
        <translation>टाॅरेंट फाइलें</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1494"/>
        <source>Options were saved successfully.</source>
        <translation>विकल्प सफलतापूर्वक संचित।</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="185"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>आपका गतिशील DNS अद्यतित कर दिया गया है।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="191"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>गतिशील DNS त्रुटि: यह सेवा अस्थाई रूप से बाधित है, इसे 30 मिनटों में सेवामुक्त कर दिया जायेगा।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="202"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>गतिशील DNS त्रुटि: जो होस्टनेम आपने दिया था वह बताए गए खाते में नहीं है।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>गतिशील DNS त्रुटि: अमान्य यूजरनेम/पासवर्ड।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="216"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>गतिशील डीएनएस त्रुटि : सेवा द्वारा क्यूबिटटोरेंट दुर्जनसूची में दर्ज, यह समस्या http://bugs.qbittorrent.org पर सूचित करें।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="224"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>गतिशील डीएनएस त्रुटि : सेवा द्वारा %1 प्राप्त, यह समस्या http://bugs.qbittorrent.org पर सूचित करें।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="232"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>गतिशील DNS त्रुटि: आपके यूजरनेम पर दुर्व्यवहार करने के कारण रोक लगा दी गयी है।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="255"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>गतिशील DNS त्रुटि: आपके द्वारा दिया गया डोमेन अमान्य है।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="268"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>गतिशील DNS त्रुटि: आपके द्वारा दिया गया यूजरनेम बहुत छोटा है।</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="281"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>गतिशील DNS त्रुटि: आपके द्वारा दिया गया पासवर्ड बहुत छोटा है।</translation>
    </message>
</context>
<context>
    <name>Net::DownloadManager</name>
    <message>
        <location filename="../base/net/downloadmanager.cpp" line="296"/>
        <source>Ignoring SSL error, URL: &quot;%1&quot;, errors: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>वेनेजुएला के बोलीवियाई गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="399"/>
        <location filename="../base/net/geoipmanager.cpp" line="402"/>
        <source>N/A</source>
        <translation>लागू नहीं</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Andorra</source>
        <translation>अन्डोर्रा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="97"/>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>IP geolocation database loaded. Type: %1. Build time: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="101"/>
        <location filename="../base/net/geoipmanager.cpp" line="467"/>
        <source>Couldn&apos;t load IP geolocation database. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>United Arab Emirates</source>
        <translation>यूनाइटेड अरब अमीरात</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Afghanistan</source>
        <translation>अफगानिस्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antigua and Barbuda</source>
        <translation>एंटीगुआ और बरबुडा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Anguilla</source>
        <translation>एंगुइला</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Albania</source>
        <translation>अल्बानिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Armenia</source>
        <translation>आर्मेनिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Angola</source>
        <translation>अंगोला</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Antarctica</source>
        <translation>अंटार्कटिका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Argentina</source>
        <translation>अर्जेंटीना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>American Samoa</source>
        <translation>अमेरिकी समोआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Austria</source>
        <translation>ऑस्ट्रिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Australia</source>
        <translation>ऑस्ट्रेलिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Aruba</source>
        <translation>अरूबा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Azerbaijan</source>
        <translation>अजरबैजान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bosnia and Herzegovina</source>
        <translation>बोस्निआ और हर्जेगोविना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Barbados</source>
        <translation>बारबेडोस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Bangladesh</source>
        <translation>बांग्लादेश</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Belgium</source>
        <translation>बेल्जियम</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Burkina Faso</source>
        <translation>बुर्किना फासो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bulgaria</source>
        <translation>बुल्गारिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bahrain</source>
        <translation>बहरीन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Burundi</source>
        <translation>बुरुंदी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Benin</source>
        <translation>बेनिन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bermuda</source>
        <translation>बरमूडा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Brunei Darussalam</source>
        <translation>ब्रूनेई दारूसलम</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Brazil</source>
        <translation>ब्राजील</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Bahamas</source>
        <translation>बहामस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Bhutan</source>
        <translation>भूटान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Bouvet Island</source>
        <translation>बोवेत द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Botswana</source>
        <translation>बोत्सवाना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Belarus</source>
        <translation>बेलारस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Belize</source>
        <translation>बिलीज</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Canada</source>
        <translation>कनाडा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>कोको (कीलिंग) द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>कांगो लोकतान्त्रिक गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Central African Republic</source>
        <translation>मध्य अफ्रीकी गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Congo</source>
        <translation>कांगो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Switzerland</source>
        <translation>स्विटजरलैंड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Cook Islands</source>
        <translation>कुक द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Chile</source>
        <translation>चिली</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cameroon</source>
        <translation>कैमरून</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>China</source>
        <translation>चीन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Colombia</source>
        <translation>कोलम्बिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Costa Rica</source>
        <translation>कोस्टा रिका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Cuba</source>
        <translation>क्यूबा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Cape Verde</source>
        <translation>केप वर्ड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Curacao</source>
        <translation>कुरासावो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Christmas Island</source>
        <translation>क्रिसमस द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Cyprus</source>
        <translation>सायप्रस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Czech Republic</source>
        <translation>चेक रिपब्लिक</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Germany</source>
        <translation>जर्मनी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Djibouti</source>
        <translation>जिबूती</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Denmark</source>
        <translation>डेनमार्क</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Dominica</source>
        <translation>डॉमिनिका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Dominican Republic</source>
        <translation>डॉमिनिकन रिपब्लिक</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Algeria</source>
        <translation>अल्जीरिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Ecuador</source>
        <translation>इक्वाडोर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Estonia</source>
        <translation>एस्टोनिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Egypt</source>
        <translation>मिस्त्र</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Western Sahara</source>
        <translation>पश्चिमी सहारा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Eritrea</source>
        <translation>इरित्रिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Spain</source>
        <translation>स्पेन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Ethiopia</source>
        <translation>ईथोपिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>Finland</source>
        <translation>फिनलैंड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Fiji</source>
        <translation>फिजी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>फ़ाकलैंड द्वीपसमूह (माल्विनस)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Micronesia, Federated States of</source>
        <translation>माइक्रोनीशिया राज्य संघ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Faroe Islands</source>
        <translation>फ़रो द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>France</source>
        <translation>फ्रांस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Gabon</source>
        <translation>गेबॉन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>United Kingdom</source>
        <translation>यूनाइटेड किंगडम</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Grenada</source>
        <translation>ग्रेनाडा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Georgia</source>
        <translation>जॉर्जिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>French Guiana</source>
        <translation>फ्रेंच गुयाना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Ghana</source>
        <translation>घाना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Gibraltar</source>
        <translation>जिब्राल्टर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greenland</source>
        <translation>ग्रीनलैण्ड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Gambia</source>
        <translation>गाम्बिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guinea</source>
        <translation>गिनी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guadeloupe</source>
        <translation>गुआदेलूप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Equatorial Guinea</source>
        <translation>भूमध्यरेखीय गिनी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Greece</source>
        <translation>ग्रीस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>दक्षिण जॉर्जिया एवं दक्षिण सैंडविच द्वीप समूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Guatemala</source>
        <translation>ग्वाटेमाला</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Guam</source>
        <translation>गुआम </translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Guinea-Bissau</source>
        <translation>गिनी-बिसाऊ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Guyana</source>
        <translation>गुयाना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hong Kong</source>
        <translation>हॉङ्ग कॉङ्ग</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>हर्ड द्वीप और मैकडोनाल्ड द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Honduras</source>
        <translation>हौण्डुरस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Croatia</source>
        <translation>क्रोएशिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Haiti</source>
        <translation>हैती</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>Hungary</source>
        <translation>हंगरी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Indonesia</source>
        <translation>इंडोनेशिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Ireland</source>
        <translation>आयरलैंड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Israel</source>
        <translation>इजराइल</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>India</source>
        <translation>भारत</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>British Indian Ocean Territory</source>
        <translation>ब्रिटिश हिंद महासागर क्षेत्र</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Iraq</source>
        <translation>इराक</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Iran, Islamic Republic of</source>
        <translation>ईरानी इस्लामिक गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Iceland</source>
        <translation>आइसलैंड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Italy</source>
        <translation>इटली</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Jamaica</source>
        <translation>जमैका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Jordan</source>
        <translation>जॉर्डन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Japan</source>
        <translation>जापान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Kenya</source>
        <translation>कीनिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Kyrgyzstan</source>
        <translation>किर्गिज़स्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Cambodia</source>
        <translation>कम्बोडिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kiribati</source>
        <translation>किरिबाती</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Comoros</source>
        <translation>कोमोरोस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Saint Kitts and Nevis</source>
        <translation>सन्त किट्स और नेविस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>कोरिया जनवादी लोकतांत्रिक गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Korea, Republic of</source>
        <translation>कोरिया गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Kuwait</source>
        <translation>कुवैत</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Cayman Islands</source>
        <translation>केमन द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Kazakhstan</source>
        <translation>कजाखस्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>लाओ जनवादी लोकतान्त्रिक गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lebanon</source>
        <translation>लेबनान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Saint Lucia</source>
        <translation>सन्त लूसिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Liechtenstein</source>
        <translation>लिख्टेंश्टाइन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Sri Lanka</source>
        <translation>श्री लंका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Liberia</source>
        <translation>लाईबेरिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Lesotho</source>
        <translation>लेसोथो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Lithuania</source>
        <translation>लिथुआनिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Luxembourg</source>
        <translation>लग्जमबर्ग</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Latvia</source>
        <translation>लातविया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Morocco</source>
        <translation>मोरक्को</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Monaco</source>
        <translation>मोनाको</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Moldova, Republic of</source>
        <translation>माल्दोवा गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Madagascar</source>
        <translation>मैडागास्कर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Marshall Islands</source>
        <translation>मार्शल द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Mali</source>
        <translation>माली</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Myanmar</source>
        <translation>म्यान्मार</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Mongolia</source>
        <translation>मंगोलिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Northern Mariana Islands</source>
        <translation>उत्तरी मैरियाना द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Martinique</source>
        <translation>मार्टीनिक</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Mauritania</source>
        <translation>मॉरीतानिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Montserrat</source>
        <translation>मॉण्टसेराट</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malta</source>
        <translation>माल्टा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mauritius</source>
        <translation>मॉरीशस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Maldives</source>
        <translation>मालदीव</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Malawi</source>
        <translation>मलावी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Mexico</source>
        <translation>मेक्सिको</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Malaysia</source>
        <translation>मलेशिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Mozambique</source>
        <translation>मोजाम्बीक</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Namibia</source>
        <translation>नामीबिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>New Caledonia</source>
        <translation>न्यू कालेडोनिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Niger</source>
        <translation>नाइजर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Norfolk Island</source>
        <translation>नॉरफ़ॉक द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nigeria</source>
        <translation>नाइजीरिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Nicaragua</source>
        <translation>निकारागुआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Netherlands</source>
        <translation>नीदरलैण्डस्</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Norway</source>
        <translation>नॉर्वे</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Nepal</source>
        <translation>नेपाल</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Nauru</source>
        <translation>नाउरु</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Niue</source>
        <translation>नियू</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>New Zealand</source>
        <translation>न्यूजीलैंड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Oman</source>
        <translation>ओमान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Panama</source>
        <translation>पनामा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Peru</source>
        <translation>पेरू</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>French Polynesia</source>
        <translation>फ्रेंच पॉलिनेसिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Papua New Guinea</source>
        <translation>पापुआ न्यू गिनी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Philippines</source>
        <translation>फिलीपींस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Pakistan</source>
        <translation>पाकिस्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Poland</source>
        <translation>पोलैण्ड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>सन्त पियर और मिकलान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Puerto Rico</source>
        <translation>पोर्टो रीको</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Portugal</source>
        <translation>पुर्तगाल</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Palau</source>
        <translation>पलाउ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Paraguay</source>
        <translation>पराग्वे</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Qatar</source>
        <translation>कतर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Reunion</source>
        <translation>रेयूनियों</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Romania</source>
        <translation>रोमानिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Russian Federation</source>
        <translation>रूस</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Rwanda</source>
        <translation>रवाण्डा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Saudi Arabia</source>
        <translation>सउदी अरब</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Solomon Islands</source>
        <translation>सोलोमन द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Seychelles</source>
        <translation>सेशेल्स</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Sudan</source>
        <translation>सूडान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Sweden</source>
        <translation>स्वीडन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Singapore</source>
        <translation>सिंगापुर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Slovenia</source>
        <translation>स्लोवेनिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>स्वालबार्ड और यान मायेन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Slovakia</source>
        <translation>स्लोवाकिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Sierra Leone</source>
        <translation>सियरा लियोन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>San Marino</source>
        <translation>सान मारिनो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Senegal</source>
        <translation>सेनेगल</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Somalia</source>
        <translation>सोमालिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Suriname</source>
        <translation>सूरीनाम</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Sao Tome and Principe</source>
        <translation>साओ तोमे और प्रिन्सिपी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>El Salvador</source>
        <translation>अल साल्वाडोर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Syrian Arab Republic</source>
        <translation>सीरियाई अरब गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Swaziland</source>
        <translation>स्वाज़ीलैण्ड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Turks and Caicos Islands</source>
        <translation>तुर्क और केकोस द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Chad</source>
        <translation>चाड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>French Southern Territories</source>
        <translation>दक्षिणी फ्रांस प्रदेश</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Togo</source>
        <translation>टोगो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Thailand</source>
        <translation>थाईलैण्ड</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tajikistan</source>
        <translation>ताजिकिस्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Tokelau</source>
        <translation>तोकेलाऊ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Turkmenistan</source>
        <translation>तुर्कमेनिस्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Tunisia</source>
        <translation>तूनिसीया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tonga</source>
        <translation>टोंगो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Vietnam</source>
        <translation>वियतनाम</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="427"/>
        <source>Couldn&apos;t download IP geolocation database file. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="435"/>
        <source>Could not decompress IP geolocation database file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="456"/>
        <source>Couldn&apos;t save downloaded IP geolocation database file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="458"/>
        <source>Successfully updated IP geolocation database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Timor-Leste</source>
        <translation>पूर्वी तिमोर</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>बोलीविया बहुराष्ट्रीय देश</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>बोनायर, सिंट युस्टेशियस व साबा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>आइवरी कोस्ट</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Libya</source>
        <translation>लीबिया</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Saint Martin (French part)</source>
        <translation>संत मार्टिन (फ्रांसीसी भाग)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>पूर्व यूगोस्लाव गणराज्य मेसोडोनिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Macao</source>
        <translation>मकाऊ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Pitcairn</source>
        <translation>पिटकेर्न</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Palestine, State of</source>
        <translation>फलिस्तीन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>सन्त हेलेना, असेन्शन व त्रिस्तान दा कून्हा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>South Sudan</source>
        <translation>दक्षिणी सूडान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>सिण्ट मार्टेन (डच भाग)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Turkey</source>
        <translation>तुर्की</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Trinidad and Tobago</source>
        <translation>त्रिनिनाद व टोबेगो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>Tuvalu</source>
        <translation>तुवालू</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Taiwan</source>
        <translation>ताइवान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Tanzania, United Republic of</source>
        <translation>तन्जानिया गणराज्य</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Ukraine</source>
        <translation>यूक्रेन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Uganda</source>
        <translation>युगांडा</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>United States Minor Outlying Islands</source>
        <translation>संयुक्त राज्य अमेरिका छोटे बाहरी द्वीप</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>United States</source>
        <translation>संयुक्त राज्य अमेरिका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Uruguay</source>
        <translation>उरुग्वे</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Uzbekistan</source>
        <translation>उज्बेकिस्तान</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Holy See (Vatican City State)</source>
        <translation>होली सी (वेटिकन सिटी राज्य)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>सेंट विंसेंट एंड ग्रेनाडाइन्स</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Virgin Islands, British</source>
        <translation>ब्रिटिश वर्जिन द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Virgin Islands, U.S.</source>
        <translation>संयुक्त राज्य अमेरिका वर्जिन द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Vanuatu</source>
        <translation>वानूआतू</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Wallis and Futuna</source>
        <translation>वालिस और फुटूना</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Samoa</source>
        <translation>समोआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="393"/>
        <source>Yemen</source>
        <translation>यमन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <source>Mayotte</source>
        <translation>मायोत</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Serbia</source>
        <translation>सर्बिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="395"/>
        <source>South Africa</source>
        <translation>दक्षिण अफ्रीका</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="396"/>
        <source>Zambia</source>
        <translation>जाम्बिआ</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Montenegro</source>
        <translation>मॉन्टेनीग्रो</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="397"/>
        <source>Zimbabwe</source>
        <translation>जिब्बावे</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Aland Islands</source>
        <translation>ऑलैण्ड द्वीपसमूह</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guernsey</source>
        <translation>ग्वेर्नसे</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Isle of Man</source>
        <translation>आइल ऑफ़ मैन</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Jersey</source>
        <translation>जर्सी</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Saint Barthelemy</source>
        <translation>सेंट बार्थेलेमी</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="561"/>
        <source>Email Notification Error:</source>
        <translation>ईमेल अधिसूचना त्रुटि</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>विकल्प</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>व्यवहार</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>कनेक्शन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>गति</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>बिटटोरेंट</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>वेब UI</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>उन्नत</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="219"/>
        <source>Transfer List</source>
        <translation>स्थानांतरण सूची</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="228"/>
        <source>Confirm when deleting torrents</source>
        <translation>टाॅरेंट मिटाते समय पुष्टि करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="238"/>
        <source>Use alternating row colors</source>
        <extracomment>In table elements, every other row will have a grey background.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="250"/>
        <source>Hide zero and infinity values</source>
        <translation>शुन्य व अनन्त को छुपायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="258"/>
        <source>Always</source>
        <translation>हमेशा</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="263"/>
        <source>Paused torrents only</source>
        <translation>केवल विरामित टौरेंट</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="286"/>
        <source>Action on double-click</source>
        <translation>डबल-क्लिक पर क्रिया</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="292"/>
        <source>Downloading torrents:</source>
        <translation>डाउनलोड हो रहे टाॅरेंट:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="303"/>
        <location filename="../gui/optionsdialog.ui" line="329"/>
        <source>Start / Stop Torrent</source>
        <translation>टाॅरेंट चालू / बन्द करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="308"/>
        <location filename="../gui/optionsdialog.ui" line="334"/>
        <source>Open destination folder</source>
        <translation>गन्तव्य फोल्डर खोलें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="313"/>
        <location filename="../gui/optionsdialog.ui" line="344"/>
        <source>No action</source>
        <translation>कोई कार्यवाही नहीं</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="321"/>
        <source>Completed torrents:</source>
        <translation>पूर्ण हो चुके टाॅरेंट:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="371"/>
        <source>Desktop</source>
        <translation>डेस्कट‍ॉप</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="377"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>विंडोज के साथ क्यूबिटटोरेंट ही आरंभ करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="384"/>
        <source>Show splash screen on start up</source>
        <translation>शुरू करते समय आरंभ स्क्रीन दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="397"/>
        <source>Start qBittorrent minimized</source>
        <translation>क्यूबिटटोरेंट संक्षिप्त रूप में आरंभ करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="407"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>टाॅरेंटों के सक्रिय होने पर बाहर निकलने की पुष्टि करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="417"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>डाउनलोडों के समाप्त होने पर स्वतः बाहर निकलने की पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="605"/>
        <source> KiB</source>
        <translation>केबी</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="776"/>
        <source>Torrent content layout:</source>
        <translation>टाॅरेंट सामग्री का अभिविन्यास:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="787"/>
        <source>Original</source>
        <translation>मूल</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="792"/>
        <source>Create subfolder</source>
        <translation>उपफोल्डर बनायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="797"/>
        <source>Don&apos;t create subfolder</source>
        <translation>उपफोल्डर न बनायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1188"/>
        <source>Add...</source>
        <translation>जोड़ें...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1198"/>
        <source>Options..</source>
        <translation>विकल्प...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1208"/>
        <source>Remove</source>
        <translation>हटायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1235"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>डाउनलोड पूरा होने पर &amp;ईमेल अधिसूचना</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1336"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>टाॅरेंटों के पूर्ण होने प&amp;र बाहरी प्रोग्राम चलायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1405"/>
        <source>Peer connection protocol:</source>
        <translation>सहकर्मी कनेक्शन की पद्धति:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1461"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1789"/>
        <source>IP Fi&amp;ltering</source>
        <translation>IP फिल्ट&amp;र करना</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1989"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2004"/>
        <source>From:</source>
        <comment>From start time</comment>
        <translation>से:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2031"/>
        <source>To:</source>
        <comment>To end time</comment>
        <translation>को:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2236"/>
        <source>Find peers on the DHT network</source>
        <translation>DHT नेटवर्क पर सहकर्मी ढूँढे</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2284"/>
        <source>Allow encryption: Connect to peers regardless of setting
Require encryption: Only connect to peers with protocol encryption
Disable encryption: Only connect to peers without protocol encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2290"/>
        <source>Allow encryption</source>
        <translation>गोपनीयता का प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2335"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;अधिक जानकारी&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2363"/>
        <source>&amp;Torrent Queueing</source>
        <translation>टौरें&amp;ट पंक्तिबद्धीकरण</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2656"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>इन ट्रैकरों को नए डा&amp;उनलोडों में स्वतः जोड़ दें:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2722"/>
        <source>RSS Reader</source>
        <translation>RSS पाठक</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2728"/>
        <source>Enable fetching RSS feeds</source>
        <translation>RSS स्रोतों को लाना सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2737"/>
        <source>Feeds refresh interval:</source>
        <translation>स्रोतों को ताजा करने का अन्तराल:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2754"/>
        <source>Maximum number of articles per feed:</source>
        <translation>प्रति स्रोत अधिकतम लेखों की संख्या:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2560"/>
        <location filename="../gui/optionsdialog.ui" line="2761"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation>न्यूनतम</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2551"/>
        <source>Seeding Limits</source>
        <translation>स्रोत की सीमाएं</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2573"/>
        <source>When seeding time reaches</source>
        <translation>जब स्रोत काल समाप्त हो जाए</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2594"/>
        <source>Pause torrent</source>
        <translation>टौरेंट को विराम दें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2599"/>
        <source>Remove torrent</source>
        <translation>टौरेंट को हटायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2604"/>
        <source>Remove torrent and its files</source>
        <translation>टौरेंट और उसकी फाइलों को हटायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2609"/>
        <source>Enable super seeding for torrent</source>
        <translation>इसे महास्रोत बनायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2617"/>
        <source>When ratio reaches</source>
        <translation>जब अनुपात तक पहुँचे</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2795"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>RSS टाॅरेंट स्वतः डाउनलोडर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2801"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>RSS टाॅरेंटों को स्वतः डाउनलोड करना सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2808"/>
        <source>Edit auto downloading rules...</source>
        <translation>स्वतः डाउनलोड के नियमों को बदलें...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2818"/>
        <source>RSS Smart Episode Filter</source>
        <translation>बुद्धिमान RSS एपिसोड फिल्टर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2824"/>
        <source>Download REPACK/PROPER episodes</source>
        <translation>REPACK/PROPER एपिसोडों को डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2831"/>
        <source>Filters:</source>
        <translation>फिल्टर:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2892"/>
        <source>Web User Interface (Remote control)</source>
        <translation>वेब यूजर इन्टरफेस (रिमोट कण्ट्रोल)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2906"/>
        <source>IP address:</source>
        <translation>IP पता:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2913"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3071"/>
        <source>Ban client after consecutive failures:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3091"/>
        <source>Never</source>
        <translation>कभी नहीं</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3101"/>
        <source>ban for:</source>
        <translation>के लिए प्रतिबन्ध:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3128"/>
        <source>Session timeout:</source>
        <translation>सत्र का समयान्त:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3135"/>
        <source>Disabled</source>
        <translation>अक्षम</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3211"/>
        <source>Enable cookie Secure flag (requires HTTPS)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3229"/>
        <source>Server domains:</source>
        <translation>सर्वर डोमेन:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3236"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2954"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>HTTP के स्थान &amp;पर HTTPS प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3042"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3049"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>आईपी सबनेटों की सज्जनसूची में आने वाले प्रयोक्ताओं का प्रमाणीकरण रहने दें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3062"/>
        <source>IP subnet whitelist...</source>
        <translation>आईपी सबनेट सज्जनसूची...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3307"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>मेरा &amp;परिवर्तनशील डोमेन नाम अद्यतित करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="439"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>क्यूबिटटोरेंट को अधिसूचना क्षेत्र में संक्षिप्त करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Interface</source>
        <translation>पद्धति</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="174"/>
        <source>Language:</source>
        <translation>भाषा:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="461"/>
        <source>Tray icon style:</source>
        <translation>ट्रे चित्र की शैली</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="469"/>
        <source>Normal</source>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="505"/>
        <source>File association</source>
        <translation>फाइल संगठन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="511"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>.torrent फाइल हेतु क्यूबिटटोरेंट उपयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="518"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>मैग्नेट लिंक हेतु क्यूबिटटोरेंट उपयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="528"/>
        <source>Check for program updates</source>
        <translation>प्रोग्राम अद्यतन के लिए जाँच करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="538"/>
        <source>Power Management</source>
        <translation>ऊर्जा प्रबन्धन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="581"/>
        <source>Save path:</source>
        <translation>संचय पथ:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="598"/>
        <source>Backup the log file after:</source>
        <translation>के बाद लॉग फाइल का बैकअप लें:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="638"/>
        <source>Delete backup logs older than:</source>
        <translation>इससे पुरानी बैकअप लॉग फाइलों को मिटा दें:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="746"/>
        <source>When adding a torrent</source>
        <translation>टौरेंट जोड़ते समय</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="761"/>
        <source>Bring torrent dialog to the front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="830"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>पूर्व निर्धारित टाॅरेंट प्रबन्धन रीति</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="845"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>.torrent फाइलें भी मिटा दें जिनका जोड़ना रद्द हो गया</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="848"/>
        <source>Also when addition is cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="870"/>
        <source>Warning! Data loss possible!</source>
        <translation>चेतावनी! डाटा खो सकता है!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="912"/>
        <source>Saving Management</source>
        <translation>सञ्चय प्रबन्धन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="920"/>
        <source>Default Torrent Management Mode:</source>
        <translation>पूर्व निर्धारित टौरेंट प्रबंधन मोड:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="937"/>
        <source>Manual</source>
        <translation>स्वयं</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="942"/>
        <source>Automatic</source>
        <translation>स्वतः</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="965"/>
        <source>When Torrent Category changed:</source>
        <translation>जब टौरेंट की श्रेणी बदल जाए:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="975"/>
        <source>Relocate torrent</source>
        <translation>टाॅरेंट स्थानांतरित करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="980"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>टाॅरेंट को स्वयं प्रबन्धित करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1003"/>
        <source>When Default Save Path changed:</source>
        <translation>जब पूर्व निर्धारित सञ्चय पथ बदले:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1016"/>
        <location filename="../gui/optionsdialog.ui" line="1057"/>
        <source>Relocate affected torrents</source>
        <translation>प्रभावित टाॅरेंटों को स्थानांतरित करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1021"/>
        <location filename="../gui/optionsdialog.ui" line="1062"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>प्रभावित टाॅरेंटों को स्वयं प्रबन्धित करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1087"/>
        <source>Use Subcategories</source>
        <translation>उपश्रेणियाँ प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1106"/>
        <source>Default Save Path:</source>
        <translation>पूर्व निर्धारित संचय पथ:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1120"/>
        <source>Keep incomplete torrents in:</source>
        <translation>अपूर्ण टौरेंटों को यहाँ रखें:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1113"/>
        <source>Copy .torrent files to:</source>
        <translation>.torrent फाइलों को यहां प्रतिलिपि करें:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="427"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>क्यूबिटटोरेंट को अधिसूचना क्षेत्र में दिखाएँ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="561"/>
        <source>&amp;Log file</source>
        <translation>&amp;लॉग फाइल</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="752"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>टाॅरें&amp;ट सामग्री व कुछ विकल्प दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="833"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>बा&amp;द में .torrent फाइलें मिटा दें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1099"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>पूरे हो चुके डाउनलोडों की .torrent फाइलों को यहां प्रतिलिपि करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="888"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>सभी फाइलों के लिए डिस्क में स्थान पूर्व-निर्धारित करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="139"/>
        <source>Use custom UI Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="148"/>
        <source>UI Theme file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="181"/>
        <source>Use system icon theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="209"/>
        <source>Changing Interface settings requires application restart</source>
        <translation>इन्टरफेस की सेटिंग बदलने पर एप्लीकेशन को पुनः आरम्भ करना आवश्यक है</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="225"/>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="339"/>
        <source>Preview file, otherwise open destination folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="394"/>
        <source>When qBittorrent is started, the main window will be minimized</source>
        <translation>क्यूबिटटोरेंट आरंभ होने पर मुख्य विंडो संक्षिप्त रखें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="404"/>
        <source>Shows a confirmation dialog when exiting with active torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="436"/>
        <source>When minimizing, the main window is closed and must be reopened from the systray icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="449"/>
        <source>The systray icon will still be visible when closing the main window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="452"/>
        <source>Close qBittorrent to notification area</source>
        <extracomment>The systray icon will still be visible when closing the main window</extracomment>
        <translation>क्यूबिटटोरेंट को अधिसूचना क्षेत्र में बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="474"/>
        <source>Monochrome (for dark theme)</source>
        <translation>एकवर्णीय (गहरी थीम के लिए)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="479"/>
        <source>Monochrome (for light theme)</source>
        <translation>एकवर्णीय (हल्की थीम के लिए)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="544"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation>जब टाॅरेंट डाउनलोड हो रहे हों तब सिस्टम को सुप्त न होने दें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="551"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation>जब टाॅरेंट स्रोत बने हुए हों तब सिस्टम को सुप्त न होने दें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="595"/>
        <source>Creates an additional log file after the log file reaches the specified file size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="662"/>
        <source>days</source>
        <extracomment>Delete backup logs older than 10 days</extracomment>
        <translation>दिन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="667"/>
        <source>months</source>
        <extracomment>Delete backup logs older than 10 months</extracomment>
        <translation>माह</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="672"/>
        <source>years</source>
        <extracomment>Delete backup logs older than 10 years</extracomment>
        <translation>वर्ष</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="820"/>
        <source>The torrent will be added to download list in a paused state</source>
        <translation>टौरेंट को सूची में विरामित अवस्था में जोड़ा जाएगा</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="823"/>
        <source>Do not start the download automatically</source>
        <extracomment>The torrent will be added to download list in a paused state</extracomment>
        <translation>डाउनलोड स्वतः आरम्भ न करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="885"/>
        <source>Allocate full file sizes on disk before starting downloads, to minimize fragmentation. Only useful for HDDs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="895"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>अपूर्ण फाइलों में .!qB एक्सटेंशन जोड़े</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="902"/>
        <source>When a torrent is downloaded, offer to add torrents from any .torrent files found inside it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="905"/>
        <source>Enable recursive download dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="932"/>
        <source>Automatic: Various torrent properties (e.g. save path) will be decided by the associated category
Manual: Various torrent properties (e.g. save path) must be assigned manually</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1044"/>
        <source>When Category Save Path changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1141"/>
        <source>Automatically add torrents from:</source>
        <translation>यहाँ से टौरेंट स्वतः जोड़े</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1252"/>
        <source>Receiver</source>
        <translation>प्राप्तकर्ता</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1255"/>
        <source>To:</source>
        <comment>To receiver</comment>
        <translation>को:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1262"/>
        <source>SMTP server:</source>
        <translation>SMTP सर्वर:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1275"/>
        <source>Sender</source>
        <translation>प्रेषक</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1278"/>
        <source>From:</source>
        <comment>From sender</comment>
        <translation>से:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1287"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1294"/>
        <location filename="../gui/optionsdialog.ui" line="3005"/>
        <source>Authentication</source>
        <translation>प्रमाणीकरण</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1306"/>
        <location filename="../gui/optionsdialog.ui" line="1750"/>
        <location filename="../gui/optionsdialog.ui" line="3013"/>
        <location filename="../gui/optionsdialog.ui" line="3365"/>
        <source>Username:</source>
        <translation>यूजरनेम:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1316"/>
        <location filename="../gui/optionsdialog.ui" line="1760"/>
        <location filename="../gui/optionsdialog.ui" line="3023"/>
        <location filename="../gui/optionsdialog.ui" line="3379"/>
        <source>Password:</source>
        <translation>पासवर्ड</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1351"/>
        <source>Show console window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1413"/>
        <source>TCP and μTP</source>
        <translation>TCP व μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1446"/>
        <source>Listening Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1454"/>
        <source>Port used for incoming connections:</source>
        <translation>आवक कनेक्शनों के लिए पोर्ट:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1471"/>
        <source>Random</source>
        <translation>यादृच्छिक</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1493"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use different port on each startup</source>
        <translation type="vanished">एप्लिकेशन शुरू करने पर हर बार नया पोर्ट प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1506"/>
        <source>Connections Limits</source>
        <translation>कनेक्शन सीमायें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1522"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>प्रति टौरेंट अधिकतम कनेक्शनों की संख्या</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1532"/>
        <source>Global maximum number of connections:</source>
        <translation>सार्वभौम अधिकतम कनेक्शनों की संख्या</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1571"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>प्रति टौरेंट अधिकतम अपलोड स्लॉटों की संख्या:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1581"/>
        <source>Global maximum number of upload slots:</source>
        <translation>अधिकतम सार्वभौम अपलोड स्लॉटों की संख्या:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1620"/>
        <source>Proxy Server</source>
        <translation>प्रॉक्सी सर्वर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1628"/>
        <source>Type:</source>
        <translation>प्रकार:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1636"/>
        <source>(None)</source>
        <translation>(कोई नहीं)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1641"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1646"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1651"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1662"/>
        <source>Host:</source>
        <translation>होस्ट:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1682"/>
        <location filename="../gui/optionsdialog.ui" line="2922"/>
        <source>Port:</source>
        <translation>पोर्ट:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1710"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1713"/>
        <source>Use proxy for peer connections</source>
        <translation>सहकर्मी कनेक्शनों के लिए प्रॉक्सी का उपयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1720"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1723"/>
        <source>Use proxy only for torrents</source>
        <translation>प्रॉक्सी का उपयोग केवल टाॅरेंटों के लिए करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1736"/>
        <source>A&amp;uthentication</source>
        <translation>प्रमाणी&amp;करण</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1776"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>सूचना: पासवर्ड गोपनीय नहीं है</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1797"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>फिल्टर पथ (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1813"/>
        <source>Reload the filter</source>
        <translation>फिल्टर पुनः लोड करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1828"/>
        <source>Manually banned IP addresses...</source>
        <translation>आपके द्वारा प्रतिबन्धित किए गए IP पते...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1835"/>
        <source>Apply to trackers</source>
        <translation>ट्रैकरों पर लागू करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1893"/>
        <source>Global Rate Limits</source>
        <translation>सीमाओं की सार्वभौम दर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1899"/>
        <location filename="../gui/optionsdialog.ui" line="1915"/>
        <location filename="../gui/optionsdialog.ui" line="1970"/>
        <location filename="../gui/optionsdialog.ui" line="2106"/>
        <location filename="../gui/optionsdialog.ui" line="2382"/>
        <location filename="../gui/optionsdialog.ui" line="2405"/>
        <location filename="../gui/optionsdialog.ui" line="2428"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1902"/>
        <location filename="../gui/optionsdialog.ui" line="1918"/>
        <location filename="../gui/optionsdialog.ui" line="1973"/>
        <location filename="../gui/optionsdialog.ui" line="2109"/>
        <location filename="../gui/optionsdialog.ui" line="2469"/>
        <location filename="../gui/optionsdialog.ui" line="2482"/>
        <source> KiB/s</source>
        <translation>केबी/से</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1947"/>
        <location filename="../gui/optionsdialog.ui" line="2135"/>
        <source>Upload:</source>
        <translation>अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1954"/>
        <location filename="../gui/optionsdialog.ui" line="2142"/>
        <source>Download:</source>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1964"/>
        <source>Alternative Rate Limits</source>
        <translation>सीमाओं की वैकल्पिक दर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2001"/>
        <source>Start time</source>
        <translation>आरम्भ का समय</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2028"/>
        <source>End time</source>
        <translation>अन्त समय</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2058"/>
        <source>When:</source>
        <translation>कब:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2072"/>
        <source>Every day</source>
        <translation>प्रत्येक दिन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2077"/>
        <source>Weekdays</source>
        <translation>कार्यदिवसों</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2082"/>
        <source>Weekends</source>
        <translation>अवकाशदिवस</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2152"/>
        <source>Rate Limits Settings</source>
        <translation>दर सीमा की सैटिंग</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2172"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>LAN के सहकर्मियों पर दर सीमा लागू करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2165"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>अतिरिक्त के यातायात की दर की सीमा तय करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2158"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>µTP पद्धति पर दर सीमा लागू करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2230"/>
        <source>Privacy</source>
        <translation>निजता</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2239"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>ज्यादा सहकर्मियों को ढूँढने के लिए DHT (विकेन्द्रित नेटवर्क) सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2249"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>संगत बिटटोरेंट साधन (µTorrent, Vuze, ...) से पीयर अंतरण</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2252"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>ज्यादा सहकर्मियों को ढूँढने के लिए सहकर्मी आदान-प्रदान (PeX) सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2262"/>
        <source>Look for peers on your local network</source>
        <translation>अपने स्थानीय नेटवर्क पर सहकर्मीं ढूँढे</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2265"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>ज्यादा सहकर्मियों को ढूँढने के लिए स्थानीय सहकर्मी खोज सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2277"/>
        <source>Encryption mode:</source>
        <translation>गोपनीयकरण रीति:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2295"/>
        <source>Require encryption</source>
        <translation>गोपनीयकरण आवश्यक है</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2300"/>
        <source>Disable encryption</source>
        <translation> गोपनीयकरण अक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2325"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>प्रॉक्सी या VPN प्रयोग करते समय सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2328"/>
        <source>Enable anonymous mode</source>
        <translation>अनाम रीति सक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2375"/>
        <source>Maximum active downloads:</source>
        <translation>अधिकतम सक्रिय डाउनलोड:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2398"/>
        <source>Maximum active uploads:</source>
        <translation>अधिकतम सक्रिय अपलोड:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2421"/>
        <source>Maximum active torrents:</source>
        <translation>अधिकतम सक्रिय टौरेंट</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2457"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>
इन सीमाओं में धीमे टौरेंटों को न गिनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2495"/>
        <source>Upload rate threshold:</source>
        <translation>अपलोड गति की दहलीज</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2502"/>
        <source>Download rate threshold:</source>
        <translation>डाउनलोड गति की दहलीज:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2522"/>
        <location filename="../gui/optionsdialog.ui" line="3111"/>
        <location filename="../gui/optionsdialog.ui" line="3138"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation>सेक</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2538"/>
        <source>Torrent inactivity timer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2580"/>
        <source>then</source>
        <translation>फिर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2944"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2973"/>
        <source>Certificate:</source>
        <translation>प्रमाणपत्र:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2966"/>
        <source>Key:</source>
        <translation>कुँजी:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2986"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;प्रमाणपत्रों के बारे में जानकारी&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3033"/>
        <source>Change current password</source>
        <translation>पासवर्ड बदलें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3166"/>
        <source>Use alternative Web UI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3178"/>
        <source>Files location:</source>
        <translation>फाइलों का स्थान:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3191"/>
        <source>Security</source>
        <translation>सुरक्षा</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3197"/>
        <source>Enable clickjacking protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3204"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3218"/>
        <source>Enable Host header validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3255"/>
        <source>Add custom HTTP headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3267"/>
        <source>Header: value pairs, one per line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3277"/>
        <source>Enable reverse proxy support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3288"/>
        <source>Trusted proxies list:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3295"/>
        <source>Specify reverse proxy IPs in order to use forwarded client address (X-Forwarded-For attribute), use &apos;;&apos; to split multiple entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3319"/>
        <source>Service:</source>
        <translation>सेवा:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3342"/>
        <source>Register</source>
        <translation>पंजीकृत हों</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3351"/>
        <source>Domain name:</source>
        <translation>डोमेन का नाम:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="227"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>ये विकल्प चालू करने के बाद आप अपनी .torrent फाइलों को &lt;strong&gt;स्थायी रूप से&lt;/strong&gt; खो देंगे!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="234"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="258"/>
        <source>Select qBittorrent UI Theme file</source>
        <translation>क्यूबिटटोरेंट उपयोक्ता अंतरफलक थीम फाइल चयन</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="259"/>
        <source>qBittorrent UI Theme file (*.qbtheme)</source>
        <translation>क्यूबिटटोरेंट उपयोक्ता अंतरफलक थीम फाइल (*.qbtheme)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="295"/>
        <source>Choose Alternative UI files location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="392"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>समर्थित पैरामीटर (लघु-गुरू संवेदनशील):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="393"/>
        <source>%N: Torrent name</source>
        <translation>%N: टौरेंट नाम</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="394"/>
        <source>%L: Category</source>
        <translation>%L: श्रेणी</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="396"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="397"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="398"/>
        <source>%D: Save path</source>
        <translation>%D: संचय पथ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="399"/>
        <source>%C: Number of files</source>
        <translation>%C: फाइलों की संख्या</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="400"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: टौरेंट आकर (बाइट्स)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="401"/>
        <source>%T: Current tracker</source>
        <translation>%T: निवर्तमान ट्रैकर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="405"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="472"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="481"/>
        <source>Certificate</source>
        <translation>प्रमाणपत्र</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="482"/>
        <source>Select certificate</source>
        <translation>प्रमाणपत्र चुनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="484"/>
        <source>Private key</source>
        <translation>निजी कुँजी</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="485"/>
        <source>Select private key</source>
        <translation>निजी कुँजी चुनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1664"/>
        <source>Select folder to monitor</source>
        <translation>निरीक्षण के लिए फोल्डर चुनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1688"/>
        <source>Adding entry failed</source>
        <translation>प्रविष्टि जोड़ना में असफल</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1788"/>
        <location filename="../gui/optionsdialog.cpp" line="1814"/>
        <source>Invalid path</source>
        <translation>अमान्य पथ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1891"/>
        <source>Location Error</source>
        <translation>स्थान त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1891"/>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="549"/>
        <location filename="../gui/optionsdialog.cpp" line="552"/>
        <location filename="../gui/optionsdialog.cpp" line="1747"/>
        <location filename="../gui/optionsdialog.cpp" line="1749"/>
        <source>Choose export directory</source>
        <translation>निर्यात के लिए फोल्डर चुनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="229"/>
        <source>When these options are enabled, qBittorrent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>ये विकल्प सक्रिय होने पर क्यूबिटटोरेंट द्वारा डाउनलोड पंक्ति में सफलतापूर्वक जोड़ी गई (पहला विकल्प) या नहीं जोड़ी गई (दूसरा विकल्प) .torrent फाइलों को &lt;strong&gt;हटा&lt;/strong&gt; दिया जाएगा। यह &amp;ldquo;टोरेंट जोड़ें&amp;rdquo; मेन्यू कार्य के &lt;strong&gt;साथ&lt;/strong&gt; ही &lt;strong&gt;संलग्न फाइल प्रकार&lt;/strong&gt; द्वारा प्रयुक्त फाइलों पर भी लागू होगा</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="395"/>
        <source>%G: Tags (separated by comma)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="402"/>
        <source>%I: Info hash v1 (or &apos;-&apos; if unavailable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="403"/>
        <source>%J: Info hash v2 (or &apos;-&apos; if unavailable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="404"/>
        <source>%K: Torrent ID (either sha-1 info hash for v1 torrent or truncated sha-256 info hash for v2/hybrid torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="546"/>
        <location filename="../gui/optionsdialog.cpp" line="559"/>
        <location filename="../gui/optionsdialog.cpp" line="562"/>
        <source>Choose a save directory</source>
        <translation>संचय फोल्डर चुनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="555"/>
        <source>Choose an IP filter file</source>
        <translation>IP फिल्टर की फाइल चुनें</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="556"/>
        <source>All supported filters</source>
        <translation>सभी समर्थित फिल्टर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1855"/>
        <source>Parsing error</source>
        <translation>समझने में त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1855"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>दिया गया IP फिल्टर समझ से बाहर</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1857"/>
        <source>Successfully refreshed</source>
        <translation>ताजा कर दिया</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1857"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>दिए गए IP फिल्टर को समझ लिया: %1 नियमों को लागू किया।</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1821"/>
        <source>Invalid key</source>
        <translation>अमान्य कुँजी</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1821"/>
        <source>This is not a valid SSL key.</source>
        <translation>ये SSL कुँजी मान्य नहीं है।</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1795"/>
        <source>Invalid certificate</source>
        <translation>अमान्य प्रमाणपत्र</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="191"/>
        <source>Preferences</source>
        <translation>वरीयताएं</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1795"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>ये SSL प्रमाणपत्र मान्य नहीं है।</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1866"/>
        <source>Time Error</source>
        <translation>समय त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1866"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>शुरुआत और अन्त का समय एक जैसे नहीं हो सकते।</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1876"/>
        <location filename="../gui/optionsdialog.cpp" line="1881"/>
        <source>Length Error</source>
        <translation>लम्बाई त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1876"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1881"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="271"/>
        <source>Interested (local) and choked (peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="276"/>
        <source>Interested (local) and unchoked (peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="285"/>
        <source>Interested (peer) and choked (local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="290"/>
        <source>Interested (peer) and unchoked (local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="296"/>
        <source>Not interested (local) and unchoked (peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="300"/>
        <source>Not interested (peer) and unchoked (local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="304"/>
        <source>Optimistic unchoke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="308"/>
        <source>Peer snubbed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="312"/>
        <source>Incoming connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="316"/>
        <source>Peer from DHT</source>
        <translation>DHT का सहकर्मी</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="320"/>
        <source>Peer from PEX</source>
        <translation>PEX का सहकर्मी</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="324"/>
        <source>Peer from LSD</source>
        <translation>LSD का सहकर्मी</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="328"/>
        <source>Encrypted traffic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="332"/>
        <source>Encrypted handshake</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="95"/>
        <source>Country/Region</source>
        <translation>देश/छेत्र</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="96"/>
        <source>IP</source>
        <translation>आई पी</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="97"/>
        <source>Port</source>
        <translation>पोर्ट</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="98"/>
        <source>Flags</source>
        <translation>फ्लैग</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="99"/>
        <source>Connection</source>
        <translation>कनेक्शन</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="100"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>प्रोग्राम</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="101"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>प्रगति</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="102"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>डाउनलोड गति</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="103"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>अपलोड गति</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="104"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="105"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="106"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>अनुकूलता</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="107"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>फाइलों</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="182"/>
        <source>Column visibility</source>
        <translation>स्तंभ दृश्यता</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="273"/>
        <source>Add a new peer...</source>
        <translation>नया सहकर्मी जोड़े...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="284"/>
        <source>Adding peers</source>
        <translation>सहकर्मियों को जोड़ रहे हैं</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>Some peers cannot be added. Check the Log for details.</source>
        <translation>कुछ सहकर्मियों को जोड़ा नहीं जा सका। अधिक जानकारी के लिए लॉग देखें।</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="284"/>
        <source>Peers are added to this torrent.</source>
        <translation>इस टाॅरेंट में सहकर्मियों को जोड़ा गया।</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="293"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="319"/>
        <source>Ban peer permanently</source>
        <translation>सहकर्मी को स्थायी रूप से अवरुद्ध करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="320"/>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>क्या आप निश्चिंत है कि आप चयनित सहकर्मियों को स्थायी रुप से प्रतिबंधित करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="326"/>
        <source>Peer &quot;%1&quot; is manually banned</source>
        <translation>सहकर्मी &quot;%1&quot; को आपके द्वारा प्रतिबन्धित किया गया</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="290"/>
        <source>Copy IP:port</source>
        <translation>IP:पोर्ट की प्रतिलिपि बनायें</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation>सहकर्मियों को जोड़ें</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>जोड़ने के लिए सहकर्मियों की सूची (प्रति पंक्ति एक):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>प्रारूप: IPv4:पोर्ट / [IPv6]:पोर्ट</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="62"/>
        <source>No peer entered</source>
        <translation>कोई सहकर्मी नहीं भरा गया</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="63"/>
        <source>Please type at least one peer.</source>
        <translation>कम से कम एक सहकर्मी भरें।</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="76"/>
        <source>Invalid peer</source>
        <translation>अमान्य सहकर्मी</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="77"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>सहकर्मी &apos;%1&apos; अमान्य है।</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="172"/>
        <source>Unavailable pieces</source>
        <translation>अनुपलब्ध खण्ड</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="173"/>
        <source>Available pieces</source>
        <translation>उपलब्ध खण्ड</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>Files in this piece:</source>
        <translation>इस खण्ड में फाइलें:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="275"/>
        <source>File in this piece</source>
        <translation>इस खण्ड में फाइल</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="277"/>
        <source>File in these pieces</source>
        <translation>इन खण्डों में फाइल</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="294"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>ज्यादा जानकारी देखने के लिए मेटाडाटा उपलब्ध होने की प्रतीक्षा करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="296"/>
        <source>Hold Shift key for detailed information</source>
        <translation>सविस्तार जानकारी देखने के लिए शिफ्ट कुँजी दबाए रखें</translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation>खोज प्लगिन</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>स्थापित खोज प्लगिनें:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation>संस्करण</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation>सक्षम</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>चेतावनी: इनमें से किसी भी खोज इन्जन से टाॅरेंटों को डाउनलोड करते समय अपने देश के कॉपीराइट नियमों का पालन करें।</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>नए खोज साधन प्लगिन यहाँ से प्राप्त करें : &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation>नए की स्थापना करें</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation>अद्यतन के लिए जाँचे</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation>अस्थापना करें</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="167"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="238"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="303"/>
        <source>Yes</source>
        <translation>हाँ</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="172"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="217"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="243"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="308"/>
        <source>No</source>
        <translation>नहीं</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="223"/>
        <source>Uninstall warning</source>
        <translation>अस्थापना चेतावनी</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="223"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>क्यूबिटटोरेंट में सम्मिलित होने के कारण सभी प्लगिन हटाना संभव नहीं है। आप केवल स्वयं द्वारा जोड़ें गए प्लगिन ही हटा सकते हैं।
वे प्लगिन निष्क्रिय कर दिए गए।</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <source>Uninstall success</source>
        <translation>अस्थापना सफल</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>चुनी हुईं सभी प्लगिनें अस्थापित हो गयीं हैं</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="456"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="471"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="503"/>
        <source>Search plugin update</source>
        <translation>खोज प्लगिन अद्यतन</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>Plugins installed or updated: %1</source>
        <translation>प्लगिन अद्यतित या स्थापित हुई: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="368"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="376"/>
        <source>New search engine plugin URL</source>
        <translation>नए खोज इन्जन प्लगिन का URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="369"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="377"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="374"/>
        <source>Invalid link</source>
        <translation>अमान्य लिंक</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="374"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="391"/>
        <source>Select search plugins</source>
        <translation>खोज प्लगिनों को चुनें</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="392"/>
        <source>qBittorrent search plugin</source>
        <translation>क्यूबिटटोरेंट खोज प्लगिन</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="456"/>
        <source>All your plugins are already up to date.</source>
        <translation>सभी प्लगिन पहले से ही आधुनिक हैं।</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="471"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>प्लगिन अद्यतन जाँचने में असफल: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="485"/>
        <source>Search plugin install</source>
        <translation>खोज प्लगिन की स्थापना</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="486"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>खोज इन्जन प्लगिन &quot;%1&quot; स्थापित नहीं हो सकी। %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="504"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>खोज इन्जन प्लगिन &quot;%1&quot; अद्यतित नहीं हो सकी। %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation>प्लगिन स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>खोज प्लगिन स्रोत:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation>स्थानीय फाइल</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation>वेब लिंक</translation>
    </message>
</context>
<context>
    <name>PortForwarderImpl</name>
    <message>
        <location filename="../base/bittorrent/portforwarderimpl.cpp" line="108"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>UPnP / NAT-PMP समर्थन [चालू]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/portforwarderimpl.cpp" line="118"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>UPnP / NAT-PMP समर्थन [बंद]</translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="76"/>
        <source>qBittorrent is active</source>
        <translation>क्यूबिटटोरेंट सक्रिय है</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="59"/>
        <source>The following files from torrent &quot;%1&quot; support previewing, please select one of them:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Preview</source>
        <translation>पूर्वदर्शन</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="70"/>
        <source>Name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="71"/>
        <source>Size</source>
        <translation>आकार</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="72"/>
        <source>Progress</source>
        <translation>प्रगति</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="136"/>
        <source>Preview impossible</source>
        <translation>पूर्वावलोकन असंभव</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="137"/>
        <source>Sorry, we can&apos;t preview this file: &quot;%1&quot;.</source>
        <translation>क्षमा कीजिए, हम फाइल का पूर्वावलोकन नहीं करा सकते हैं: &quot;%1&quot;।</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>पूर्वावलोकन चयन</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; अस्तित्व में नहीं है</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="315"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; फोल्डर की ओर इंगित नहीं करता है</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="317"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; फाइल की ओर इंगित नहीं करता है</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="319"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>&apos;%1&apos; में पढ़ने की अनुमति नहीं है</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="321"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>&apos;%1&apos; में लिखने की अनुमति नहीं है</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="87"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="86"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>डाउनलोड न करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="88"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>उच्च</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="89"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>सर्वोच्च</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>General</source>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="60"/>
        <source>Trackers</source>
        <translation>ट्रैकर</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Peers</source>
        <translation>सहकर्मीं</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="78"/>
        <source>HTTP Sources</source>
        <translation>एचटीटीपी स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="87"/>
        <source>Content</source>
        <translation>सामग्री</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="98"/>
        <source>Speed</source>
        <translation>गति</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="333"/>
        <source>Downloaded:</source>
        <translation>डाउनलोड :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="110"/>
        <source>Availability:</source>
        <translation>उपलब्धता:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="81"/>
        <source>Progress:</source>
        <translation>प्रगति:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="157"/>
        <source>Transfer</source>
        <translation>अंतरण</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="549"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>सक्रिय काल:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="578"/>
        <source>ETA:</source>
        <translation>बचा हुआ समय:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="507"/>
        <source>Uploaded:</source>
        <translation>अपलोड:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="436"/>
        <source>Seeds:</source>
        <translation>स्रोत:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="452"/>
        <source>Download Speed:</source>
        <translation>डाउनलोड गति:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="188"/>
        <source>Upload Speed:</source>
        <translation>अपलोड गति:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="217"/>
        <source>Peers:</source>
        <translation>सहकर्मीं:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="275"/>
        <source>Download Limit:</source>
        <translation>डाउनलोड सीमा:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="349"/>
        <source>Upload Limit:</source>
        <translation>अपलोड सीमा:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="594"/>
        <source>Wasted:</source>
        <translation>व्यर्थ :</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="233"/>
        <source>Connections:</source>
        <translation>कनेक्शन:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="607"/>
        <source>Information</source>
        <translation>सूचना</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="799"/>
        <source>Info Hash v1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="815"/>
        <source>Info Hash v2:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>टिप्पणी:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1058"/>
        <source>Select All</source>
        <translation>सभी चुनें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1065"/>
        <source>Select None</source>
        <translation>कुछ न चुनें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="651"/>
        <source>Normal</source>
        <translation>सामान्य</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="655"/>
        <source>High</source>
        <translation>उच्च</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="291"/>
        <source>Share Ratio:</source>
        <translation>बांटने का अनुपात:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="407"/>
        <source>Reannounce In:</source>
        <translation>पुनर्घोषणा:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="365"/>
        <source>Last Seen Complete:</source>
        <translation>अन्तिम बार पूर्ण देखा गया:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="625"/>
        <source>Total Size:</source>
        <translation>कुल आकार:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="654"/>
        <source>Pieces:</source>
        <translation>खण्ड:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="683"/>
        <source>Created By:</source>
        <translation>निर्माता:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="712"/>
        <source>Added On:</source>
        <translation>जोड़ने का समय:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="741"/>
        <source>Completed On:</source>
        <translation>पूर्ण होने का समय:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="770"/>
        <source>Created On:</source>
        <translation>निर्माण का समय:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="847"/>
        <source>Save Path:</source>
        <translation>संचय पथ:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="659"/>
        <source>Maximum</source>
        <translation>सर्वोच्च</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="647"/>
        <source>Do not download</source>
        <translation>डाउनलोड न करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="492"/>
        <source>Never</source>
        <translation>कभी नहीं</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="500"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (हैं %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="442"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="445"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 इस सत्र में)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="348"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="349"/>
        <source>N/A</source>
        <translation>लागू नहीं</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="454"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (स्रोत काल %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="461"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 अधिकतम)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="474"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="478"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 कुल)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="484"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="489"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 औसत)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="621"/>
        <source>Open</source>
        <translation>खोलें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="623"/>
        <source>Open Containing Folder</source>
        <translation>धारक फोल्डर को खोलें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="625"/>
        <source>Rename...</source>
        <translation>नाम बदलें...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="645"/>
        <source>Priority</source>
        <translation>प्राथमिकता</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="664"/>
        <source>By shown file order</source>
        <translation type="unfinished">फ़ाइल अनुक्रम में दिखाया गया है </translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="720"/>
        <source>New Web seed</source>
        <translation>नया वेब स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="724"/>
        <source>Remove Web seed</source>
        <translation>वेब स्रोत को हटाएँ</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="727"/>
        <source>Copy Web seed URL</source>
        <translation>वेब स्रोत यूआरएल कॉपी करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="729"/>
        <source>Edit Web seed URL</source>
        <translation>वेब स्रोत का यूआरएल संपादित करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="763"/>
        <source>&lt;center&gt;&lt;b&gt;Speed graphs are disabled&lt;/b&gt;&lt;p&gt;You may change this setting in Advanced Options &lt;/center&gt;</source>
        <translation>&lt;center&gt;&lt;b&gt;गति के ग्राफ अक्षम है&lt;/b&gt;&lt;p&gt;आप ये सेटिंग उन्नत विकल्पों में जाकर बदल सकते हैं&lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="96"/>
        <source>Filter files...</source>
        <translation>फाइलें फिल्टर करें...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="775"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>नया युआरएल स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="776"/>
        <source>New URL seed:</source>
        <translation>नया युआरएल स्रोत:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="783"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="837"/>
        <source>This URL seed is already in the list.</source>
        <translation>यह युआरएल स्रोत पहले से ही सूची में है।</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="829"/>
        <source>Web seed editing</source>
        <translation>वेब स्रोत का संपादन</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="830"/>
        <source>Web seed URL:</source>
        <translation>वेब स्रोत यूआरएल:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="154"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 अज्ञात कमाण्ड लाइन शब्द है।</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="166"/>
        <location filename="../app/main.cpp" line="177"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 एकल कमाण्ड लाइन शब्द हो।</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="212"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>%1 उपयोग करना संभव नहीं है : इस उपयोक्ता हेतु क्यूबिटटोरेंट पहले से सक्रिय है।</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="529"/>
        <source>Usage:</source>
        <translation>प्रयोग:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="532"/>
        <source>Options:</source>
        <translation>विकल्प:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="161"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="207"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="222"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="279"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="306"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="537"/>
        <source>port</source>
        <translation>पोर्ट</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="425"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 को एक मान्य पोर्ट होना चाहिए (1 से 65535)।</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="534"/>
        <source>Display program version and exit</source>
        <translation>प्रोग्राम संस्करण को प्रदर्शित करें और बाहर निकलें</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="536"/>
        <source>Display this help message and exit</source>
        <translation>इस सहायता सन्देश को प्रदर्शित करें और बाहर निकलें</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>Change the Web UI port</source>
        <translation>वेब UI पोर्ट बदलें</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Disable splash screen</source>
        <translation>आरंभ स्क्रीन अक्षम करें</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Run in daemon-mode (background)</source>
        <translation>डेमन-रीति में चलायें (पृष्ठभूमि)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>फोल्डर</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>विन्यास फाइलें इन डायरेक्टरी में संचित करें क्यूबिटटाॅरेंट_&lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>files or URLs</source>
        <translation>फाइलें व URL</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Download the torrents passed by the user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="568"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Options when adding new torrents:</source>
        <translation>नये टौरेंट जोड़ते समय विकल्प:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="558"/>
        <source>path</source>
        <translation>पथ</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="558"/>
        <source>Torrent save path</source>
        <translation>टौरेंट संचय पथ</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Add torrents as started or paused</source>
        <translation>टौरेंट को आरम्भित या विरामित की तरह जोड़े</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="560"/>
        <source>Skip hash check</source>
        <translation>हैश की जाँच रहने दे</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="562"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="564"/>
        <source>Download files in sequential order</source>
        <translation>फाइलों को क्रम में डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="566"/>
        <source>Download first and last pieces first</source>
        <translation>प्रथम व अंतिम खण्ड पहले डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="572"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="577"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="585"/>
        <source>Help</source>
        <translation>सहायता</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="401"/>
        <source>Bad command line</source>
        <translation>गलत कमाण्ड लाइन</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="407"/>
        <source>Bad command line: </source>
        <translation>गलत कमाण्ड लाइन:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>Legal Notice</source>
        <translation>कानूनी सूचना</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="421"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation>क्यूबिटटोरेंट एक फाइल सहभाजन प्रोग्राम है। टोरेंट आरंभ करने के उपरांत सम्मिलित डेटा अपलोड के माध्यम से अन्य व्यक्तियों को उपलब्ध होगा। इस सहभाजित सामग्री हेतु उत्तरदायित्व केवल आपका है।</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="422"/>
        <source>No further notices will be issued.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="435"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>क्यूबिटटोरेंट एक फाइल सहभाजन प्रोग्राम है। टोरेंट आरंभ करने के उपरांत सम्मिलित डेटा अपलोड के माध्यम से अन्य व्यक्तियों को उपलब्ध होगा। इस सहभाजित सामग्री हेतु उत्तरदायित्व केवल आपका है।

इस विषय पर पुनः सूचित नहीं किया जाएगा।</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="423"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>स्वीकार करने और जारी रखने के लिए %1 कुंजी दबाएँ...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="436"/>
        <source>Legal notice</source>
        <translation>कानूनी सूचना</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="437"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="438"/>
        <source>I Agree</source>
        <translation>मै सहमत हूँ</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="255"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="329"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="332"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="335"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="51"/>
        <source>Migrate preferences failed: WebUI https, file: &quot;%1&quot;, error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="73"/>
        <source>Migrated preferences: WebUI https, exported data to file: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="80"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="88"/>
        <source>Invalid data format.</source>
        <translation>अमान्य डाटा प्रारूप।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="117"/>
        <source>Directory for RSS AutoDownloader data is unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="123"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>RSS स्वतः डाउनलोड का डाटा %1 में सञ्चित नहीं किया जा सका। त्रुटि: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="284"/>
        <source>Invalid data format</source>
        <translation>अमान्य डाटा प्रारूप</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="431"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>RSS स्वतः डाउनलोड के नियम %1 से नहीं पढ़े जा सके। त्रुटि: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="445"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>RSS स्वतः डाउनलोड के नियम लोड नहीं हो सके। कारण: %1</translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="215"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>RSS स्रोत &apos;%1&apos; को डाउनलोड करने में असफल। कारण: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="251"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation>RSS स्रोत &apos;%1&apos; का अद्यतन हो गया। %2 नए लेख जोड़े।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="248"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>RSS स्रोत &apos;%1&apos; समझ से बाहर है। कारण: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="205"/>
        <source>RSS feed at &apos;%1&apos; is successfully downloaded. Starting to parse it.</source>
        <translation>&apos;%1&apos; के RSS स्रोत को डाउनलोड कर लिया है। इसे समझने की शुरुआत कर दी है।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="275"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>%1 से RSS सत्र डाटा नहीं पढ़ा जा सका। त्रुटि: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="287"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>RSS सत्र डाटा समझ से बाहर। त्रुटि: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="294"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>RSS सत्र डाटा लोड नहीं हो सका। अमान्य डाटा प्रारूप।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="305"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>RSS लेख &apos;%1#%2&apos; लोड नहीं हुआ। अमान्य डाटा प्रारूप।</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/rss_parser.cpp" line="596"/>
        <source>Invalid RSS feed.</source>
        <translation>RSS स्रोत अमान्य है।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_parser.cpp" line="600"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (पंक्ति: %2, स्तंभ: %3, ऑफसेट: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="162"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>दिए गए URL का RSS पहले से ही है: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="182"/>
        <source>Cannot move root folder.</source>
        <translation>मूल फोल्डर को स्थानान्तरित नहीं कर सकते।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="190"/>
        <location filename="../base/rss/rss_session.cpp" line="231"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>वस्तु अस्तित्व में नहीं है: %1।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="223"/>
        <source>Cannot delete root folder.</source>
        <translation>मूल फोल्डर को डिलीट नहीं कर सकते।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="315"/>
        <source>Couldn&apos;t load RSS Feed &apos;%1&apos;. URL is required.</source>
        <translation>RSS स्रोत &apos;%1&apos; लोड नहीं हुआ। URL आवश्यक है।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="326"/>
        <source>Couldn&apos;t load RSS Feed &apos;%1&apos;. UID is invalid.</source>
        <translation>RSS स्रोत &apos;%1&apos; लोड नहीं हुआ। UID अमान्य है।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="333"/>
        <source>Duplicate RSS Feed UID: %1. Configuration seems to be corrupted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="354"/>
        <source>Couldn&apos;t load RSS Item &apos;%1&apos;. Invalid data format.</source>
        <translation>RSS स्रोत &apos;%1&apos; लोड नहीं हुआ। अमान्य डाटा प्रारूप।</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="404"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>RSS का पथ गलत है: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="411"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>दिए गए पथ का RSS पहले से ही है: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="420"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>खोंजे</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>RSS स्रोतों को लाना अब अक्षम है! आप इसे एप्लीकेशन सेटिंग में सक्षम कर सकते हैं।</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>नयी सदस्यता</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>वस्तुओं को पढ़ा हुआ चिन्हित करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>RSS स्ट्रीमों को ताजा करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>सभी अद्यतित करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>RSS डाउनलोडर...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>टाॅरेंट: (डाउनलोड करने के लिए दो बार क्लिक करें)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>मिटाएं</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>नाम बदलें...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>नाम बदलें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>अद्यतन</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>नयी सदस्यता...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>सभी स्रोत अद्यतित करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>डाउनलोड टौरेंट</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>समाचार यूआरएल खोलें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>स्रोत URL की प्रतिलिपि बनायें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>नया फोल्डर</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="228"/>
        <source>Please choose a folder name</source>
        <translation>फोल्डर के नाम का चुनाव करें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="228"/>
        <source>Folder name:</source>
        <translation>फोल्डर का नाम:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="229"/>
        <source>New folder</source>
        <translation>नया फोल्डर</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="270"/>
        <source>Please type a RSS feed URL</source>
        <translation>RSS स्रोत का URL भरें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="270"/>
        <source>Feed URL:</source>
        <translation>स्रोत URL:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="312"/>
        <source>Deletion confirmation</source>
        <translation>मिटाने की पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="312"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>क्या आप निश्चित ही चुनें हुए RSS स्रोतों को मिटाना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="409"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>इस RSS स्रोत के लिए नया नाम चुनें</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="409"/>
        <source>New feed name:</source>
        <translation>नया स्रोत नाम:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="417"/>
        <source>Rename failed</source>
        <translation>नाम बदलनें में असफल</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="489"/>
        <source>Date: </source>
        <translation>दिनांक:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="491"/>
        <source>Author: </source>
        <translation>रचनाकार:</translation>
    </message>
</context>
<context>
    <name>SearchController</name>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="98"/>
        <source>Python must be installed to use the Search Engine.</source>
        <translation>खोज इन्जन का उपगोय करने के लिए पायथन की स्थापना करें।</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="123"/>
        <source>Unable to create more than %1 concurrent searches.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="203"/>
        <location filename="../webui/api/searchcontroller.cpp" line="209"/>
        <source>Offset is out of range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="286"/>
        <source>All plugins are already up to date.</source>
        <translation>सभी प्लगिन पहले से ही आधुनिक हैं</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="290"/>
        <source>Updating %1 plugins</source>
        <translation>%1 प्लगिनों को अद्यतित कर रहे हैं</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="295"/>
        <source>Updating plugin %1</source>
        <translation>प्लगिन %1 को अद्यतित कर रहे हैं</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="302"/>
        <source>Failed to check for plugin updates: %1</source>
        <translation>प्लगिन अद्यतन जाँचने में असफल: %1</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="14"/>
        <source>Form</source>
        <translation>फॉर्म</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>परिणाम (xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="45"/>
        <source>Search in:</source>
        <translation>में खोजें:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;स्रोतस्वामियों की न्यूनतम व अधिकतम संख्या निर्धारित करें&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="87"/>
        <source>Seeds:</source>
        <translation>स्रोत:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;स्रोतों की न्यूनतम संख्या&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="116"/>
        <location filename="../gui/search/searchjobwidget.ui" line="204"/>
        <source>to</source>
        <translation>से</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;स्रोतों की अधिकतम संख्या&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="126"/>
        <location filename="../gui/search/searchjobwidget.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;टाॅरेंट का न्यूनतम व अधिकतम आकार निर्धारित करें&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="170"/>
        <source>Size:</source>
        <translation>आकार:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;टाॅरेंट का न्यूनतम आकार&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;टाॅरेंट का अधिकतम आकार&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="77"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="78"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>आकार</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="79"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>स्रोतस्वामी</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="80"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>जोंके</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="81"/>
        <source>Search engine</source>
        <translation>खोज इन्जन</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="132"/>
        <source>Filter search results...</source>
        <translation>खोज परिणाम फिल्टर करें...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="307"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>परिणाम (&lt;i&gt;%2&lt;/i&gt; में से &lt;i&gt;%1&lt;/i&gt; प्रदर्शित)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="358"/>
        <source>Torrent names only</source>
        <translation>केवल टौरेंटों के नाम</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="359"/>
        <source>Everywhere</source>
        <translation>हर जगह</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="382"/>
        <source>Use regular expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="396"/>
        <source>Download</source>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="399"/>
        <source>Open description page</source>
        <translation>विवरण पृष्ठ खोलें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="403"/>
        <source>Copy</source>
        <translation>प्रतिलिपि बनाए</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="405"/>
        <source>Name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="407"/>
        <source>Download link</source>
        <translation>डाउनलोड लिंक</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="409"/>
        <source>Description page URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="420"/>
        <source>Searching...</source>
        <translation>खोज रहे हैं...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="422"/>
        <source>Search has finished</source>
        <translation>खोज समाप्त हुई</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="424"/>
        <source>Search aborted</source>
        <translation>खोज रोक दी गयी</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="426"/>
        <source>An error occurred during search...</source>
        <translation>खोज के दौरान एक त्रुटि घटी...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="428"/>
        <source>Search returned no results</source>
        <translation>खोज का कोई परिणाम नहीं मिला</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="453"/>
        <source>Column visibility</source>
        <translation>स्तंभ दृश्यता</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="221"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>खोज इन्जन प्लगिन फाइल का प्रारूप अज्ञात है।</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="233"/>
        <source>Plugin already at version %1, which is greater than %2</source>
        <translation>प्लगिन पहले से ही संस्करण %1 पर है, जो %2 से आधुनिक है</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="234"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>इस प्लगिन का ज्यादा नया संस्करण पहले ही से स्थापित है।</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="257"/>
        <source>Plugin %1 is not supported.</source>
        <translation>प्लगिन %1 समर्थित नहीं है।</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="265"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="269"/>
        <source>Plugin is not supported.</source>
        <translation>प्लगिन समर्थित नहीं है।</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="277"/>
        <source>Plugin %1 has been successfully updated.</source>
        <translation>प्लगिन %1 अद्यतित हो गयी है।</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="342"/>
        <source>All categories</source>
        <translation>सभी श्रेणियाँ</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="343"/>
        <source>Movies</source>
        <translation>फिल्में</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="344"/>
        <source>TV shows</source>
        <translation>टीवी शो</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="345"/>
        <source>Music</source>
        <translation>गानें</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="346"/>
        <source>Games</source>
        <translation>गेम्स</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="347"/>
        <source>Anime</source>
        <translation>एनीमे</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="348"/>
        <source>Software</source>
        <translation>सॉफ्टवेयर</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="349"/>
        <source>Pictures</source>
        <translation>फोटो</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="350"/>
        <source>Books</source>
        <translation>किताबें</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="384"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>अद्यतन सर्वर अभी काम नहीं कर रहा है। %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="405"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="407"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>प्लगिन फाइल डाउनलोड करने में असफल। %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="537"/>
        <source>Plugin &quot;%1&quot; is outdated, updating to version %2</source>
        <translation>प्लगिन %1 पुरानी है, संस्करण %2 पर अद्यतित कर रहे हैं</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="544"/>
        <source>Incorrect update info received for %1 out of %2 plugins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="583"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="293"/>
        <location filename="../gui/search/searchwidget.cpp" line="316"/>
        <location filename="../gui/search/searchwidget.cpp" line="382"/>
        <location filename="../gui/search/searchwidget.cpp" line="390"/>
        <source>Search</source>
        <translation>खोंजे</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>कोई भी खोज करने की प्लगिन स्थापित नहीं है।
स्थापित करने के लिए नीचे की ओर दायीं तरफ &quot;प्लगिनें खोजें...&quot; बटन पर क्लिक करें।</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Search plugins...</source>
        <translation>प्लगिनें खोजें...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="97"/>
        <source>A phrase to search for.</source>
        <translation>खोजने के लिए शब्द:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="98"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="100"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>उदाहरण:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="102"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;राम श्याम&lt;/b&gt;: &lt;b&gt;राम&lt;/b&gt; या &lt;b&gt;श्याम&lt;/b&gt; खोजें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="106"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;राम श्याम&amp;quot;&lt;/b&gt;: &lt;b&gt;राम श्याम&lt;/b&gt; खोजें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="205"/>
        <source>All plugins</source>
        <translation>सभी प्लगिनें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="204"/>
        <source>Only enabled</source>
        <translation>केवल सक्षम</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="170"/>
        <source>Close tab</source>
        <translation>टैब बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="171"/>
        <source>Close all tabs</source>
        <translation>सभी टैबें बंद करें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="206"/>
        <source>Select...</source>
        <translation>चुनें...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <location filename="../gui/search/searchwidget.cpp" line="376"/>
        <location filename="../gui/search/searchwidget.cpp" line="378"/>
        <source>Search Engine</source>
        <translation>खोज इन्जन</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>खोज इन्जन का उपगोय करने के लिए पायथन की स्थापना करें।</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="327"/>
        <source>Empty search pattern</source>
        <translation>रिक्त खोज पैटर्न</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="327"/>
        <source>Please type a search pattern first</source>
        <translation>खोज पैटर्न भरें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="357"/>
        <source>Stop</source>
        <translation>रोकें</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="378"/>
        <source>Search has finished</source>
        <translation>खोज समाप्त हुई</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="376"/>
        <source>Search has failed</source>
        <translation>खोज असफल हुई</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>पुनः न दिखायें</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>qBittorrent will now exit.</source>
        <translation>क्यूबिटटोरेंट अब बंद होगा।</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="115"/>
        <source>E&amp;xit Now</source>
        <translation>अभी बा&amp;हर निकलें</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="116"/>
        <source>Exit confirmation</source>
        <translation>बाहर निकलने की पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>The computer is going to shutdown.</source>
        <translation>कम्प्यूटर बन्द होने वाला है।</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="120"/>
        <source>&amp;Shutdown Now</source>
        <translation>अब बं&amp;द करें</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="121"/>
        <source>Shutdown confirmation</source>
        <translation>बन्द करने की पु‍ष्टि</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="125"/>
        <source>&amp;Suspend Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="126"/>
        <source>Suspend confirmation</source>
        <translation>स्थगित करने की पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>कम्प्यूटर अतिसुप्त होने वाला है।</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="130"/>
        <source>&amp;Hibernate Now</source>
        <translation>अभी &amp;अतिसुप्त करें</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="131"/>
        <source>Hibernate confirmation</source>
        <translation>अतिसुप्त करने की पुष्टि</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="141"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="14"/>
        <source>Global Speed Limits</source>
        <translation>सार्वभौम गति सीमा</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="20"/>
        <source>Speed limits</source>
        <translation>गति सीमायें</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="33"/>
        <location filename="../gui/speedlimitdialog.ui" line="103"/>
        <source>Upload:</source>
        <translation>अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="47"/>
        <location filename="../gui/speedlimitdialog.ui" line="74"/>
        <location filename="../gui/speedlimitdialog.ui" line="117"/>
        <location filename="../gui/speedlimitdialog.ui" line="144"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="50"/>
        <location filename="../gui/speedlimitdialog.ui" line="77"/>
        <location filename="../gui/speedlimitdialog.ui" line="120"/>
        <location filename="../gui/speedlimitdialog.ui" line="147"/>
        <source> KiB/s</source>
        <translation>केबी/से</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="60"/>
        <location filename="../gui/speedlimitdialog.ui" line="130"/>
        <source>Download:</source>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="90"/>
        <source>Alternative speed limits</source>
        <translation>वैकल्पिक गति सीमा</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="173"/>
        <source>Total Upload</source>
        <translation>कुल अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="174"/>
        <source>Total Download</source>
        <translation>कुल डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="178"/>
        <source>Payload Upload</source>
        <translation>सामान अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="179"/>
        <source>Payload Download</source>
        <translation>सामान डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="183"/>
        <source>Overhead Upload</source>
        <translation>अतिरिक्त अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="184"/>
        <source>Overhead Download</source>
        <translation>अतिरिक्त डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="188"/>
        <source>DHT Upload</source>
        <translation>डीएचटी अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="189"/>
        <source>DHT Download</source>
        <translation>डीएचटी डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="193"/>
        <source>Tracker Upload</source>
        <translation>ट्रैकर अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="194"/>
        <source>Tracker Download</source>
        <translation>ट्रैकर डाउनलोड</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>अवधि</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 मिनट</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 मिनट</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 मिनट</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="75"/>
        <source>6 Hours</source>
        <translation>6 घण्टे</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="105"/>
        <source>Select Graphs</source>
        <translation>ग्राफों को चुनें</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Total Upload</source>
        <translation>कुल अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>3 Hours</source>
        <translation>3 घण्टे</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="76"/>
        <source>12 Hours</source>
        <translation>12 घण्टे</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="77"/>
        <source>24 Hours</source>
        <translation>24 घण्टे</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Total Download</source>
        <translation>कुल डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Payload Upload</source>
        <translation>सामान अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>Payload Download</source>
        <translation>सामान डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Overhead Upload</source>
        <translation>अतिरिक्त अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Overhead Download</source>
        <translation>अतिरिक्त डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>DHT Upload</source>
        <translation>डीएचटी अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="90"/>
        <source>DHT Download</source>
        <translation>डीएचटी डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="91"/>
        <source>Tracker Upload</source>
        <translation>ट्रैकर अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="92"/>
        <source>Tracker Download</source>
        <translation>ट्रैकर डाउनलोड</translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation>ढहने की जानकारी</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>आंकड़े</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>उपयोगकर्ता के आंकड़े</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>कैष के आंकड़े</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>पंक्ति में औसत समय</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>जुड़े हुए सहकर्मीं:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation>अब तक का वितरण अनुपात:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation>अब तक डाउनलोड:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation>सत्र में बर्बादी:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation>अब तक उपलोड:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation>कुल बफर आकार:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>प्रदर्शन के आंकड़े</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>पन्क्तिबद्ध I/O कार्य:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>लेखन द्रुतिका ओवरलोड:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>पाठ्य द्रुतिका ओवरलोड:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>पन्क्ति का कुल आकार:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="112"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 मिलीसेकंड</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="192"/>
        <source>Connection status:</source>
        <translation>कनेक्शन स्थिति:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="192"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>कोई प्रत्यक्ष कनेक्शन नहीं। नेटवर्क विन्यास समस्या संभव है।</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="202"/>
        <source>DHT: %1 nodes</source>
        <translation>डीएचटी : %1 नोड</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>क्यूबिटटोरेंट पुनः आरंभ करना आवश्यक है!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="179"/>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Connection Status:</source>
        <translation>कनेक्शन स्थिति:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="179"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>ऑफलाइन। सदारणतः ऐसा तब होता है जब क्यूबिटटाॅरेंट आवक कनेक्शनों के लिए चयनित पोर्टों पर डाटा प्राप्त नहीं कर पाता है।</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Online</source>
        <translation>ऑनलाइन</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="248"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>वैकल्पिक गति सीमाएँ उपयोग करने हेतु क्लिक करें</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="242"/>
        <source>Click to switch to regular speed limits</source>
        <translation>सामान्य गति सीमाएँ उपयोग करने हेतु क्लिक करें</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>सभी (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="186"/>
        <source>Downloading (0)</source>
        <translation>डाउनलोड हो रहे हैं (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="189"/>
        <source>Seeding (0)</source>
        <translation>स्रोत बने हुए (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="192"/>
        <source>Completed (0)</source>
        <translation>पूर्ण (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="195"/>
        <source>Resumed (0)</source>
        <translation>प्रारम्भित(0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="198"/>
        <source>Paused (0)</source>
        <translation>विरामित (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="201"/>
        <source>Active (0)</source>
        <translation>सक्रिय (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="204"/>
        <source>Inactive (0)</source>
        <translation>अक्रिय (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="207"/>
        <source>Stalled (0)</source>
        <translation>अवरुद्ध (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="210"/>
        <source>Stalled Uploading (0)</source>
        <translation>अवरुद्ध अपलोड (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="213"/>
        <source>Stalled Downloading (0)</source>
        <translation>अवरुद्ध डाउनलोड (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="216"/>
        <source>Checking (0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="219"/>
        <source>Errored (0)</source>
        <translation>त्रुटिपूर्ण (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="276"/>
        <source>All (%1)</source>
        <translation>सभी (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="277"/>
        <source>Downloading (%1)</source>
        <translation>डाउनलोड हो रहे हैं (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="278"/>
        <source>Seeding (%1)</source>
        <translation>स्रोत बने हुए (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="279"/>
        <source>Completed (%1)</source>
        <translation>पूर्ण (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="281"/>
        <source>Paused (%1)</source>
        <translation>विरामित (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="280"/>
        <source>Resumed (%1)</source>
        <translation>प्रारम्भित(%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="282"/>
        <source>Active (%1)</source>
        <translation>सक्रिय (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="283"/>
        <source>Inactive (%1)</source>
        <translation>अक्रिय (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="284"/>
        <source>Stalled (%1)</source>
        <translation>अवरुद्ध (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="285"/>
        <source>Stalled Uploading (%1)</source>
        <translation>अवरुद्ध अपलोड (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="286"/>
        <source>Stalled Downloading (%1)</source>
        <translation>अवरुद्ध डाउनलोड (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="287"/>
        <source>Checking (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="288"/>
        <source>Errored (%1)</source>
        <translation>त्रुटिपूर्ण (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="149"/>
        <source>Tags</source>
        <translation>उपनाम</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>All</source>
        <translation>सभी</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="262"/>
        <source>Untagged</source>
        <translation>उपनाम रहित</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="110"/>
        <source>Add tag...</source>
        <translation>उपनाम जोड़ें...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="116"/>
        <source>Remove tag</source>
        <translation>उपनाम हटायें</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove unused tags</source>
        <translation>अनुपयोगी श्रेणियां हटायें</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="123"/>
        <source>Resume torrents</source>
        <translation>टौरेंटो को प्रारम्भ करें</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="125"/>
        <source>Pause torrents</source>
        <translation>टौरेंटो को विराम दें</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="127"/>
        <source>Delete torrents</source>
        <translation>टौरेंटो को मिटाएं</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="171"/>
        <source>New Tag</source>
        <translation>नया चिह्न</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="171"/>
        <source>Tag:</source>
        <translation>उपनाम:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="177"/>
        <source>Invalid tag name</source>
        <translation>अमान्य उपनाम</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="178"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>उपनाम &apos;%1&apos; अमान्य है</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag exists</source>
        <translation>उपनाम अस्तित्व में है</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name already exists.</source>
        <translation>उपनाम पहले से ही अस्तित्व में है।</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>टाॅरेंट श्रेणी के गुण:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>नाम:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>संचय पथ:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="43"/>
        <source>Choose save path</source>
        <translation>संचय पथ चुनें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="65"/>
        <source>New Category</source>
        <translation>नई श्रेणी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="76"/>
        <source>Invalid category name</source>
        <translation>अमान्य श्रेणी नाम</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="77"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="84"/>
        <source>Category creation error</source>
        <translation>श्रेणी बनाने में त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="85"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>आपके द्वारा दिए गए नाम की श्रेणी पहले से ही अस्तित्व में है।
किसी और नाम के साथ प्रयास करें।</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Size</source>
        <translation>आकार</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Progress</source>
        <translation>प्रगति</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Download Priority</source>
        <translation>डाउनलोड प्राथमिकता</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Remaining</source>
        <translation>बचा हुआ</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="193"/>
        <source>Availability</source>
        <translation>उपलब्धता</translation>
    </message>
</context>
<context>
    <name>TorrentContentModelItem</name>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="118"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>मिश्रित</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="120"/>
        <source>Not downloaded</source>
        <translation>डाउनलोड न करें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="122"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>उच्च</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="124"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>अधिकतम</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="126"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>साधारण</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="140"/>
        <source>N/A</source>
        <translation>लागू नहीं</translation>
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="124"/>
        <source>Renaming</source>
        <translation>पुनः नामकरण</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="124"/>
        <source>New name:</source>
        <translation>नया नाम:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="147"/>
        <source>Rename error</source>
        <translation>नाम बदलनें में त्रुटि</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>टाॅरेंट निर्माणक</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="56"/>
        <source>Select file/folder to share</source>
        <translation>बांटने के लिए फाइल/फोल्डर चुनें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="64"/>
        <source>Path:</source>
        <translation>पथ:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="91"/>
        <source>[Drag and drop area]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="101"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="120"/>
        <source>Select file</source>
        <translation>फाइल चुनें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="108"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="113"/>
        <source>Select folder</source>
        <translation>फोल्डर चुनें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="120"/>
        <source>Settings</source>
        <translation>सेटिंग</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="141"/>
        <source>Torrent format:</source>
        <translation>टाॅरेंट प्रारूप:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>Hybrid</source>
        <translation> मिश्रित</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="185"/>
        <source>Piece size:</source>
        <translation>खण्ड का आकर</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="199"/>
        <source>Auto</source>
        <translation>स्वतः</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="204"/>
        <source>16 KiB</source>
        <translation>16 केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="209"/>
        <source>32 KiB</source>
        <translation>32 केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="214"/>
        <source>64 KiB</source>
        <translation>64 केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="219"/>
        <source>128 KiB</source>
        <translation>128 केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="224"/>
        <source>256 KiB</source>
        <translation>256 केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="229"/>
        <source>512 KiB</source>
        <translation>512 केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="234"/>
        <source>1 MiB</source>
        <translation>1 एमबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="239"/>
        <source>2 MiB</source>
        <translation>2 एमबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="244"/>
        <source>4 MiB</source>
        <translation>4 एमबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="249"/>
        <source>8 MiB</source>
        <translation>8 एमबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="254"/>
        <source>16 MiB</source>
        <translation>16 एमबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="259"/>
        <source>32 MiB</source>
        <translation>32 एमबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="267"/>
        <source>Calculate number of pieces:</source>
        <translation>खण्डों की संख्या की गणना करें:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="296"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="303"/>
        <source>Start seeding immediately</source>
        <translation>तुरन्त स्रोत बनायें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="313"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>इस टाॅरेंट के लिए बाँटने के अनुपात की सीमा की अवहेलना करें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="320"/>
        <source>Optimize alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="331"/>
        <source>Align to piece boundary for files larger than:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="338"/>
        <source>Disabled</source>
        <translation>अक्षम</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="341"/>
        <source> KiB</source>
        <translation>केबी</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="378"/>
        <source>Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="384"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="394"/>
        <source>Web seed URLs:</source>
        <translation>वेब स्रोत यूआरएल:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="415"/>
        <source>Tracker URLs:</source>
        <translation>ट्रैकर URL:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="422"/>
        <source>Comments:</source>
        <translation>टिप्पणियां:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="429"/>
        <source>Source:</source>
        <translation>स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="448"/>
        <source>Progress:</source>
        <translation>प्रगति:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="73"/>
        <source>Create Torrent</source>
        <translation>टाॅरेंट बनायें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="181"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="226"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="240"/>
        <source>Torrent creation failed</source>
        <translation>टाॅरेंट बनाने में असफलता</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="181"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="188"/>
        <source>Select where to save the new torrent</source>
        <translation>नया टौरेंट संचित करने के स्थान को चुनें</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="188"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>टाॅरेंट फाइलें (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="226"/>
        <source>Reason: %1</source>
        <translation>कारण: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="240"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>कारण: बनाया गया टाॅरेंट अमान्य है। इसे डाउनलोड सूची में नहीं जोड़ा जायेगा।</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="256"/>
        <source>Torrent creator</source>
        <translation>टाॅरेंट निर्माणक</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="257"/>
        <source>Torrent created:</source>
        <translation>टाॅरेंट बन गया:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesWatcher</name>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="269"/>
        <source>Watched folder path cannot be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="272"/>
        <source>Watched folder path cannot be relative.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="288"/>
        <source>Couldn&apos;t load Watched Folders configuration from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="297"/>
        <source>Couldn&apos;t parse Watched Folders configuration from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="304"/>
        <source>Couldn&apos;t load Watched Folders configuration from %1. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="377"/>
        <source>Couldn&apos;t store Watched Folders configuration to %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentFilesWatcher::Worker</name>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="512"/>
        <source>Failed to open magnet file: %1</source>
        <translation>मैग्नेट फाइल खोलने में असफल: %1</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="577"/>
        <source>Rejecting failed torrent file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="620"/>
        <source>Watching folder: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="140"/>
        <source>File size exceeds max limit %1</source>
        <translation>फाइल आकार ने अधिकतम सीमा %1 को पार कर लिया है</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="152"/>
        <source>Torrent file read error: %1</source>
        <translation>टाॅरेंट फाइल पढ़ने में त्रुटि: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="158"/>
        <source>Torrent file read error: size mismatch</source>
        <translation>टाॅरेंट फाइल पढ़ने में त्रुटि: आकार बेमेल है</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="170"/>
        <source>Invalid metadata</source>
        <translation>अमान्य मेटाडेटा</translation>
    </message>
</context>
<context>
    <name>TorrentOptionsDialog</name>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="14"/>
        <source>Torrent Options</source>
        <translation>टाॅरेंट विकल्प</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="20"/>
        <source>Torrent speed limits</source>
        <translation>टाॅरेंट गति सीमा</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="26"/>
        <source>Download:</source>
        <translation>डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="33"/>
        <location filename="../gui/torrentoptionsdialog.ui" line="46"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="36"/>
        <location filename="../gui/torrentoptionsdialog.ui" line="49"/>
        <source> KiB/s</source>
        <translation>केबी/से</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="59"/>
        <source>These will not exceed the global limits</source>
        <translation>ये सार्वभौम सीमा को पार नहीं करेगा</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="66"/>
        <source>Upload:</source>
        <translation>अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="90"/>
        <source>Torrent share limits</source>
        <translation>टाॅरेंट साझा करने की सीमाएं</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="96"/>
        <source>Use global share limit</source>
        <translation>सीमाओं की सार्वभौम दर का प्रयोग करें</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="106"/>
        <source>Set no share limit</source>
        <translation>साझा करने की कोई सीमा निर्धारित न करें</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="118"/>
        <source>Set share limit to</source>
        <translation>साझा करने की सीमा हो</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="128"/>
        <source>minutes</source>
        <translation>मिनट</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="171"/>
        <source>ratio</source>
        <translation>अनुपात</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="185"/>
        <source>Disable DHT for this torrent</source>
        <translation>इस टाॅरेंट के लिए DHT अक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="205"/>
        <source>Disable PeX for this torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="212"/>
        <source>Disable LSD for this torrent</source>
        <translation>इस टाॅरेंट के लिए LSD अक्षम करें</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="239"/>
        <source>Not applicable to private torrents</source>
        <translation>प्राइवेट टाॅरेंटों पर लागू नहीं है</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="281"/>
        <source>No share limit method selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="281"/>
        <source>Please select a limit method first</source>
        <translation>पहले सीमा की विधि का चयन करें</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="708"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation>त्रुटि: &apos;%1&apos; टाॅरेंट फाइल मान्य नहीं है।</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="871"/>
        <source>Priority must be an integer</source>
        <translation>प्राथमिकता एक पूर्ण संख्या होनी चाहिए</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="874"/>
        <source>Priority is not valid</source>
        <translation>यह प्राथमिकता अमान्य है</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="880"/>
        <source>Torrent&apos;s metadata has not yet downloaded</source>
        <translation>टाॅरेंट का मेटाडाटा अभी डाउनलोड नहीं हुआ है</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="889"/>
        <source>File IDs must be integers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="891"/>
        <source>File ID is not valid</source>
        <translation>फाइल आईडी अमान्य है</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1034"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1045"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1056"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1067"/>
        <source>Torrent queueing must be enabled</source>
        <translation>टौरेंट पंक्तिबद्धीकरण अवश्य ही सक्षम हो</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1081"/>
        <source>Save path cannot be empty</source>
        <translation>सञ्चय पथ रिक्त नहीं हो सकता</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1168"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1185"/>
        <source>Category cannot be empty</source>
        <translation>श्रेणी रिक्त नहीं हो सकती</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1174"/>
        <source>Unable to create category</source>
        <translation>श्रेणी बनाने में अक्षम</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1188"/>
        <source>Unable to edit category</source>
        <translation>श्रेणी संशोधित करने में अक्षम</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1085"/>
        <source>Cannot make save path</source>
        <translation>सञ्चय पथ नहीं बन सका</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="287"/>
        <source>&apos;sort&apos; parameter is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="536"/>
        <source>&quot;%1&quot; is not a valid file index.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="538"/>
        <source>Index %1 is out of bounds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1089"/>
        <source>Cannot write to directory</source>
        <translation>फोल्डर पर नहीं लिख सके</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1093"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1107"/>
        <source>Incorrect torrent name</source>
        <translation>टाॅरेंट का नाम गलत है</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1156"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1171"/>
        <source>Incorrect category name</source>
        <translation>श्रेणी का नाम गलत है</translation>
    </message>
</context>
<context>
    <name>TrackerEntriesDialog</name>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="14"/>
        <source>Edit trackers</source>
        <translation>ट्रैकर संशोधित करें</translation>
    </message>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="20"/>
        <source>One tracker URL per line.

- You can split the trackers into groups by inserting blank lines.
- All trackers within the same group will belong to the same tier.
- The group on top will be tier 0, the next group tier 1 and so on.
- Below will show the common subset of trackers of the selected torrents.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="308"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>सभी (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="311"/>
        <source>Trackerless (0)</source>
        <translation>ट्रैकर रहित (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="314"/>
        <source>Error (0)</source>
        <translation>त्रुटि (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="317"/>
        <source>Warning (0)</source>
        <translation>चेतावनी (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="361"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="426"/>
        <source>Trackerless (%1)</source>
        <translation>ट्रैकर रहित (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="473"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="501"/>
        <source>Error (%1)</source>
        <translation>त्रुटि (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="487"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="513"/>
        <source>Warning (%1)</source>
        <translation>चेतावनी (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="568"/>
        <source>Resume torrents</source>
        <translation>टौरेंटो को प्रारम्भ करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="570"/>
        <source>Pause torrents</source>
        <translation>टौरेंटो को विराम दें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="572"/>
        <source>Delete torrents</source>
        <translation>टौरेंटो को मिटाएं</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="597"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="611"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>सभी (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="281"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="390"/>
        <source>Working</source>
        <translation>काम कर रहा है</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="282"/>
        <source>Disabled</source>
        <translation>अक्षम</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="283"/>
        <source>Disabled for this torrent</source>
        <translation>इस टाॅरेंट के लिए अक्षम है</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="312"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="173"/>
        <source>This torrent is private</source>
        <translation>यह टाॅरेंट निजी है</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="393"/>
        <source>Updating...</source>
        <translation>अद्यतन कर रहा है...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="396"/>
        <source>Not working</source>
        <translation>काम नहीं कर रहा है</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="399"/>
        <source>Not contacted yet</source>
        <translation>अभी तक संपर्क नहीं किया</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="407"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="410"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="413"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="416"/>
        <source>N/A</source>
        <translation>लागू नहीं</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="510"/>
        <source>Tracker editing</source>
        <translation>ट्रैकर संपादन</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="510"/>
        <source>Tracker URL:</source>
        <translation>ट्रैकर URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="516"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="527"/>
        <source>Tracker editing failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="516"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>भरा गया ट्रैकर URL अमान्य है।</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="527"/>
        <source>The tracker URL already exists.</source>
        <translation>यह टाॅरेंट URL पहले से ही है।</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="586"/>
        <source>Add a new tracker...</source>
        <translation>नया ट्रैकर जोड़ें...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="591"/>
        <source>Edit tracker URL...</source>
        <translation>ट्रैकर URL संशोधित करें...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="593"/>
        <source>Remove tracker</source>
        <translation>ट्रैकर हटाएँ</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="595"/>
        <source>Copy tracker URL</source>
        <translation>ट्रैकर URL की प्रतिलिपि बनायें</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="601"/>
        <source>Force reannounce to selected trackers</source>
        <translation>चयनित ट्रैकर्स पर बलपूर्वक घोषणा करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="604"/>
        <source>Force reannounce to all trackers</source>
        <translation>सभी ट्रैकर्स पर बलपूर्वक घोषणा करें</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="630"/>
        <source>Tier</source>
        <translation>परत</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="631"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="632"/>
        <source>Status</source>
        <translation>स्थिति</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="634"/>
        <source>Seeds</source>
        <translation>स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="633"/>
        <source>Peers</source>
        <translation>सहकर्मीं</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="635"/>
        <source>Leeches</source>
        <translation>जोंके</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="636"/>
        <source>Downloaded</source>
        <translation>डाउनलोड हो चुका</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="637"/>
        <source>Message</source>
        <translation>संदेश</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="657"/>
        <source>Column visibility</source>
        <translation>स्तंभ दृश्यता</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>जोड़ने के लिए ट्रैकर्स की सूची (प्रति पंक्ति एक):</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="129"/>
        <source>No change</source>
        <translation>कोई बदलाव नहीं</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="129"/>
        <source>No additional trackers were found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="88"/>
        <source>Download error</source>
        <translation>डाउनलोड त्रुटि</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="89"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>ट्रैकर सूची डाउनलोड नहीं की जा सकी, कारण: %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="680"/>
        <source>Status</source>
        <translation>स्थिति</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="688"/>
        <source>Categories</source>
        <translation>श्रेणियाँ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="707"/>
        <source>Tags</source>
        <translation>उपनाम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="725"/>
        <source>Trackers</source>
        <translation>ट्रैकर्स</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Downloading</source>
        <translation>डाउनलोड हो रहा है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>अवरुद्ध</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>Downloading metadata</source>
        <comment>Used when loading a magnet link</comment>
        <translation>मेटाडाटा डाउनलोड हो रहा है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <source>[F] Downloading metadata</source>
        <comment>Used when forced to load a magnet link. You probably shouldn&apos;t translate the F.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>[F] Downloading</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[ब] डाउनलोड हो रहा है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>स्रोत बना हुआ है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>[F] Seeding</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[ब] स्रोत बना हुआ है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Queued</source>
        <comment>Torrent is queued</comment>
        <translation>कतारबद्ध</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>जाँच कर रहे हैं</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Checking resume data</source>
        <comment>Used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>प्रारम्भ करनें की जानकारी को जांचा जा रहा है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Paused</source>
        <translation>विरामित</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="126"/>
        <source>Completed</source>
        <translation>पूर्ण</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="127"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>स्थानांतरित कर रहा है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="128"/>
        <source>Missing Files</source>
        <translation>अनुपस्थित फाइलें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="129"/>
        <source>Errored</source>
        <comment>Torrent status, the torrent has an error</comment>
        <translation>त्रुटिपूर्ण</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="172"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="173"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>आकार</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="174"/>
        <source>Progress</source>
        <comment>% Done</comment>
        <translation>प्रगति</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="175"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>स्थिति</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="176"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>स्रोत</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="177"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>सहकर्मीं</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="178"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>डाउनलोड गति</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="179"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>अपलोड गति</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="180"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>अनुपात</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="181"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>बचा हुआ समय</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="182"/>
        <source>Category</source>
        <translation>श्रेणी</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="183"/>
        <source>Tags</source>
        <translation>उपनाम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="184"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>जोड़ने का समय</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="185"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>पूर्ण होने का समय</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="186"/>
        <source>Tracker</source>
        <translation>ट्रैकर</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="187"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>डाउनलोड सीमा</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="188"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>अपलोड सीमा</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="189"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>डाउनलोड हो चुका</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="190"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="191"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>सत्र में डाउनलोड</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="192"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>सत्र में अपलोड</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="193"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>बचा हुआ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="194"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>सक्रिय काल</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="195"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>संचय पथ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="196"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>पूर्ण</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="197"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>अनुपात की सीमा</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="198"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>अन्तिम बार पूर्ण देखा गया</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="199"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>अन्तिम गतिविधि</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="200"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>कुल आकर</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="201"/>
        <source>Availability</source>
        <comment>The number of distributed copies of the torrent</comment>
        <translation>उपलब्धता</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="253"/>
        <source>N/A</source>
        <translation>लागू नहीं</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="310"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 पहले</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="323"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (स्रोत काल %2)</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="612"/>
        <source>Column visibility</source>
        <translation>स्तंभ दृश्यता</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="337"/>
        <source>Choose save path</source>
        <translation>संचय पथ चुनें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="593"/>
        <source>Recheck confirmation</source>
        <translation>पुन: जाँच हेतु पु‍ष्टि</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="593"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>क्या आप निश्चित ही चयनित टोरेंट पुनः जाँचना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="786"/>
        <source>Rename</source>
        <translation>नाम बदलें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="786"/>
        <source>New name:</source>
        <translation>नया नाम:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="826"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>आरंभ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="830"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>बलपूर्वक प्रारम्भ करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="828"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>रोकें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="573"/>
        <source>Unable to preview</source>
        <translation>पूर्वावलोकन करने में अक्षम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="573"/>
        <source>The selected torrent &quot;%1&quot; does not contain previewable files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="689"/>
        <source>Add Tags</source>
        <translation>उपनाम जोड़ें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="732"/>
        <source>Remove All Tags</source>
        <translation>सभी उपनाम हटायें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="732"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>चुनें हुए टाॅरेंटों से सभी उपनाम हटायें?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="747"/>
        <source>Comma-separated tags:</source>
        <translation>अल्पविराम द्वारा विभाजित उपनाम:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="756"/>
        <source>Invalid tag</source>
        <translation>अमान्य उपनाम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="757"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>उपनाम: &apos;%1&apos; अमान्य है</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="832"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>हटाएँ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="834"/>
        <source>Preview file...</source>
        <translation>फाइल पूर्वावलोकन...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="838"/>
        <source>Open destination folder</source>
        <translation>लक्षित फोल्डर खोलें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="840"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>ऊपर करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="842"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>नीचे लाएँ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="844"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>शीर्ष पर ले जाएँ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="846"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>अंत में ले जाएँ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="848"/>
        <source>Set location...</source>
        <translation>स्थान निर्धारण...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="852"/>
        <source>Force reannounce</source>
        <translation>पुनः बलपूर्वक घोषणा करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="854"/>
        <source>Magnet link</source>
        <translation>चुम्बकीय लिंक</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="856"/>
        <source>Torrent ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="858"/>
        <source>Name</source>
        <translation>नाम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1114"/>
        <source>Queue</source>
        <translation>कतार</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1122"/>
        <source>Copy</source>
        <translation>प्रतिलिपि बनाए</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="870"/>
        <source>Download first and last pieces first</source>
        <translation>प्रथम व अंतिम खण्ड सबसे पहले डाउनलोड करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="836"/>
        <source>Torrent options...</source>
        <translation>टाॅरेंट विकल्प...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="860"/>
        <source>Info hash v1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="862"/>
        <source>Info hash v2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="872"/>
        <source>Automatic Torrent Management</source>
        <translation>स्वतः टाॅरेंट प्रबन्धन</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation type="unfinished">स्वतः मोड यानि टोरेंट विशेषताएँ (संचय पथ आदि) संबंधित श्रेणी द्वारा निर्धारित होगी</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="875"/>
        <source>Edit trackers...</source>
        <translation>ट्रैकर संशोधित करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1007"/>
        <source>Category</source>
        <translation>श्रेणी</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1009"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>नया...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1011"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>मूल स्थिति में लाएं</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1032"/>
        <source>Tags</source>
        <translation>उपनाम</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1034"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>जोड़ें...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1036"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>सभी हटायें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="850"/>
        <source>Force recheck</source>
        <translation>पुनः जाँच बाध्य करें</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="864"/>
        <source>Super seeding mode</source>
        <translation>महास्रोत रीति</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="866"/>
        <source>Rename...</source>
        <translation>नाम बदलें...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="868"/>
        <source>Download in sequential order</source>
        <translation>क्रमबद्ध डाउनलोड करें</translation>
    </message>
</context>
<context>
    <name>UIThemeManager</name>
    <message>
        <location filename="../gui/uithememanager.cpp" line="88"/>
        <source>Failed to load UI theme from file: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="110"/>
        <source>Couldn&apos;t apply theme stylesheet. stylesheet.qss couldn&apos;t be opened. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="205"/>
        <source>Failed to open &quot;%1&quot;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="213"/>
        <location filename="../gui/uithememanager.cpp" line="218"/>
        <source>&quot;%1&quot; has invalid format. Reason: %2</source>
        <translation>&quot;%1&quot; का प्रारूप अमान्य है। कारण: %2</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="218"/>
        <source>Root JSON value is not an object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="228"/>
        <source>Invalid color for ID &quot;%1&quot; is provided by theme</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="84"/>
        <source>Python detected, executable name: &apos;%1&apos;, version: %2</source>
        <translation>पायथन की उपस्तिथि का पता लगा है। एग्जिक्युटेबल का नाम: &apos;%1&apos;, संस्करण: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="288"/>
        <source>Python not detected</source>
        <translation>पायथन की उपस्तिथि का पता नहीं लगा</translation>
    </message>
</context>
<context>
    <name>WatchedFolderOptionsDialog</name>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="14"/>
        <source>Watched Folder Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="22"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Will watch the folder and all its subfolders. In Manual torrent management mode it will also add subfolder name to the selected Save path.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="25"/>
        <source>Recursive mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="69"/>
        <source>Torrent parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="77"/>
        <source>Torrent Management Mode:</source>
        <translation type="unfinished">टौरेंट प्रबंधन मोड:</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="84"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation type="unfinished">स्वतः मोड यानि टोरेंट विशेषताएँ (संचय पथ आदि) संबंधित श्रेणी द्वारा निर्धारित होगी</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="88"/>
        <source>Manual</source>
        <translation>स्वयं</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="93"/>
        <source>Automatic</source>
        <translation>स्वतः</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="116"/>
        <source>Save at</source>
        <translation>यहाँ संचित करें</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="130"/>
        <source>Category:</source>
        <translation>श्रेणी:</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="172"/>
        <source>Start torrent</source>
        <translation>टाॅरेंट आरंभ करें</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="198"/>
        <source>Content layout:</source>
        <translation>सामग्री का अभिविन्यास:</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="209"/>
        <source>Original</source>
        <translation>मूल</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="214"/>
        <source>Create subfolder</source>
        <translation>उपफोल्डर बनायें</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="219"/>
        <source>Don&apos;t create subfolder</source>
        <translation>उपफोल्डर न बनायें</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.cpp" line="53"/>
        <source>Choose save path</source>
        <translation>संचय पथ चुनें</translation>
    </message>
</context>
<context>
    <name>WatchedFoldersModel</name>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="77"/>
        <source>Watched Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="107"/>
        <source>Folder &apos;%1&apos; is already in watch list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="111"/>
        <source>Folder &apos;%1&apos; doesn&apos;t exist.</source>
        <translation>फोल्डर &apos;%1&apos; मौजूद नहीं है।</translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="113"/>
        <source>Folder &apos;%1&apos; isn&apos;t readable.</source>
        <translation>फोल्डर &apos;%1&apos; को पढ़ने की आज्ञा नहीं है।</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="189"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="197"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="331"/>
        <source>Using built-in Web UI.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="333"/>
        <source>Using custom Web UI. Location: &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="345"/>
        <source>Web UI translation for selected locale (%1) has been successfully loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="350"/>
        <source>Couldn&apos;t load Web UI translation for selected locale (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="398"/>
        <source>Missing &apos;:&apos; separator in WebUI custom HTTP header: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="463"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="674"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="684"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="702"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="723"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="105"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="119"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="123"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="73"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>बाइट्स</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="74"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>केबी</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="75"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>एमबी</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="76"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>जीबी</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="77"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>टेबिबाइट्स</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="78"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="79"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="257"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/सेकंड</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="374"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1घण्टे %2मिनट</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="381"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1दिन %2घण्टे</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="386"/>
        <source>%1y %2d</source>
        <comment>e.g: 2years 10days</comment>
        <translation>%1 वर्ष %2 दिन</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="265"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>अज्ञात</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="144"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>सभी डाउनलोड पूर्ण होने के कारण अब क्यूबिटटाॅरेंट द्वारा कंप्यूटर बंद किया जाएगा।</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="364"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 मिनट</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="368"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1मिनट</translation>
    </message>
</context>
</TS>
