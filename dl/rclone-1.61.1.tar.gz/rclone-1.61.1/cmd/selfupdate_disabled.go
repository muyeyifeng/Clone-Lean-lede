//go:build noselfupdate
// +build noselfupdate

package cmd

const selfupdateEnabled = false
