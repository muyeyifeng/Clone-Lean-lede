`dialwithip` plugin can dial with specified ip
