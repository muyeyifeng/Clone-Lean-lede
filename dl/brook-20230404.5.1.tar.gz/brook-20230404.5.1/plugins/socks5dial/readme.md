`socks5dial` plugin can overwrite default dial, both server-side and client-side.
