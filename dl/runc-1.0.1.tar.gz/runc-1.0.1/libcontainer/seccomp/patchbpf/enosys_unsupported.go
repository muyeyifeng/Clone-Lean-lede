// +build !linux !cgo !seccomp

package patchbpf
