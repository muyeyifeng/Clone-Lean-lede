# //base/android/library_loader

Java code lives at:
 * [//base/android/java/src/org/chromium/base/library_loader/](../java/src/org/chromium/base/library_loader/)

A high-level guide to native code on Android exists at:
 * [//docs/android_native_libraries.md](../../../docs/android_native_libraries.md)
