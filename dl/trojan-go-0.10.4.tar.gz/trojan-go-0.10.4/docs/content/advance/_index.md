---
title: "高级配置"
draft: false
weight: 30
---

这一部分内容将介绍更复杂的Trojan-Go配置方法。对于与Trojan原版不兼容的特性，将在小节中明确标明。
