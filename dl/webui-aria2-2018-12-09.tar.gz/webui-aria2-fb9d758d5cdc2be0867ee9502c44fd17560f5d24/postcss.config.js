module.exports = {
  plugins: [require("autoprefixer")({ browsers: ["> 5%", "IE 11", "last 2 versions"] })]
};
