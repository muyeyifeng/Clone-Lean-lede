// Package dns is an implementation of core.DNS feature.
package dns

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen
